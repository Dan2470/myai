"""
CIPHERX-NEXUS SOCIAL ENGINE MODULE
Omni-channel social media automation with Playwright.
Features: Persistent browser sessions, auto-login, content posting,
trend engagement, DM auto-reply, and video scheduling.

Platforms: Facebook, Instagram, LinkedIn, YouTube, Twitter (X)
"""

import asyncio
import json
import logging
import os
import random
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from playwright.async_api import async_playwright, Browser, BrowserContext, Page

from utils.stealth import StealthController
from utils.security import SecurityManager

logger = logging.getLogger(__name__)


class Platform(Enum):
    """Supported social media platforms."""
    FACEBOOK = "facebook"
    INSTAGRAM = "instagram"
    TWITTER = "twitter"
    LINKEDIN = "linkedin"
    YOUTUBE = "youtube"


class PostStatus(Enum):
    """Status of a social media post."""
    PENDING = "pending"
    POSTING = "posting"
    SUCCESS = "success"
    FAILED = "failed"
    SCHEDULED = "scheduled"


class SocialEngine:
    """
    Omni-channel Social Media Engine.
    
    Manages all social media platform interactions with:
    - Persistent browser context and sessions
    - Automatic login with credential management
    - Content posting across platforms
    - Video scheduling for YouTube
    - Trend engagement
    - DM auto-reply
    """

    def __init__(self, config: Dict[str, Any], security: SecurityManager):
        """
        Initialize social media engine.
        
        Args:
            config: Social media configuration section
            security: SecurityManager instance
        """
        self.config = config
        self.security = security
        self.stealth = StealthController(config.get("stealth", {}))
        
        # Browser instances
        self._playwright = None
        self._browser: Optional[Browser] = None
        self._contexts: Dict[str, BrowserContext] = {}
        self._pages: Dict[str, Page] = {}
        
        # Platform handlers
        self._handlers: Dict[str, 'BasePlatformHandler'] = {}
        
        # Session storage path
        self._sessions_dir = Path("sessions")
        self._sessions_dir.mkdir(exist_ok=True)
        
        # Post tracking
        self._post_queue: asyncio.Queue = asyncio.Queue()
        self._scheduled_posts: List[Dict[str, Any]] = []
        self._post_history: List[Dict[str, Any]] = []
        
        logger.info("[SOCIAL] SocialEngine initialized")

    async def initialize(self) -> bool:
        """
        Initialize Playwright browser and load sessions.
        
        Returns:
            True if initialization successful
        """
        try:
            self._playwright = await async_playwright().start()
            
            # Launch browser with stealth options
            browser_options = {
                "headless": True,
                "args": [
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-accelerated-2d-canvas",
                    "--no-first-run",
                    "--no-zygote",
                    "--disable-gpu",
                    "--disable-web-security",
                    "--disable-features=IsolateOrigins,site-per-process",
                ],
            }
            
            self._browser = await self._playwright.chromium.launch(**browser_options)
            
            # Initialize platform handlers
            await self._init_handlers()
            
            logger.info("[SOCIAL] Browser initialized - Chromium ready")
            return True

        except Exception as e:
            logger.error("[SOCIAL] Initialization failed: %s", e)
            return False

    async def _init_handlers(self) -> None:
        """Initialize platform-specific handlers."""
        handler_classes = {
            Platform.FACEBOOK.value: FacebookHandler,
            Platform.INSTAGRAM.value: InstagramHandler,
            Platform.TWITTER.value: TwitterHandler,
            Platform.LINKEDIN.value: LinkedInHandler,
            Platform.YOUTUBE.value: YouTubeHandler,
        }
        
        for platform_name, handler_class in handler_classes.items():
            platform_config = self.config.get(platform_name, {})
            if platform_config.get("enabled", False):
                handler = handler_class(
                    platform_config,
                    self.stealth,
                    self._sessions_dir,
                )
                self._handlers[platform_name] = handler
                
                # Try to restore session
                await self._restore_session(platform_name)
                
                logger.info("[SOCIAL] Handler ready: %s", platform_name)

    async def _restore_session(self, platform: str) -> bool:
        """
        Restore browser session for platform.
        
        Args:
            platform: Platform name
            
        Returns:
            True if session restored
        """
        try:
            handler = self._handlers.get(platform)
            if not handler:
                return False

            session_file = self._sessions_dir / f"{platform}_session.json"
            
            # Create context with saved state if exists
            context_options = self.stealth.get_browser_context_options()
            
            if session_file.exists():
                context_options["storage_state"] = str(session_file)
                logger.info("[SOCIAL] Restoring session for %s", platform)
            
            context = await self._browser.new_context(**context_options)
            page = await context.new_page()
            
            # Apply stealth scripts
            await self.stealth.apply_stealth_scripts(page)
            
            self._contexts[platform] = context
            self._pages[platform] = page
            
            # Verify session by checking login state
            is_logged_in = await handler.verify_login(page)
            
            if not is_logged_in:
                logger.info("[SOCIAL] Session expired for %s, re-logging in...", platform)
                login_success = await handler.login(page)
                if login_success:
                    await self._save_session(platform)
                return login_success
            
            logger.info("[SOCIAL] Session restored for %s", platform)
            return True

        except Exception as e:
            logger.error("[SOCIAL] Session restore failed for %s: %s", platform, e)
            return False

    async def _save_session(self, platform: str) -> None:
        """
        Save browser session for platform.
        
        Args:
            platform: Platform name
        """
        try:
            context = self._contexts.get(platform)
            if context:
                session_file = self._sessions_dir / f"{platform}_session.json"
                await context.storage_state(path=str(session_file))
                logger.info("[SOCIAL] Session saved for %s", platform)
        except Exception as e:
            logger.error("[SOCIAL] Session save failed for %s: %s", platform, e)

    async def post_update(self, platform: str, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Post update to social media platform.
        
        Args:
            platform: Target platform
            content: Post content/text
            media_paths: Optional media file paths
            
        Returns:
            Post result with status and URL
        """
        handler = self._handlers.get(platform)
        if not handler:
            return {"status": "error", "message": f"Platform {platform} not configured"}

        page = self._pages.get(platform)
        if not page:
            return {"status": "error", "message": f"No active session for {platform}"}

        try:
            result = await handler.post_update(page, content, media_paths)
            
            # Track post
            post_record = {
                "platform": platform,
                "content": content[:100],
                "status": result.get("status", "unknown"),
                "timestamp": datetime.now().isoformat(),
                "url": result.get("url"),
            }
            self._post_history.append(post_record)
            
            return result

        except Exception as e:
            logger.error("[SOCIAL] Post failed on %s: %s", platform, e)
            return {"status": "error", "message": str(e)}

    async def schedule_video(self, video_path: str, title: str, description: str, 
                            tags: Optional[List[str]] = None, 
                            scheduled_time: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Schedule YouTube video upload.
        
        Args:
            video_path: Path to video file
            title: Video title
            description: Video description
            tags: Video tags
            scheduled_time: When to publish (None = immediate)
            
        Returns:
            Upload/schedule result
        """
        handler = self._handlers.get(Platform.YOUTUBE.value)
        if not handler:
            return {"status": "error", "message": "YouTube not configured"}

        page = self._pages.get(Platform.YOUTUBE.value)
        if not page:
            return {"status": "error", "message": "No active YouTube session"}

        if not os.path.exists(video_path):
            return {"status": "error", "message": f"Video file not found: {video_path}"}

        try:
            if scheduled_time and scheduled_time > datetime.now():
                # Schedule for later
                self._scheduled_posts.append({
                    "platform": "youtube",
                    "video_path": video_path,
                    "title": title,
                    "description": description,
                    "tags": tags or [],
                    "scheduled_time": scheduled_time,
                    "status": "scheduled",
                })
                
                return {
                    "status": "scheduled",
                    "scheduled_time": scheduled_time.isoformat(),
                    "message": f"Video scheduled for {scheduled_time}",
                }
            else:
                # Upload immediately
                return await handler.upload_video(page, video_path, title, description, tags)

        except Exception as e:
            logger.error("[SOCIAL] Video upload failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def engage_with_trends(self, platform: str, keyword: str) -> Dict[str, Any]:
        """
        Engage with trending content by keyword.
        
        Args:
            platform: Target platform
            keyword: Trend keyword/hashtag
            
        Returns:
            Engagement results
        """
        handler = self._handlers.get(platform)
        if not handler:
            return {"status": "error", "message": f"Platform {platform} not configured"}

        page = self._pages.get(platform)
        if not page:
            return {"status": "error", "message": f"No active session for {platform}"}

        try:
            return await handler.engage_trends(page, keyword)
        except Exception as e:
            logger.error("[SOCIAL] Trend engagement failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def auto_reply_dms(self, platform: str, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        Auto-reply to direct messages.
        
        Args:
            platform: Target platform
            replies: Optional reply templates by keyword
            
        Returns:
            DM handling results
        """
        handler = self._handlers.get(platform)
        if not handler:
            return {"status": "error", "message": f"Platform {platform} not configured"}

        page = self._pages.get(platform)
        if not page:
            return {"status": "error", "message": f"No active session for {platform}"}

        try:
            return await handler.auto_reply_dms(page, replies)
        except Exception as e:
            logger.error("[SOCIAL] DM auto-reply failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def process_scheduled_posts(self) -> List[Dict[str, Any]]:
        """
        Process scheduled posts that are due.
        
        Returns:
            List of processed post results
        """
        now = datetime.now()
        due_posts = [
            p for p in self._scheduled_posts
            if p["status"] == "scheduled" and p["scheduled_time"] <= now
        ]
        
        results = []
        for post in due_posts:
            if post["platform"] == "youtube" and "video_path" in post:
                result = await self.schedule_video(
                    post["video_path"],
                    post["title"],
                    post["description"],
                    post.get("tags"),
                )
                post["status"] = "posted" if result.get("status") == "success" else "failed"
                results.append(result)
            else:
                result = await self.post_update(post["platform"], post["content"])
                post["status"] = "posted" if result.get("status") == "success" else "failed"
                results.append(result)
        
        return results

    async def get_platform_status(self) -> Dict[str, Any]:
        """
        Get status of all platform connections.
        
        Returns:
            Platform status dictionary
        """
        status = {}
        
        for platform, handler in self._handlers.items():
            page = self._pages.get(platform)
            is_logged_in = False
            
            if page:
                try:
                    is_logged_in = await handler.verify_login(page)
                except:
                    pass
            
            status[platform] = {
                "enabled": True,
                "logged_in": is_logged_in,
                "session_exists": (self._sessions_dir / f"{platform}_session.json").exists(),
            }
        
        return status

    async def close(self) -> None:
        """Close all browser contexts and connections."""
        logger.info("[SOCIAL] Closing browser connections...")
        
        # Save all sessions
        for platform in self._contexts:
            await self._save_session(platform)
        
        # Close contexts
        for context in self._contexts.values():
            await context.close()
        
        self._contexts.clear()
        self._pages.clear()
        
        # Close browser
        if self._browser:
            await self._browser.close()
        
        # Stop playwright
        if self._playwright:
            await self._playwright.stop()
        
        logger.info("[SOCIAL] Browser connections closed")


class BasePlatformHandler(ABC):
    """
    Abstract base class for social media platform handlers.
    Each platform implements its own login, posting, and engagement logic.
    """

    def __init__(
        self,
        config: Dict[str, Any],
        stealth: StealthController,
        sessions_dir: Path,
    ):
        self.config = config
        self.stealth = stealth
        self.sessions_dir = sessions_dir

    @abstractmethod
    async def login(self, page: Page) -> bool:
        """Log in to the platform."""
        pass

    @abstractmethod
    async def verify_login(self, page: Page) -> bool:
        """Verify if currently logged in."""
        pass

    @abstractmethod
    async def post_update(self, page: Page, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """Post content update."""
        pass

    @abstractmethod
    async def engage_trends(self, page: Page, keyword: str) -> Dict[str, Any]:
        """Engage with trending content."""
        pass

    @abstractmethod
    async def auto_reply_dms(self, page: Page, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Auto-reply to DMs."""
        pass

    async def _safe_click(self, page: Page, selector: str, timeout: int = 5000) -> bool:
        """Safely click element with human-like behavior."""
        try:
            element = await page.wait_for_selector(selector, timeout=timeout)
            if element:
                box = await element.bounding_box()
                if box:
                    await self.stealth.human_like_mouse_move(
                        page, 
                        int(box["x"] + box["width"] / 2),
                        int(box["y"] + box["height"] / 2),
                    )
                await element.click()
                await self.stealth.random_delay()
                return True
        except Exception as e:
            logger.debug("[SOCIAL] Click failed for %s: %s", selector, e)
        return False

    async def _safe_type(self, page: Page, selector: str, text: str) -> bool:
        """Safely type with human-like behavior."""
        try:
            await self.stealth.human_like_typing(page, selector, text)
            return True
        except Exception as e:
            logger.debug("[SOCIAL] Type failed for %s: %s", selector, e)
        return False


class FacebookHandler(BasePlatformHandler):
    """Facebook platform handler."""

    URLS = {
        "login": "https://www.facebook.com/login",
        "home": "https://www.facebook.com",
        "create_post": "https://www.facebook.com",
    }

    async def login(self, page: Page) -> bool:
        """Log in to Facebook."""
        try:
            await page.goto(self.URLS["login"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Enter credentials
            await self._safe_type(page, "input#email", self.config["email"])
            await self._safe_type(page, "input#pass", self.config["password"])
            
            # Click login
            await self._safe_click(page, "button[name='login']")
            
            # Wait for navigation
            await page.wait_for_load_state("networkidle", timeout=30000)
            
            # Check for 2FA
            if await page.query_selector("input[name='approvals_code']"):
                logger.warning("[SOCIAL:FB] 2FA required - cannot complete login automatically")
                return False
            
            # Verify login
            is_logged_in = await self.verify_login(page)
            if is_logged_in:
                logger.info("[SOCIAL:FB] Login successful")
            return is_logged_in

        except Exception as e:
            logger.error("[SOCIAL:FB] Login failed: %s", e)
            return False

    async def verify_login(self, page: Page) -> bool:
        """Check if logged in to Facebook."""
        try:
            await page.goto(self.URLS["home"], wait_until="domcontentloaded", timeout=10000)
            
            # Check for login page indicator
            login_button = await page.query_selector("button[name='login']")
            if login_button:
                return False
            
            # Check for home page indicators
            indicators = [
                "[aria-label='Facebook']",
                "[aria-label='Home']",
                "[data-pagelet='LeftRail']",
            ]
            
            for indicator in indicators:
                if await page.query_selector(indicator):
                    return True
            
            return False

        except Exception as e:
            logger.debug("[SOCIAL:FB] Login verification error: %s", e)
            return False

    async def post_update(self, page: Page, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """Post update to Facebook."""
        try:
            await page.goto(self.URLS["home"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Click create post
            create_post_selectors = [
                "[aria-label='Create a post']",
                "[aria-label="What's on your mind?"]",
                "div[role='button']:has-text('Create post')",
            ]
            
            clicked = False
            for selector in create_post_selectors:
                if await self._safe_click(page, selector):
                    clicked = True
                    break
            
            if not clicked:
                return {"status": "error", "message": "Could not open post creator"}

            await self.stealth.random_delay(2, 4)

            # Type content
            post_input_selectors = [
                "[aria-label="What's on your mind?"]",
                "[contenteditable='true']",
                "div[role='textbox']",
            ]
            
            typed = False
            for selector in post_input_selectors:
                if await self._safe_type(page, selector, content):
                    typed = True
                    break
            
            if not typed:
                return {"status": "error", "message": "Could not enter post content"}

            # Upload media if provided
            if media_paths:
                # Click photo/video button
                photo_button = await page.query_selector("[aria-label='Photo/Video']")
                if photo_button:
                    await photo_button.click()
                    await self.stealth.random_delay(1, 2)
                    
                    # Upload files
                    file_input = await page.query_selector("input[type='file'][accept*='image']")
                    if file_input:
                        await file_input.set_input_files(media_paths)
                        await self.stealth.random_delay(3, 6)

            await self.stealth.random_delay(1, 2)

            # Click post button
            post_button_selectors = [
                "[aria-label='Post']",
                "div[role='button']:has-text('Post')",
            ]
            
            for selector in post_button_selectors:
                if await self._safe_click(page, selector):
                    await self.stealth.random_delay(3, 5)
                    return {
                        "status": "success",
                        "message": "Post published to Facebook",
                        "platform": "facebook",
                    }

            return {"status": "error", "message": "Could not click post button"}

        except Exception as e:
            logger.error("[SOCIAL:FB] Post failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def engage_trends(self, page: Page, keyword: str) -> Dict[str, Any]:
        """Engage with trending topics on Facebook."""
        try:
            # Search for keyword
            search_url = f"https://www.facebook.com/search/top?q={keyword.replace(' ', '%20')}"
            await page.goto(search_url, wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find and interact with posts
            posts = await page.query_selector_all("[role='article']")
            engaged = 0
            
            for post in posts[:5]:  # Limit engagement
                try:
                    # Random engagement (like or comment)
                    if random.random() > 0.5:
                        like_button = await post.query_selector("[aria-label='Like']")
                        if like_button:
                            await like_button.click()
                            await self.stealth.random_delay(1, 3)
                            engaged += 1
                except:
                    continue

            return {
                "status": "success",
                "keyword": keyword,
                "posts_found": len(posts),
                "engaged": engaged,
            }

        except Exception as e:
            logger.error("[SOCIAL:FB] Trend engagement failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def auto_reply_dms(self, page: Page, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Auto-reply to Facebook messages."""
        try:
            await page.goto("https://www.facebook.com/messages", wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find unread messages
            unread_indicators = await page.query_selector_all("[aria-label*='unread']")
            
            processed = 0
            for indicator in unread_indicators[:10]:  # Process max 10
                try:
                    await indicator.click()
                    await self.stealth.random_delay(2, 3)

                    # Get last message
                    messages = await page.query_selector_all("[role='row']")
                    if messages:
                        last_message = await messages[-1].text_content()
                        
                        # Find matching reply
                        reply_text = "Thank you for your message. I'll get back to you soon."
                        if replies:
                            for key, response in replies.items():
                                if key.lower() in (last_message or "").lower():
                                    reply_text = response
                                    break

                        # Type reply
                        input_box = await page.query_selector("[aria-label='Message']")
                        if input_box:
                            await self._safe_type(page, "[aria-label='Message']", reply_text)
                            await self.stealth.random_delay(1, 2)
                            
                            # Send
                            send_button = await page.query_selector("[aria-label='Press Enter to send']")
                            if send_button:
                                await send_button.click()
                                processed += 1
                                await self.stealth.random_delay(2, 4)

                except:
                    continue

            return {
                "status": "success",
                "messages_processed": processed,
            }

        except Exception as e:
            logger.error("[SOCIAL:FB] DM auto-reply failed: %s", e)
            return {"status": "error", "message": str(e)}


class InstagramHandler(BasePlatformHandler):
    """Instagram platform handler."""

    URLS = {
        "login": "https://www.instagram.com/accounts/login/",
        "home": "https://www.instagram.com/",
        "create": "https://www.instagram.com/",
    }

    async def login(self, page: Page) -> bool:
        """Log in to Instagram."""
        try:
            await page.goto(self.URLS["login"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Accept cookies if prompted
            cookie_button = await page.query_selector("button:has-text('Allow all cookies')")
            if cookie_button:
                await cookie_button.click()
                await self.stealth.random_delay(1, 2)

            # Enter credentials
            await self._safe_type(page, "input[name='username']", self.config["username"])
            await self._safe_type(page, "input[name='password']", self.config["password"])
            
            # Click login
            await self._safe_click(page, "button[type='submit']")
            
            await page.wait_for_load_state("networkidle", timeout=30000)
            
            # Handle "Save Your Login Info" prompt
            not_now = await page.query_selector("button:has-text('Not Now')")
            if not_now:
                await not_now.click()
                await self.stealth.random_delay(1, 2)

            is_logged_in = await self.verify_login(page)
            if is_logged_in:
                logger.info("[SOCIAL:IG] Login successful")
            return is_logged_in

        except Exception as e:
            logger.error("[SOCIAL:IG] Login failed: %s", e)
            return False

    async def verify_login(self, page: Page) -> bool:
        """Check if logged in to Instagram."""
        try:
            await page.goto(self.URLS["home"], wait_until="domcontentloaded", timeout=10000)
            
            login_form = await page.query_selector("input[name='password']")
            if login_form:
                return False
            
            nav_elements = [
                "[aria-label='Home']",
                "[aria-label='Search']",
                "svg[aria-label='Home']",
            ]
            
            for elem in nav_elements:
                if await page.query_selector(elem):
                    return True
            
            return False

        except Exception:
            return False

    async def post_update(self, page: Page, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """Post to Instagram (photo/video)."""
        try:
            await page.goto(self.URLS["home"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Click create button
            create_selectors = [
                "[aria-label='New post']",
                "svg[aria-label='New post']",
            ]
            
            for selector in create_selectors:
                if await self._safe_click(page, selector):
                    break
            else:
                # Try alternative: direct URL
                await page.goto("https://www.instagram.com/create/select/", wait_until="networkidle")

            await self.stealth.random_delay(2, 3)

            # Upload media
            if media_paths:
                file_input = await page.query_selector("input[type='file'][accept='image/jpeg,image/png,image/heic,image/heif,video/mp4,video/quicktime']")
                if file_input:
                    await file_input.set_input_files(media_paths[:10])  # Max 10 files
                    await self.stealth.random_delay(3, 6)

            # Next button (crop/resize)
            next_button = await page.query_selector("button:has-text('Next')")
            if next_button:
                await next_button.click()
                await self.stealth.random_delay(2, 3)

            # Next button again (filters)
            next_button = await page.query_selector("button:has-text('Next')")
            if next_button:
                await next_button.click()
                await self.stealth.random_delay(2, 3)

            # Enter caption
            caption_input = await page.query_selector("[aria-label='Write a caption...']")
            if caption_input:
                await self._safe_type(page, "[aria-label='Write a caption...']", content)

            await self.stealth.random_delay(1, 2)

            # Share
            share_button = await page.query_selector("button:has-text('Share')")
            if share_button:
                await share_button.click()
                await self.stealth.random_delay(5, 10)
                
                return {
                    "status": "success",
                    "message": "Post published to Instagram",
                    "platform": "instagram",
                }

            return {"status": "error", "message": "Could not complete Instagram post"}

        except Exception as e:
            logger.error("[SOCIAL:IG] Post failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def engage_trends(self, page: Page, keyword: str) -> Dict[str, Any]:
        """Engage with trending hashtags on Instagram."""
        try:
            hashtag_url = f"https://www.instagram.com/explore/tags/{keyword.replace(' ', '')}/"
            await page.goto(hashtag_url, wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Get recent posts
            posts = await page.query_selector_all("article a")
            engaged = 0

            for post in posts[:9]:  # Top 9 posts
                try:
                    await post.click()
                    await self.stealth.random_delay(2, 4)

                    # Like post
                    like_button = await page.query_selector("[aria-label='Like'] svg")
                    if like_button:
                        await like_button.click()
                        engaged += 1
                        await self.stealth.random_delay(1, 3)

                    # Close modal
                    close_button = await page.query_selector("[aria-label='Close']")
                    if close_button:
                        await close_button.click()
                        await self.stealth.random_delay(1, 2)

                except:
                    continue

            return {
                "status": "success",
                "hashtag": keyword,
                "posts_engaged": engaged,
            }

        except Exception as e:
            logger.error("[SOCIAL:IG] Trend engagement failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def auto_reply_dms(self, page: Page, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Auto-reply to Instagram DMs."""
        try:
            await page.goto("https://www.instagram.com/direct/inbox/", wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Dismiss notifications if present
            not_now = await page.query_selector("button:has-text('Not Now')")
            if not_now:
                await not_now.click()
                await self.stealth.random_delay(1, 2)

            # Find unread conversations
            unread_chats = await page.query_selector_all("div[role='listitem']:has(div[aria-label*='unread'])")
            
            processed = 0
            for chat in unread_chats[:5]:
                try:
                    await chat.click()
                    await self.stealth.random_delay(2, 3)

                    # Get messages
                    messages = await page.query_selector_all("[role='listitem'] div[class*='message']")
                    if messages:
                        last_msg = await messages[-1].text_content()
                        
                        reply = "Thanks for reaching out! I'll respond shortly."
                        if replies:
                            for key, resp in replies.items():
                                if key.lower() in (last_msg or "").lower():
                                    reply = resp
                                    break

                        # Type and send
                        msg_input = await page.query_selector("[placeholder='Message...']")
                        if msg_input:
                            await self._safe_type(page, "[placeholder='Message...']", reply)
                            await self.stealth.random_delay(1, 2)
                            
                            send_btn = await page.query_selector("[aria-label='Send']")
                            if send_btn:
                                await send_btn.click()
                                processed += 1
                                await self.stealth.random_delay(2, 3)

                except:
                    continue

            return {
                "status": "success",
                "messages_replied": processed,
            }

        except Exception as e:
            logger.error("[SOCIAL:IG] DM auto-reply failed: %s", e)
            return {"status": "error", "message": str(e)}


class TwitterHandler(BasePlatformHandler):
    """Twitter/X platform handler."""

    URLS = {
        "login": "https://twitter.com/i/flow/login",
        "home": "https://twitter.com/home",
        "compose": "https://twitter.com/compose/tweet",
    }

    async def login(self, page: Page) -> bool:
        """Log in to Twitter/X."""
        try:
            await page.goto(self.URLS["login"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Enter username
            await self._safe_type(page, "input[autocomplete='username']", self.config["username"])
            await self._safe_click(page, "//span[text()='Next']")
            
            await self.stealth.random_delay(2, 4)

            # Enter password
            password_input = await page.wait_for_selector("input[name='password']", timeout=10000)
            if password_input:
                await self._safe_type(page, "input[name='password']", self.config["password"])
            
            await self._safe_click(page, "//span[text()='Log in']")
            await page.wait_for_load_state("networkidle", timeout=30000)

            is_logged_in = await self.verify_login(page)
            if is_logged_in:
                logger.info("[SOCIAL:TW] Login successful")
            return is_logged_in

        except Exception as e:
            logger.error("[SOCIAL:TW] Login failed: %s", e)
            return False

    async def verify_login(self, page: Page) -> bool:
        """Check if logged in to Twitter."""
        try:
            await page.goto(self.URLS["home"], wait_until="domcontentloaded", timeout=10000)
            
            login_indicator = await page.query_selector("input[autocomplete='username']")
            if login_indicator:
                return False
            
            home_indicators = [
                "[aria-label='Home']",
                "[data-testid='primaryColumn']",
                "a[href='/home']",
            ]
            
            for indicator in home_indicators:
                if await page.query_selector(indicator):
                    return True
            
            return False

        except Exception:
            return False

    async def post_update(self, page: Page, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """Post tweet to Twitter/X."""
        try:
            await page.goto(self.URLS["compose"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Type tweet
            tweet_input = await page.wait_for_selector("[data-testid='tweetTextarea_0']", timeout=10000)
            if tweet_input:
                await self._safe_type(page, "[data-testid='tweetTextarea_0']", content)
            else:
                # Fallback
                await self._safe_type(page, "[contenteditable='true']", content)

            await self.stealth.random_delay(1, 2)

            # Upload media if provided
            if media_paths:
                file_input = await page.query_selector("input[type='file'][accept^='image/']")
                if file_input:
                    await file_input.set_input_files(media_paths[:4])  # Max 4 images
                    await self.stealth.random_delay(3, 5)

            # Click tweet button
            tweet_button = await page.query_selector("[data-testid='tweetButton']")
            if tweet_button:
                await tweet_button.click()
                await self.stealth.random_delay(3, 6)
                
                return {
                    "status": "success",
                    "message": "Tweet posted successfully",
                    "platform": "twitter",
                }

            return {"status": "error", "message": "Could not click tweet button"}

        except Exception as e:
            logger.error("[SOCIAL:TW] Post failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def engage_trends(self, page: Page, keyword: str) -> Dict[str, Any]:
        """Engage with trending topics on Twitter."""
        try:
            search_url = f"https://twitter.com/search?q={keyword.replace(' ', '%20')}&f=live"
            await page.goto(search_url, wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find tweets
            tweets = await page.query_selector_all("[data-testid='tweet']")
            engaged = 0

            for tweet in tweets[:5]:
                try:
                    # Like tweet
                    like_button = await tweet.query_selector("[data-testid='like']")
                    if like_button:
                        await like_button.click()
                        engaged += 1
                        await self.stealth.random_delay(1, 3)
                except:
                    continue

            return {
                "status": "success",
                "keyword": keyword,
                "tweets_engaged": engaged,
            }

        except Exception as e:
            logger.error("[SOCIAL:TW] Trend engagement failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def auto_reply_dms(self, page: Page, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Auto-reply to Twitter DMs."""
        try:
            await page.goto("https://twitter.com/messages", wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find conversation previews with unread indicators
            conversations = await page.query_selector_all("[data-testid='conversation']")
            
            processed = 0
            for conv in conversations[:5]:
                try:
                    # Check if unread
                    unread = await conv.query_selector("div[class*='unread']")
                    if not unread:
                        continue

                    await conv.click()
                    await self.stealth.random_delay(2, 3)

                    # Get last message
                    messages = await page.query_selector_all("[data-testid='messageEntry']")
                    if messages:
                        last_msg = await messages[-1].text_content()
                        
                        reply = "Thanks for the message! I'll get back to you."
                        if replies:
                            for key, resp in replies.items():
                                if key.lower() in (last_msg or "").lower():
                                    reply = resp
                                    break

                        msg_input = await page.query_selector("[data-testid='dmComposerTextInput']")
                        if msg_input:
                            await self._safe_type(page, "[data-testid='dmComposerTextInput']", reply)
                            await self.stealth.random_delay(1, 2)
                            
                            send_btn = await page.query_selector("[data-testid='dmComposerSendButton']")
                            if send_btn:
                                await send_btn.click()
                                processed += 1
                                await self.stealth.random_delay(2, 3)

                except:
                    continue

            return {
                "status": "success",
                "messages_replied": processed,
            }

        except Exception as e:
            logger.error("[SOCIAL:TW] DM auto-reply failed: %s", e)
            return {"status": "error", "message": str(e)}


class LinkedInHandler(BasePlatformHandler):
    """LinkedIn platform handler."""

    URLS = {
        "login": "https://www.linkedin.com/login",
        "feed": "https://www.linkedin.com/feed/",
        "messaging": "https://www.linkedin.com/messaging/",
    }

    async def login(self, page: Page) -> bool:
        """Log in to LinkedIn."""
        try:
            await page.goto(self.URLS["login"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            await self._safe_type(page, "input#username", self.config["email"])
            await self._safe_type(page, "input#password", self.config["password"])
            
            await self._safe_click(page, "button[type='submit']")
            await page.wait_for_load_state("networkidle", timeout=30000)

            # Handle security challenge
            challenge = await page.query_selector("input#input__phone_verification_pin")
            if challenge:
                logger.warning("[SOCIAL:LI] Security verification required")
                return False

            is_logged_in = await self.verify_login(page)
            if is_logged_in:
                logger.info("[SOCIAL:LI] Login successful")
            return is_logged_in

        except Exception as e:
            logger.error("[SOCIAL:LI] Login failed: %s", e)
            return False

    async def verify_login(self, page: Page) -> bool:
        """Check if logged in to LinkedIn."""
        try:
            await page.goto(self.URLS["feed"], wait_until="domcontentloaded", timeout=10000)
            
            login_form = await page.query_selector("input#password")
            if login_form:
                return False

            indicators = [
                "[data-test-id='primary-nav-home-tab']",
                "[aria-label='LinkedIn']",
                "global-nav",
            ]
            
            for indicator in indicators:
                if await page.query_selector(indicator):
                    return True
            
            return False

        except Exception:
            return False

    async def post_update(self, page: Page, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """Post update to LinkedIn."""
        try:
            await page.goto(self.URLS["feed"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Click start post
            post_button = await page.query_selector("[data-test-id='share-creation-trigger']")
            if not post_button:
                post_button = await page.query_selector("button:has-text('Start a post')")
            
            if post_button:
                await post_button.click()
                await self.stealth.random_delay(2, 4)

            # Type content in modal
            editor = await page.wait_for_selector("[data-test-id='share-creation-unified-modal'] [contenteditable='true']", timeout=10000)
            if editor:
                await self._safe_type(page, "[data-test-id='share-creation-unified-modal'] [contenteditable='true']", content)

            await self.stealth.random_delay(1, 2)

            # Upload media
            if media_paths:
                file_input = await page.query_selector("input[type='file']")
                if file_input:
                    await file_input.set_input_files(media_paths[:9])  # Max 9 images
                    await self.stealth.random_delay(3, 6)

            # Click post
            post_btn = await page.query_selector("[data-test-id='share-creation-unified-modal'] button:has-text('Post')")
            if post_btn:
                await post_btn.click()
                await self.stealth.random_delay(3, 6)
                
                return {
                    "status": "success",
                    "message": "Post published to LinkedIn",
                    "platform": "linkedin",
                }

            return {"status": "error", "message": "Could not complete LinkedIn post"}

        except Exception as e:
            logger.error("[SOCIAL:LI] Post failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def engage_trends(self, page: Page, keyword: str) -> Dict[str, Any]:
        """Engage with trending topics on LinkedIn."""
        try:
            search_url = f"https://www.linkedin.com/search/results/content/?keywords={keyword.replace(' ', '%20')}"
            await page.goto(search_url, wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find posts
            posts = await page.query_selector_all("[data-test-id='social-activity-social-action-bar']")
            engaged = 0

            for post in posts[:5]:
                try:
                    like_button = await post.query_selector("button:has-text('Like')")
                    if like_button:
                        await like_button.click()
                        engaged += 1
                        await self.stealth.random_delay(1, 3)
                except:
                    continue

            return {
                "status": "success",
                "keyword": keyword,
                "posts_engaged": engaged,
            }

        except Exception as e:
            logger.error("[SOCIAL:LI] Trend engagement failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def auto_reply_dms(self, page: Page, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Auto-reply to LinkedIn messages."""
        try:
            await page.goto(self.URLS["messaging"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find conversations
            conversations = await page.query_selector_all("[data-test-id='conversation-list-item']")
            
            processed = 0
            for conv in conversations[:5]:
                try:
                    # Check for unread indicator
                    unread = await conv.query_selector("[class*='unread']")
                    if not unread:
                        continue

                    await conv.click()
                    await self.stealth.random_delay(2, 3)

                    # Get messages
                    messages = await page.query_selector_all("[data-test-id='message-bubble']")
                    if messages:
                        last_msg = await messages[-1].text_content()
                        
                        reply = "Thank you for your message. I'll respond soon."
                        if replies:
                            for key, resp in replies.items():
                                if key.lower() in (last_msg or "").lower():
                                    reply = resp
                                    break

                        msg_input = await page.query_selector("[data-test-id='message-compose-area'] [contenteditable='true']")
                        if msg_input:
                            await self._safe_type(page, "[data-test-id='message-compose-area'] [contenteditable='true']", reply)
                            await self.stealth.random_delay(1, 2)
                            
                            send_btn = await page.query_selector("button[type='submit']")
                            if send_btn:
                                await send_btn.click()
                                processed += 1
                                await self.stealth.random_delay(2, 3)

                except:
                    continue

            return {
                "status": "success",
                "messages_replied": processed,
            }

        except Exception as e:
            logger.error("[SOCIAL:LI] DM auto-reply failed: %s", e)
            return {"status": "error", "message": str(e)}


class YouTubeHandler(BasePlatformHandler):
    """YouTube platform handler."""

    URLS = {
        "login": "https://accounts.google.com/signin",
        "studio": "https://studio.youtube.com",
        "upload": "https://www.youtube.com/upload",
    }

    async def login(self, page: Page) -> bool:
        """Log in to YouTube via Google."""
        try:
            await page.goto("https://www.youtube.com", wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Click sign in
            sign_in = await page.query_selector("a[href*='https://accounts.google.com/ServiceLogin']")
            if sign_in:
                await sign_in.click()
                await page.wait_for_load_state("networkidle")

            # Enter email
            await self._safe_type(page, "input[type='email']", self.config["email"])
            await self._safe_click(page, "#identifierNext")
            
            await self.stealth.random_delay(3, 5)

            # Enter password
            await self._safe_type(page, "input[type='password']", self.config["password"])
            await self._safe_click(page, "#passwordNext")
            
            await page.wait_for_load_state("networkidle", timeout=30000)

            # Handle 2FA if needed
            challenge = await page.query_selector("input[type='tel']")
            if challenge:
                logger.warning("[SOCIAL:YT] 2FA required")
                return False

            is_logged_in = await self.verify_login(page)
            if is_logged_in:
                logger.info("[SOCIAL:YT] Login successful")
            return is_logged_in

        except Exception as e:
            logger.error("[SOCIAL:YT] Login failed: %s", e)
            return False

    async def verify_login(self, page: Page) -> bool:
        """Check if logged in to YouTube."""
        try:
            await page.goto("https://www.youtube.com", wait_until="domcontentloaded", timeout=10000)
            
            avatar = await page.query_selector("button#avatar-btn")
            sign_in_btn = await page.query_selector("a[href*='ServiceLogin']")
            
            if avatar and not sign_in_btn:
                return True
            
            return False

        except Exception:
            return False

    async def post_update(self, page: Page, content: str, media_paths: Optional[List[str]] = None) -> Dict[str, Any]:
        """Post community update to YouTube."""
        try:
            channel_id = self.config.get("channel_id", "")
            community_url = f"https://www.youtube.com/channel/{channel_id}/community" if channel_id else "https://www.youtube.com/channel/default/community"
            
            await page.goto(community_url, wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Click create post
            create_btn = await page.query_selector("#create-icon")
            if create_btn:
                await create_btn.click()
                await self.stealth.random_delay(1, 2)
                
                post_option = await page.query_selector("tp-yt-paper-item:has-text('Create post')")
                if post_option:
                    await post_option.click()
                    await self.stealth.random_delay(2, 3)

            # Type content
            content_box = await page.query_selector("#contenteditable-root")
            if content_box:
                await self._safe_type(page, "#contenteditable-root", content)

            await self.stealth.random_delay(1, 2)

            # Post
            post_btn = await page.query_selector("#submit-button")
            if post_btn:
                await post_btn.click()
                await self.stealth.random_delay(3, 5)
                
                return {
                    "status": "success",
                    "message": "Community post published",
                    "platform": "youtube",
                }

            return {"status": "error", "message": "Could not publish community post"}

        except Exception as e:
            logger.error("[SOCIAL:YT] Post failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def upload_video(
        self, 
        page: Page, 
        video_path: str, 
        title: str, 
        description: str,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Upload video to YouTube.
        
        Args:
            page: Playwright page
            video_path: Path to video file
            title: Video title
            description: Video description
            tags: Video tags
            
        Returns:
            Upload result
        """
        try:
            await page.goto(self.URLS["upload"], wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Click select files
            file_input = await page.wait_for_selector("input[type='file']", timeout=10000)
            if file_input:
                await file_input.set_input_files(video_path)

            await self.stealth.random_delay(5, 10)  # Wait for upload to start

            # Enter title
            title_input = await page.query_selector("#textbox[aria-label='Title']")
            if title_input:
                await title_input.fill("")  # Clear default
                await self._safe_type(page, "#textbox[aria-label='Title']", title)

            await self.stealth.random_delay(1, 2)

            # Enter description
            desc_input = await page.query_selector("#textbox[aria-label='Description']")
            if desc_input:
                await self._safe_type(page, "#textbox[aria-label='Description']", description)

            await self.stealth.random_delay(1, 2)

            # Click next (Details -> Video elements -> Checks)
            for _ in range(3):
                next_btn = await page.query_selector("#next-button")
                if next_btn:
                    await next_btn.click()
                    await self.stealth.random_delay(2, 3)

            # Select visibility (Public)
            public_radio = await page.query_selector("[name='PUBLIC']")
            if public_radio:
                await public_radio.click()
                await self.stealth.random_delay(1, 2)

            # Publish
            publish_btn = await page.query_selector("#done-button")
            if publish_btn:
                await publish_btn.click()
                await self.stealth.random_delay(5, 10)
                
                return {
                    "status": "success",
                    "message": "Video uploaded successfully",
                    "title": title,
                    "platform": "youtube",
                }

            return {"status": "error", "message": "Could not complete video upload"}

        except Exception as e:
            logger.error("[SOCIAL:YT] Video upload failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def engage_trends(self, page: Page, keyword: str) -> Dict[str, Any]:
        """Engage with trending videos on YouTube."""
        try:
            search_url = f"https://www.youtube.com/results?search_query={keyword.replace(' ', '+')}"
            await page.goto(search_url, wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find videos
            videos = await page.query_selector_all("#video-title")
            engaged = 0

            for video in videos[:5]:
                try:
                    await video.click()
                    await self.stealth.page_load_wait()
                    await self.stealth.simulate_reading_time(page)

                    # Like video
                    like_button = await page.query_selector("#like-button")
                    if like_button:
                        await like_button.click()
                        engaged += 1

                    await self.stealth.random_delay(3, 5)
                    await page.go_back()
                    await self.stealth.page_load_wait()

                except:
                    continue

            return {
                "status": "success",
                "keyword": keyword,
                "videos_engaged": engaged,
            }

        except Exception as e:
            logger.error("[SOCIAL:YT] Trend engagement failed: %s", e)
            return {"status": "error", "message": str(e)}

    async def auto_reply_dms(self, page: Page, replies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """Auto-reply to YouTube comments (not DMs)."""
        try:
            # YouTube Studio comments
            await page.goto("https://studio.youtube.com/comments", wait_until="networkidle")
            await self.stealth.page_load_wait()

            # Find unreplied comments
            comments = await page.query_selector_all("[data-test-id='comment-row']")
            
            processed = 0
            for comment in comments[:10]:
                try:
                    reply_btn = await comment.query_selector("[data-test-id='reply-button']")
                    if not reply_btn:
                        continue

                    await reply_btn.click()
                    await self.stealth.random_delay(1, 2)

                    reply_text = "Thanks for your comment! Appreciate the support."
                    
                    reply_input = await comment.query_selector("[contenteditable='true']")
                    if reply_input:
                        await reply_input.fill(reply_text)
                        await self.stealth.random_delay(1, 2)
                        
                        submit_btn = await comment.query_selector("[data-test-id='submit-button']")
                        if submit_btn:
                            await submit_btn.click()
                            processed += 1
                            await self.stealth.random_delay(2, 3)

                except:
                    continue

            return {
                "status": "success",
                "comments_replied": processed,
            }

        except Exception as e:
            logger.error("[SOCIAL:YT] Comment reply failed: %s", e)
            return {"status": "error", "message": str(e)}
