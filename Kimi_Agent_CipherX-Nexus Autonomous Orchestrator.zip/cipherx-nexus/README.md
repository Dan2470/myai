# CipherX-Nexus Ultimate Python Orchestrator

A production-ready, autonomous multi-agent system built in Python that serves as your personal AI automation engine. Designed for 12GB+ VPS deployment with iron-clad security.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    CIPHERX-NEXUS v1.0.0                     │
│                                                             │
│  ┌──────────────┐    ┌──────────────────────────────┐      │
│  │   TELEGRAM   │◄──►│      MASTER ORCHESTRATOR      │      │
│  │   BOT API    │    │         nexus_core.py          │      │
│  │  (User 8244..│◄──►│                               │      │
│  └──────────────┘    │  • Task Routing & Delegation   │      │
│                      │  • Agent Lifecycle Management  │      │
│  ┌──────────────┐    │  • Security Enforcement        │      │
│  │  KIMI 2.5    │◄──►│  • Session Persistence         │      │
│  │   (Sonar)    │    └───────────────┬───────────────┘      │
│  │   AI Brain   │                    │                       │
│  └──────────────┘           ┌────────┴────────┐              │
│                             ▼                 ▼              │
│                    ┌─────────────┐   ┌──────────────┐       │
│                    │   Social    │   │   Utility    │       │
│                    │   Engine    │   │   Modules    │       │
│                    │  (5 Plats)  │   │  (3 Cores)   │       │
│                    └──────┬──────┘   └──────┬───────┘       │
│                           │                  │               │
│              ┌────────────┼──────────┐      │               │\n│              ▼            ▼          ▼      ▼               │
│         ┌────────┐  ┌────────┐ ┌────────┐ ┌─────────┐     │
│         │Facebook│  │Twitter │ │LinkedIn│ │  Email  │     │
│         │   IG   │  │ YouTube│ │        │ │ Handler │     │
│         └────────┘  └────────┘ └────────┘ └─────────┘     │
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  │
│  │ Content  │  │  Web     │  │ Security │  │  Base    │  │
│  │  Agent   │  │  Coding  │  │  Agent   │  │  Agent   │  │
│  │(SEO/Gen) │  │(PHP/Py)  │  │(Kali/PT) │  │(Abstract)│  │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## File Structure

```
cipherx-nexus/
├── nexus_core.py              # Main orchestrator & Telegram handler
├── social_engine.py           # Playwright social media automation
├── config.json                # Configuration template
├── setup.sh                   # One-click Ubuntu installer
├── requirements.txt           # Python dependencies
├── README.md                  # This file
├── sessions/                  # Browser session storage (auto-created)
│   ├── facebook_session.json
│   ├── instagram_session.json
│   ├── twitter_session.json
│   ├── linkedin_session.json
│   └── youtube_session.json
├── logs/                      # Application logs (auto-created)
│   └── nexus.log
├── output/                    # Generated outputs
│   └── security_reports/
├── utils/                     # Core utility modules
│   ├── __init__.py
│   ├── security.py            # Authentication, 2FA, command sanitization
│   ├── stealth.py             # Anti-detection & human-like behavior
│   └── email_handler.py       # IMAP/SMTP email operations
└── agents/                    # Sub-agent modules
    ├── __init__.py
    ├── base_agent.py          # Abstract base agent class
    ├── content_agent.py       # SEO content generation
    ├── web_coding_agent.py    # Code generation & debugging
    └── security_agent.py      # Kali Linux security tools
```

## Quick Start

### Prerequisites

- Ubuntu 20.04/22.04/24.04 LTS
- 12GB+ RAM recommended
- Root access (for setup.sh)
- Telegram Bot Token (from @BotFather)
- Kimi AI API Key

### One-Click Installation

```bash
# Clone or upload project files
cd /opt
git clone <repository> cipherx-nexus  # or upload manually
cd cipherx-nexus

# Run installer
chmod +x setup.sh
sudo ./setup.sh
```

The installer will:
1. Update system packages
2. Install Python 3.11 + pip
3. Install Node.js 20.x
4. Install Playwright + Chromium
5. Create virtual environment
6. Install Python dependencies
7. Setup systemd service
8. Configure firewall (UFW) + fail2ban
9. Install security tools (nmap, dirsearch, etc.)

### Manual Configuration

Edit `config.json` with your credentials:

```json
{
  "security": {
    "master_password_plaintext": "YOUR_STRONG_PASSWORD_HERE"
  },
  "telegram": {
    "bot_token": "YOUR_BOT_TOKEN_FROM_BOTFATHER"
  },
  "ai_brain": {
    "api_key": "YOUR_KIMI_API_KEY",
    "model": "kimi-latest"
  }
}
```

Or use environment variables (takes priority):

```bash
export NEXUS_BOT_TOKEN="your_token"
export NEXUS_AI_KEY="your_key"
export NEXUS_MASTER_PASSWORD="your_password"
```

### Start the Service

```bash
# Start
sudo systemctl start cipherx-nexus

# Check status
sudo systemctl status cipherx-nexus

# View logs
sudo journalctl -u cipherx-nexus -f

# Restart
sudo systemctl restart cipherx-nexus
```

## Telegram Commands

Send `/start` to your bot to begin. All commands are locked to your Telegram User-ID.

| Command | Description | 2FA Required |
|---------|-------------|-------------|
| `/start` | Welcome message | No |
| `/help` | Full command reference | No |
| `/status` | System status & metrics | No |
| `/auth <password>` | Authenticate for privileged access | No |
| `/social post <platform> <text>` | Post to social media | No |
| `/social trends <platform> <keyword>` | Engage with trends | No |
| `/social dms <platform>` | Auto-reply DMs | No |
| `/email fetch [limit]` | Fetch emails | No |
| `/email summary` | Email summary | No |
| `/content title <topic>` | Generate SEO titles | No |
| `/content caption <topic>` | Social media captions | No |
| `/content prompt <topic>` | AI image prompts | No |
| `/code generate <lang> <desc>` | Generate code | No |
| `/code debug <lang>` | Debug code (reply) | No |
| `/code scaffold <type> <name>` | Scaffold project | No |
| `/security scan <target>` | Port scan | No |
| `/security web <target>` | Web vulnerability scan | No |
| `/security recon <target>` | Full reconnaissance | **Yes** |
| `/shell <command>` | Execute shell command | **Yes** |
| `/ai <prompt>` | Query AI brain | No |
| `/agents` | List agent status | No |
| `/sessions` | Social media session status | No |
| `/log [n]` | Show last n log lines | No |
| `/stop` | Graceful shutdown | **Yes** |

## Security Features

### Iron-Clad Protection
- **User-ID Lockdown**: Hardcoded to only respond to Telegram User-ID `8244634415`
- **Master Password 2FA**: Required for shell execution, reconnaissance, and shutdown
- **Command Sanitization**: All shell commands validated against allow/block lists
- **Brute Force Protection**: 3 attempts before 60-minute lockout
- **Audit Logging**: All privileged actions logged with timestamps
- **Session Timeout**: Auto-expire authenticated sessions after 30 minutes

### Stealth Mode
- Human-like mouse movement using bezier curves
- Randomized typing speed (30-80 WPM) with occasional errors
- Viewport and user-agent rotation
- WebGL/Canvas fingerprint randomization
- WebRTC leak prevention
- Proxy support (SOCKS5/HTTP)

## Supported Platforms

### Social Media (via Playwright)
| Platform | Post | Schedule | Trends | DMs | Session Persistence |
|----------|------|----------|--------|-----|-------------------|
| Facebook | Yes | No | Yes | Yes | Yes |
| Instagram | Yes | No | Yes | Yes | Yes |
| Twitter/X | Yes | No | Yes | Yes | Yes |
| LinkedIn | Yes | No | Yes | Yes | Yes |
| YouTube | Community | Video Upload | Yes | Comments | Yes |

### Security Tools (Kali Linux)
- **nmap** - Port scanning with multiple profiles
- **dirsearch/gobuster** - Directory brute-forcing
- **subfinder** - Subdomain enumeration
- **httpx** - HTTP probing
- **nikto** - Web vulnerability scanning
- **wpscan** - WordPress vulnerability scanning
- **sqlmap** - SQL injection detection
- **OpenSSL** - SSL/TLS analysis

## Agent System

| Agent | Purpose | Priority Levels |
|-------|---------|-----------------|
| ContentAgent | SEO titles, descriptions, captions, image prompts | Critical to Background |
| WebCodingAgent | Laravel/PHP/Python code generation & debugging | Critical to Background |
| SecurityAgent | Penetration testing, reconnaissance, reporting | Critical to Background |

All agents feature:
- Async task execution with priority queue
- Automatic retry with exponential backoff
- Timeout protection
- Health monitoring
- Event-driven communication with orchestrator

## Configuration Reference

### Security Section
```json
{
  "security": {
    "authorized_telegram_user_id": 8244634415,
    "master_password_plaintext": "CHANGE_THIS",
    "session_timeout_minutes": 30,
    "max_login_attempts": 3,
    "lockout_duration_minutes": 60,
    "allowed_shell_commands": ["nmap", "dirsearch", "python3", "php", "git"],
    "blocked_commands": ["rm -rf /", "mkfs", "dd if=/dev/zero"]
  }
}
```

### Proxy Configuration
```json
{
  "security": {
    "proxy": {
      "enabled": true,
      "type": "socks5",
      "host": "127.0.0.1",
      "port": 1080,
      "username": "proxy_user",
      "password": "proxy_pass"
    }
  }
}
```

## Monitoring & Maintenance

### Health Checks
The orchestrator performs automatic health checks every 60 seconds:
- Agent status verification
- Session timeout cleanup
- Scheduled post processing

### Log Rotation
Logs are automatically rotated at 100MB with 5 backups preserved.

### Manual Maintenance
```bash
# View recent logs
tail -f /opt/cipherx-nexus/logs/nexus.log

# Check all agent status
# (via Telegram: /agents command)

# Restart service
sudo systemctl restart cipherx-nexus

# Update after code changes
cd /opt/cipherx-nexus
sudo git pull  # if using git
sudo systemctl restart cipherx-nexus
```

## Troubleshooting

### Bot not responding
1. Check token: `sudo journalctl -u cipherx-nexus | grep "TELEGRAM"`
2. Verify User-ID in config matches your Telegram ID
3. Check firewall: `sudo ufw status`

### Playwright/Browser issues
```bash
# Reinstall browsers
cd /opt/cipherx-nexus
source venv/bin/activate
playwright install chromium
playwright install-deps chromium
```

### Session expired
Sessions are saved automatically. The system will attempt re-login when needed. To force re-auth:
1. Delete session file: `sudo rm /opt/cipherx-nexus/sessions/facebook_session.json`
2. Restart: `sudo systemctl restart cipherx-nexus`

### Permission denied errors
```bash
# Fix ownership
sudo chown -R nexus:nexus /opt/cipherx-nexus
```

## License

Proprietary - All rights reserved.

## Version History

| Version | Date | Notes |
|---------|------|-------|
| 1.0.0 | 2025-01 | Initial release |

---

**Built for autonomous operation. Deploy once, control from anywhere.**
