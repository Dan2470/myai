"""
CIPHERX-NEXUS STEALTH MODULE
Human-like browser automation with anti-detection measures.
Features: Mouse movement simulation, randomized typing, proxy rotation,
viewport spoofing, and WebGL/Canvas fingerprint randomization.
"""

import asyncio
import json
import logging
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class ProxyConfig:
    """Proxy configuration for stealth browsing."""
    enabled: bool
    type: str  # socks5, http, https
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    
    @property
    def server(self) -> str:
        """Get proxy server string for Playwright."""
        auth = ""
        if self.username and self.password:
            auth = f"{self.username}:{self.password}@"
        return f"{self.type}://{auth}{self.host}:{self.port}"


@dataclass 
class ViewportConfig:
    """Viewport configuration for fingerprint randomization."""
    width: int
    height: int
    device_scale_factor: float = 1.0
    
    @property
    def dict(self) -> Dict[str, Any]:
        return {
            "width": self.width,
            "height": self.height,
            "device_scale_factor": self.device_scale_factor,
        }


class StealthController:
    """
    Stealth controller for human-like browser automation.
    
    Features:
    - Bezier curve mouse movements
    - Human-like typing with errors and corrections
    - Proxy support (SOCKS5/HTTP)
    - Viewport and user-agent rotation
    - WebGL/Canvas noise injection
    - WebRTC leak prevention
    """

    # Common user agents for rotation
    USER_AGENTS: List[str] = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.0 Edg/119.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.0",
    ]

    # Common screen resolutions
    VIEWPORTS: List[ViewportConfig] = [
        ViewportConfig(1920, 1080),
        ViewportConfig(1366, 768),
        ViewportConfig(1440, 900),
        ViewportConfig(1536, 864),
        ViewportConfig(1280, 720),
        ViewportConfig(1600, 900),
    ]

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize stealth controller.
        
        Args:
            config: Stealth configuration from config.json
        """
        self.config = config
        self.enabled = config.get("enabled", True)
        self.mouse_speed_range: Tuple[float, float] = tuple(config.get(
            "mouse_speed_variance", [0.3, 1.5]
        ))
        self.typing_wpm_range: Tuple[int, int] = tuple(config.get(
            "typing_speed_wpm", [30, 80]
        ))
        self.typing_error_rate: float = config.get("typing_error_rate", 0.02)
        self.page_load_delay: Tuple[int, int] = tuple(config.get(
            "page_load_delay", [2, 5]
        ))
        self.action_delay: Tuple[int, int] = tuple(config.get(
            "action_delay", [1, 3]
        ))
        self.proxy_config = self._init_proxy(config.get("proxy", {}))
        
        # Browser instance storage
        self._current_user_agent: Optional[str] = None
        self._current_viewport: Optional[ViewportConfig] = None
        
        logger.info("[STEALTH] Controller initialized - Anti-detection: %s", 
                    "ENABLED" if self.enabled else "DISABLED")

    def _init_proxy(self, proxy_config: Dict[str, Any]) -> Optional[ProxyConfig]:
        """Initialize proxy configuration."""
        if not proxy_config.get("enabled", False):
            return None
        return ProxyConfig(
            enabled=True,
            type=proxy_config.get("type", "socks5"),
            host=proxy_config.get("host", "127.0.0.1"),
            port=proxy_config.get("port", 1080),
            username=proxy_config.get("username") or None,
            password=proxy_config.get("password") or None,
        )

    def get_random_user_agent(self) -> str:
        """Get random user agent string."""
        self._current_user_agent = random.choice(self.USER_AGENTS)
        return self._current_user_agent

    def get_random_viewport(self) -> ViewportConfig:
        """Get random viewport configuration."""
        self._current_viewport = random.choice(self.VIEWPORTS)
        return self._current_viewport

    async def human_like_mouse_move(
        self, 
        page: Any, 
        target_x: int, 
        target_y: int,
        duration: Optional[float] = None
    ) -> None:
        """
        Move mouse to target using bezier curve for human-like movement.
        
        Args:
            page: Playwright page object
            target_x: Target X coordinate
            target_y: Target Y coordinate
            duration: Movement duration in seconds (random if None)
        """
        if not self.enabled:
            await page.mouse.move(target_x, target_y)
            return

        # Get current mouse position
        try:
            current_pos = await page.evaluate("""
                () => {
                    const elem = document.querySelector(':hover');
                    return { x: window.lastMouseX || 0, y: window.lastMouseY || 0 };
                }
            """)
            start_x, start_y = current_pos.get("x", 0), current_pos.get("y", 0)
        except:
            start_x, start_y = random.randint(100, 500), random.randint(100, 500)

        # Random duration if not specified
        if duration is None:
            distance = np.sqrt((target_x - start_x)**2 + (target_y - start_y)**2)
            speed = random.uniform(*self.mouse_speed_range)
            duration = distance / (speed * 500)  # pixels per second
            duration = max(0.2, min(duration, 2.0))  # clamp between 0.2-2s

        # Generate bezier curve points
        points = self._generate_bezier_points(
            (start_x, start_y), (target_x, target_y), num_points=20
        )

        # Move through points with slight randomization
        step_delay = duration / len(points)
        for x, y in points:
            # Add micro-jitter
            jitter_x = x + random.randint(-2, 2)
            jitter_y = y + random.randint(-2, 2)
            await page.mouse.move(jitter_x, jitter_y)
            await asyncio.sleep(step_delay + random.uniform(-0.01, 0.01))

    def _generate_bezier_points(
        self, 
        start: Tuple[int, int], 
        end: Tuple[int, int], 
        num_points: int = 20
    ) -> List[Tuple[int, int]]:
        """
        Generate points along a quadratic bezier curve.
        
        Args:
            start: Starting point (x, y)
            end: Ending point (x, y)
            num_points: Number of points to generate
            
        Returns:
            List of (x, y) points
        """
        # Control point with random offset for organic curve
        mid_x = (start[0] + end[0]) / 2
        mid_y = (start[1] + end[1]) / 2
        
        # Random offset for control point
        offset_range = abs(end[0] - start[0]) * 0.3
        control_x = mid_x + random.uniform(-offset_range, offset_range)
        control_y = mid_y + random.uniform(-offset_range, offset_range)
        
        t_values = np.linspace(0, 1, num_points)
        points = []
        
        for t in t_values:
            # Quadratic bezier formula
            x = (1-t)**2 * start[0] + 2*(1-t)*t * control_x + t**2 * end[0]
            y = (1-t)**2 * start[1] + 2*(1-t)*t * control_y + t**2 * end[1]
            points.append((int(x), int(y)))
        
        return points

    async def human_like_typing(
        self, 
        page: Any, 
        selector: str, 
        text: str,
        error_rate: Optional[float] = None
    ) -> None:
        """
        Type text with human-like speed and occasional errors.
        
        Args:
            page: Playwright page object
            selector: Input element selector
            text: Text to type
            error_rate: Chance of making a typo (default from config)
        """
        if not self.enabled:
            await page.fill(selector, text)
            return

        error_rate = error_rate or self.typing_error_rate
        
        # Calculate typing speed
        wpm = random.randint(*self.typing_wpm_range)
        chars_per_minute = wpm * 5  # average word length
        base_delay = 60.0 / chars_per_minute

        # Focus the element
        await page.click(selector)
        await asyncio.sleep(random.uniform(0.1, 0.3))

        typed = ""
        for char in text:
            # Occasional typo
            if random.random() < error_rate and char.isalpha():
                # Type wrong character
                wrong_char = random.choice("abcdefghijklmnopqrstuvwxyz")
                await page.keyboard.type(wrong_char, delay=base_delay * random.uniform(0.8, 1.2))
                await asyncio.sleep(random.uniform(0.1, 0.3))
                
                # Backspace to correct
                await page.keyboard.press("Backspace")
                await asyncio.sleep(random.uniform(0.05, 0.15))
            
            # Type correct character
            await page.keyboard.type(char, delay=base_delay * random.uniform(0.7, 1.3))
            
            # Random pause between words
            if char == " ":
                await asyncio.sleep(random.uniform(0.1, 0.4))
            
            typed += char

    async def random_delay(self, min_sec: Optional[float] = None, max_sec: Optional[float] = None) -> None:
        """
        Wait for random duration.
        
        Args:
            min_sec: Minimum seconds
            max_sec: Maximum seconds
        """
        min_sec = min_sec or self.action_delay[0]
        max_sec = max_sec or self.action_delay[1]
        delay = random.uniform(min_sec, max_sec)
        await asyncio.sleep(delay)

    async def page_load_wait(self) -> None:
        """Wait random duration after page load."""
        delay = random.uniform(*self.page_load_delay)
        await asyncio.sleep(delay)

    def get_browser_context_options(self) -> Dict[str, Any]:
        """
        Get Playwright browser context options with stealth measures.
        
        Returns:
            Dictionary of browser context options
        """
        options: Dict[str, Any] = {
            "viewport": self.get_random_viewport().dict,
            "user_agent": self.get_random_user_agent(),
            "locale": random.choice(["en-US", "en-GB", "en-CA"]),
            "timezone_id": random.choice([
                "America/New_York", "America/Chicago", "America/Los_Angeles",
                "Europe/London", "Europe/Paris", "Asia/Tokyo",
            ]),
            "permissions": [],
            "java_script_enabled": True,
        }

        # Add proxy if configured
        if self.proxy_config:
            options["proxy"] = {
                "server": self.proxy_config.server,
            }
            if self.proxy_config.username:
                options["proxy"]["username"] = self.proxy_config.username
            if self.proxy_config.password:
                options["proxy"]["password"] = self.proxy_config.password

        return options

    async def apply_stealth_scripts(self, page: Any) -> None:
        """
        Apply stealth JavaScript patches to page.
        
        Args:
            page: Playwright page object
        """
        if not self.enabled:
            return

        stealth_scripts = [
            # WebGL noise
            """
            () => {
                const getParameter = WebGLRenderingContext.prototype.getParameter;
                WebGLRenderingContext.prototype.getParameter = function(parameter) {
                    if (parameter === 37445) {
                        return 'Intel Inc.';
                    }
                    if (parameter === 37446) {
                        return 'Intel Iris OpenGL Engine';
                    }
                    return getParameter(parameter);
                };
            }
            """,
            # Canvas noise
            """
            () => {
                const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
                const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
                
                const noise = () => {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    const imageData = ctx.getImageData(0, 0, 1, 1);
                    imageData.data[0] = imageData.data[0] + (Math.random() > 0.5 ? 1 : -1);
                    ctx.putImageData(imageData, 0, 0);
                };
            }
            """,
            # Plugin spoofing
            """
            () => {
                Object.defineProperty(navigator, 'plugins', {
                    get: function() {
                        return [
                            {
                                name: 'Chrome PDF Plugin',
                                filename: 'internal-pdf-viewer',
                                description: 'Portable Document Format',
                                version: 'undefined',
                                length: 1,
                                item: function() { return this[0]; },
                                namedItem: function() { return null; }
                            }
                        ];
                    }
                });
            }
            """,
            # WebRTC disable
            """
            () => {
                const wrtc = window.RTCPeerConnection || window.webkitRTCPeerConnection;
                if (wrtc) {
                    window.RTCPeerConnection = function() { return null; };
                    window.webkitRTCPeerConnection = function() { return null; };
                }
            }
            """,
            # Navigator properties
            """
            () => {
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => false,
                });
                Object.defineProperty(navigator, 'chrome', {
                    get: () => ({ runtime: {} }),
                });
                window.navigator.chrome = { runtime: {} };
            }
            """,
            # Permissions API
            """
            () => {
                const originalQuery = window.navigator.permissions.query;
                window.navigator.permissions.query = (parameters) => (
                    parameters.name === 'notifications' 
                        ? Promise.resolve({ state: Notification.permission })
                        : originalQuery(parameters)
                );
            }
            """,
        ]

        for script in stealth_scripts:
            try:
                await page.evaluate(script)
            except Exception as e:
                logger.debug("[STEALTH] Script injection note: %s", e)

        logger.info("[STEALTH] Anti-detection scripts applied")

    async def human_like_scroll(self, page: Any, direction: str = "down", amount: Optional[int] = None) -> None:
        """
        Scroll page with human-like behavior.
        
        Args:
            page: Playwright page object
            direction: 'up' or 'down'
            amount: Pixels to scroll (random if None)
        """
        if not self.enabled:
            await page.evaluate(f"window.scrollBy(0, {500 if direction == 'down' else -500})")
            return

        if amount is None:
            amount = random.randint(200, 800)
        
        if direction == "up":
            amount = -amount

        # Break scroll into chunks
        chunks = random.randint(3, 8)
        chunk_size = amount // chunks
        
        for _ in range(chunks):
            jitter = random.randint(-20, 20)
            await page.evaluate(f"window.scrollBy(0, {chunk_size + jitter})")
            await asyncio.sleep(random.uniform(0.1, 0.3))

    def get_proxy_rotation_list(self) -> List[ProxyConfig]:
        """
        Get list of proxies for rotation.
        Override this method to implement proxy rotation.
        
        Returns:
            List of proxy configurations
        """
        if self.proxy_config:
            return [self.proxy_config]
        return []

    async def simulate_reading_time(self, page: Any) -> None:
        """
        Simulate human reading time based on page content.
        
        Args:
            page: Playwright page object
        """
        try:
            text_length = await page.evaluate("() => document.body.innerText.length")
            # Average reading speed: 200-300 chars per minute
            reading_speed = random.randint(200, 300)
            read_time = min(text_length / reading_speed, 30)  # max 30 seconds
            await asyncio.sleep(read_time)
        except:
            await asyncio.sleep(random.uniform(3, 10))

    def generate_mouse_trail(self, points: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
        """
        Generate natural mouse trail between points.
        
        Args:
            points: List of (x, y) waypoints
            
        Returns:
            Smoothed trail points
        """
        if len(points) < 2:
            return points
        
        trail = []
        for i in range(len(points) - 1):
            segment = self._generate_bezier_points(
                points[i], points[i + 1], num_points=10
            )
            trail.extend(segment)
        
        return trail
