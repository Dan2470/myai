"""
CIPHERX-NEXUS SECURITY MODULE
Handles authentication, 2FA, command sanitization, and access control.
Iron-clad security with hardcoded Telegram User-ID lockdown.
"""

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import time
from datetime import datetime, timedelta
from enum import Enum
from functools import wraps
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


class AuthLevel(Enum):
    """Authorization levels for command execution."""
    UNAUTHORIZED = 0
    AUTHENTICATED = 1
    PRIVILEGED = 2  # Requires master password


class SecurityManager:
    """
    Iron-clad security manager for CipherX-Nexus.
    
    Features:
    - Hardcoded Telegram User-ID whitelist (8244634415)
    - Master password 2FA for high-risk operations
    - Command sanitization and validation
    - Session management with timeout
    - Rate limiting and brute-force protection
    """

    # === HARDCODED SECURITY CONSTANTS ===
    AUTHORIZED_USER_ID: int = 8244634415
    _MASTER_PASSWORD_HASH: Optional[str] = None
    _PASSWORD_SALT: Optional[str] = None

    # Risk levels for commands
    HIGH_RISK_COMMANDS: Set[str] = {
        "shell", "exec", "run", "delete", "remove", "drop",
        "format", "fdisk", "mkfs", "dd", "del",
        "sqlmap", "nmap -o", "dirsearch -o",
        "chmod 777", "chown -R", "rm -rf",
        "docker system prune", "kill", "pkill",
        "iptables -F", "ufw --reset",
    }

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize security manager with configuration.
        
        Args:
            config: Security section from config.json
        """
        self.config = config
        self._sessions: Dict[int, Dict[str, Any]] = {}
        self._failed_attempts: Dict[int, List[float]] = {}
        self._authenticated_users: Set[int] = set()
        self._privileged_sessions: Set[int] = set()
        self._command_history: List[Dict[str, Any]] = []
        
        # Initialize master password
        self._init_master_password()
        
        # Load allowed/blocked commands from config
        self.allowed_commands: Set[str] = set(config.get("allowed_shell_commands", []))
        self.blocked_commands: Set[str] = set(config.get("blocked_commands", []))
        
        # Rate limiting config
        self.max_login_attempts: int = config.get("max_login_attempts", 3)
        self.lockout_duration: int = config.get("lockout_duration_minutes", 60)
        self.session_timeout: int = config.get("session_timeout_minutes", 30)
        
        logger.info("[SECURITY] SecurityManager initialized - Authorization locked to User-ID: %s", 
                    self.AUTHORIZED_USER_ID)

    def _init_master_password(self) -> None:
        """Initialize master password from config or environment."""
        password = self.config.get("master_password_plaintext", "")
        if not password or password == "CHANGE_THIS_TO_A_STRONG_PASSWORD":
            password = os.environ.get("NEXUS_MASTER_PASSWORD", "")
        
        if password:
            self._PASSWORD_SALT = secrets.token_hex(32)
            self._MASTER_PASSWORD_HASH = self._hash_password(password, self._PASSWORD_SALT)
            logger.info("[SECURITY] Master password initialized")
        else:
            logger.warning("[SECURITY] No master password set - high-risk commands will be blocked")

    def _hash_password(self, password: str, salt: str) -> str:
        """Create secure password hash using PBKDF2."""
        return hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            100000  # 100k iterations
        ).hex()

    def _verify_password(self, password: str) -> bool:
        """Verify master password against stored hash."""
        if not self._MASTER_PASSWORD_HASH or not self._PASSWORD_SALT:
            return False
        attempt_hash = self._hash_password(password, self._PASSWORD_SALT)
        return hmac.compare_digest(attempt_hash, self._MASTER_PASSWORD_HASH)

    def verify_telegram_user(self, user_id: int) -> bool:
        """
        Verify if Telegram user is authorized.
        HARDCODED: Only user ID 8244634415 is authorized.
        
        Args:
            user_id: Telegram user ID to verify
            
        Returns:
            True if authorized, False otherwise
        """
        if user_id == self.AUTHORIZED_USER_ID:
            self._authenticated_users.add(user_id)
            logger.info("[SECURITY] Authorized user %s authenticated", user_id)
            return True
        
        logger.warning("[SECURITY] UNAUTHORIZED ACCESS ATTEMPT from User-ID: %s", user_id)
        return False

    def is_authenticated(self, user_id: int) -> bool:
        """Check if user is currently authenticated."""
        return user_id in self._authenticated_users

    def authenticate_with_password(self, user_id: int, password: str) -> Tuple[bool, str]:
        """
        2FA authentication with master password.
        
        Args:
            user_id: Telegram user ID
            password: Master password attempt
            
        Returns:
            Tuple of (success, message)
        """
        # First verify Telegram user
        if not self.verify_telegram_user(user_id):
            return False, "ACCESS DENIED: Unauthorized User-ID"
        
        # Check for lockout
        if self._is_locked_out(user_id):
            remaining = self._get_lockout_remaining(user_id)
            return False, f"Account locked. Try again in {remaining} minutes."
        
        # Verify password
        if self._verify_password(password):
            self._privileged_sessions.add(user_id)
            self._record_successful_auth(user_id)
            logger.info("[SECURITY] User %s elevated to PRIVILEGED access", user_id)
            return True, "2FA Successful. Privileged access granted."
        else:
            self._record_failed_attempt(user_id)
            remaining = self.max_login_attempts - len(self._failed_attempts.get(user_id, []))
            return False, f"Authentication failed. {remaining} attempts remaining."

    def _is_locked_out(self, user_id: int) -> bool:
        """Check if user is currently locked out."""
        attempts = self._failed_attempts.get(user_id, [])
        if len(attempts) >= self.max_login_attempts:
            last_attempt = attempts[-1]
            lockout_end = last_attempt + (self.lockout_duration * 60)
            return time.time() < lockout_end
        return False

    def _get_lockout_remaining(self, user_id: int) -> int:
        """Get remaining lockout time in minutes."""
        attempts = self._failed_attempts.get(user_id, [])
        if attempts:
            last_attempt = attempts[-1]
            lockout_end = last_attempt + (self.lockout_duration * 60)
            remaining = int((lockout_end - time.time()) / 60)
            return max(0, remaining)
        return 0

    def _record_failed_attempt(self, user_id: int) -> None:
        """Record a failed authentication attempt."""
        now = time.time()
        attempts = self._failed_attempts.get(user_id, [])
        attempts.append(now)
        self._failed_attempts[user_id] = attempts

    def _record_successful_auth(self, user_id: int) -> None:
        """Clear failed attempts on successful auth."""
        self._failed_attempts.pop(user_id, None)

    def has_privileged_access(self, user_id: int) -> bool:
        """Check if user has privileged (2FA) access."""
        return user_id in self._privileged_sessions

    def require_privileged(func):
        """Decorator to require privileged access for a method."""
        @wraps(func)
        async def wrapper(self, user_id: int, *args, **kwargs):
            if not self.has_privileged_access(user_id):
                return {"status": "error", "message": "2FA required. Use /auth <password>"}
            return await func(self, user_id, *args, **kwargs)
        return wrapper

    def sanitize_shell_command(self, command: str) -> Tuple[bool, str, List[str]]:
        """
        Sanitize and validate shell command.
        
        Args:
            command: Raw shell command string
            
        Returns:
            Tuple of (is_valid, sanitized_command, warnings)
        """
        warnings: List[str] = []
        original = command.strip()
        
        # Check for blocked command patterns
        for blocked in self.blocked_commands:
            if blocked.lower() in original.lower():
                warnings.append(f"BLOCKED: Dangerous pattern detected: '{blocked}'")
                return False, "", warnings
        
        # Extract base command
        parts = original.split()
        if not parts:
            warnings.append("Empty command")
            return False, "", warnings
        
        base_cmd = parts[0].lower()
        
        # Check if command is in allowed list
        if self.allowed_commands and base_cmd not in self.allowed_commands:
            warnings.append(f"Command '{base_cmd}' not in allowed commands list")
            return False, "", warnings
        
        # Sanitize the command
        sanitized = self._sanitize_string(original)
        
        # Check for injection attempts
        injection_patterns = [
            r"[;&|]\s*rm\s",
            r"\$\(.*?\)",
            r"`.*?`",
            r"\|\s*sh\s*$",
            r"\|\s*bash\s*$",
            r">\s*/dev/[sh]da",
            r"curl.*?\|\s*sh",
            r"wget.*?\|\s*sh",
        ]
        
        for pattern in injection_patterns:
            if re.search(pattern, sanitized, re.IGNORECASE):
                warnings.append(f"BLOCKED: Potential command injection detected")
                return False, "", warnings
        
        # Check for high-risk patterns
        high_risk_patterns = [
            (r"rm\s+-rf\s+/", "Recursive root deletion"),
            (r"mkfs\.\w+\s+/dev/", "Filesystem formatting"),
            (r"dd\s+if=\w+\s+of=/dev/", "Direct disk write"),
            (r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:", "Fork bomb"),
        ]
        
        for pattern, description in high_risk_patterns:
            if re.search(pattern, sanitized):
                warnings.append(f"BLOCKED HIGH-RISK: {description}")
                return False, "", warnings
        
        logger.info("[SECURITY] Command sanitized: %s", sanitized)
        return True, sanitized, warnings

    def _sanitize_string(self, input_str: str) -> str:
        """Sanitize input string to prevent injection."""
        # Remove null bytes
        sanitized = input_str.replace("\x00", "")
        # Remove control characters except newlines
        sanitized = "".join(char for char in sanitized if char == "\n" or ord(char) >= 32)
        return sanitized.strip()

    def is_high_risk_command(self, command: str) -> bool:
        """
        Determine if a command requires 2FA authorization.
        
        Args:
            command: Command string to evaluate
            
        Returns:
            True if high-risk
        """
        command_lower = command.lower()
        
        # Check against high-risk command set
        for pattern in self.HIGH_RISK_COMMANDS:
            if pattern.lower() in command_lower:
                return True
        
        # Check for destructive operations
        destructive_patterns = [
            r"\brm\b.*?-r.*?/(?!tmp|home|var/www)",
            r"\bchmod\b.*?777",
            r"\bformat\b",
            r"\bdd\b.*?if=.*?of=/dev",
            r"\bmv\b.*?/dev/null",
        ]
        
        for pattern in destructive_patterns:
            if re.search(pattern, command_lower):
                return True
        
        return False

    def validate_file_path(self, file_path: str) -> Tuple[bool, str]:
        """
        Validate file path is within allowed directories.
        
        Args:
            file_path: Path to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        allowed_prefixes = [
            "/home/",
            "/var/www/",
            "/opt/",
            "/tmp/",
            os.path.expanduser("~"),
            os.path.abspath("."),
        ]
        
        resolved = os.path.abspath(os.path.expanduser(file_path))
        
        for prefix in allowed_prefixes:
            if resolved.startswith(os.path.abspath(prefix)):
                return True, ""
        
        return False, f"Path '{file_path}' is outside allowed directories"

    def generate_secure_token(self, length: int = 32) -> str:
        """Generate cryptographically secure random token."""
        return secrets.token_urlsafe(length)

    def hash_sensitive_data(self, data: str) -> str:
        """Hash sensitive data for storage."""
        salt = secrets.token_hex(16)
        hash_value = hashlib.sha256((data + salt).encode()).hexdigest()
        return f"{salt}${hash_value}"

    def audit_log(self, user_id: int, action: str, details: Dict[str, Any]) -> None:
        """
        Log security-relevant actions.
        
        Args:
            user_id: User who performed action
            action: Action description
            details: Additional details
        """
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "action": action,
            "details": details,
        }
        self._command_history.append(entry)
        logger.info("[AUDIT] User %s: %s - %s", user_id, action, json.dumps(details))

    def get_audit_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent audit log entries."""
        return self._command_history[-limit:]

    def revoke_session(self, user_id: int) -> None:
        """Revoke user session and privileged access."""
        self._authenticated_users.discard(user_id)
        self._privileged_sessions.discard(user_id)
        self._sessions.pop(user_id, None)
        logger.info("[SECURITY] Session revoked for user %s", user_id)

    def cleanup_expired_sessions(self) -> None:
        """Remove expired sessions."""
        now = time.time()
        expired = []
        
        for user_id, session in self._sessions.items():
            last_active = session.get("last_active", 0)
            if now - last_active > (self.session_timeout * 60):
                expired.append(user_id)
        
        for user_id in expired:
            self.revoke_session(user_id)
            
        if expired:
            logger.info("[SECURITY] Cleaned up %d expired sessions", len(expired))

    def encrypt_config_values(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Encrypt sensitive configuration values.
        
        Args:
            config: Configuration dictionary
            
        Returns:
            Config with encrypted sensitive values
        """
        sensitive_keys = {"password", "api_key", "api_secret", "token", "secret"}
        encrypted = {}
        
        for key, value in config.items():
            if any(sk in key.lower() for sk in sensitive_keys) and isinstance(value, str):
                encrypted[key] = f"ENC:{self.hash_sensitive_data(value)}"
            elif isinstance(value, dict):
                encrypted[key] = self.encrypt_config_values(value)
            else:
                encrypted[key] = value
        
        return encrypted


# Singleton instance
_security_manager: Optional[SecurityManager] = None


def get_security_manager(config: Optional[Dict[str, Any]] = None) -> SecurityManager:
    """Get or create SecurityManager singleton."""
    global _security_manager
    if _security_manager is None:
        if config is None:
            raise ValueError("SecurityManager requires config on first initialization")
        _security_manager = SecurityManager(config)
    return _security_manager
