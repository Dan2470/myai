"""
CIPHERX-NEXUS EMAIL HANDLER MODULE
Full IMAP/SMTP support for email reading, summarization, and replies.
Executive assistant email capabilities with business-grade features.
"""

import asyncio
import email
import hashlib
import imaplib
import json
import logging
import re
import smtplib
from datetime import datetime, timedelta
from email.header import decode_header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import aiosmtplib

logger = logging.getLogger(__name__)


class EmailMessage:
    """Represents a parsed email message."""

    def __init__(
        self,
        uid: str,
        subject: str,
        sender: str,
        recipient: str,
        date: datetime,
        body: str,
        html_body: Optional[str] = None,
        attachments: Optional[List[Dict[str, Any]]] = None,
        flags: Optional[List[str]] = None,
        folder: str = "INBOX",
    ):
        self.uid = uid
        self.subject = subject
        self.sender = sender
        self.recipient = recipient
        self.date = date
        self.body = body
        self.html_body = html_body
        self.attachments = attachments or []
        self.flags = flags or []
        self.folder = folder
        self.is_read = "\\Seen" in (flags or [])

    @property
    def summary(self) -> str:
        """Get human-readable summary."""
        preview = self.body[:200] + "..." if len(self.body) > 200 else self.body
        return (
            f"From: {self.sender}\n"
            f"Subject: {self.subject}\n"
            f"Date: {self.date.strftime('%Y-%m-%d %H:%M')}\n"
            f"Preview: {preview}\n"
            f"Attachments: {len(self.attachments)}"
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "uid": self.uid,
            "subject": self.subject,
            "sender": self.sender,
            "recipient": self.recipient,
            "date": self.date.isoformat(),
            "body": self.body,
            "html_body": self.html_body,
            "attachments": self.attachments,
            "is_read": self.is_read,
            "folder": self.folder,
        }


class EmailHandler:
    """
    Executive Assistant Email Handler.
    
    Features:
    - IMAP email fetching with folder management
    - SMTP email sending with HTML/Text support
    - Email summarization and analysis
    - Attachment handling
    - Automatic reply suggestions
    - Email threading
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize email handler.
        
        Args:
            config: Email configuration section from config.json
        """
        self.config = config
        self.imap_config = config.get("imap", {})
        self.smtp_config = config.get("smtp", {})
        
        # Connection pools
        self._imap_connection: Optional[imaplib.IMAP4_SSL] = None
        self._smtp_connection: Optional[smtplib.SMTP] = None
        self._last_imap_activity: float = 0
        self._connection_timeout: int = 300  # 5 minutes
        
        # Cache
        self._email_cache: Dict[str, List[EmailMessage]] = {}
        self._cache_ttl: int = 300  # 5 minutes
        
        logger.info("[EMAIL] Handler initialized - IMAP: %s, SMTP: %s",
                    self.imap_config.get("server", "N/A"),
                    self.smtp_config.get("server", "N/A"))

    async def connect_imap(self) -> bool:
        """
        Establish IMAP connection.
        
        Returns:
            True if connected successfully
        """
        try:
            if not self.imap_config.get("enabled", False):
                logger.warning("[EMAIL] IMAP not enabled in config")
                return False

            # Close existing connection if stale
            if self._imap_connection:
                try:
                    self._imap_connection.close()
                    self._imap_connection.logout()
                except:
                    pass
                self._imap_connection = None

            server = self.imap_config["server"]
            port = self.imap_config.get("port", 993)
            use_ssl = self.imap_config.get("use_ssl", True)
            username = self.imap_config["username"]
            password = self.imap_config["password"]

            if use_ssl:
                self._imap_connection = imaplib.IMAP4_SSL(server, port)
            else:
                self._imap_connection = imaplib.IMAP4(server, port)

            self._imap_connection.login(username, password)
            self._last_imap_activity = datetime.now().timestamp()
            
            logger.info("[EMAIL] IMAP connected to %s", server)
            return True

        except Exception as e:
            logger.error("[EMAIL] IMAP connection failed: %s", e)
            self._imap_connection = None
            return False

    async def connect_smtp(self) -> bool:
        """
        Establish SMTP connection.
        
        Returns:
            True if connected successfully
        """
        try:
            server = self.smtp_config["server"]
            port = self.smtp_config.get("port", 587)
            use_tls = self.smtp_config.get("use_tls", True)
            username = self.smtp_config["username"]
            password = self.smtp_config["password"]

            self._smtp_connection = smtplib.SMTP(server, port)
            
            if use_tls:
                self._smtp_connection.starttls()
            
            self._smtp_connection.login(username, password)
            
            logger.info("[EMAIL] SMTP connected to %s", server)
            return True

        except Exception as e:
            logger.error("[EMAIL] SMTP connection failed: %s", e)
            self._smtp_connection = None
            return False

    async def fetch_emails(
        self,
        folder: str = "INBOX",
        limit: int = 50,
        unread_only: bool = False,
        since: Optional[datetime] = None,
    ) -> List[EmailMessage]:
        """
        Fetch emails from IMAP server.
        
        Args:
            folder: Mailbox folder to fetch from
            limit: Maximum number of emails
            unread_only: Only fetch unread emails
            since: Only fetch emails since this date
            
        Returns:
            List of EmailMessage objects
        """
        try:
            if not self._imap_connection:
                if not await self.connect_imap():
                    return []

            conn = self._imap_connection
            
            # Select folder
            status, _ = conn.select(folder)
            if status != "OK":
                logger.error("[EMAIL] Failed to select folder: %s", folder)
                return []

            # Build search criteria
            search_criteria = ["ALL"]
            
            if unread_only:
                search_criteria = ["UNSEEN"]
            
            if since:
                date_str = since.strftime("%d-%b-%Y")
                search_criteria.append(f"SINCE {date_str}")

            search_query = " ".join(search_criteria) if len(search_criteria) > 1 else search_criteria[0]
            
            status, messages = conn.search(None, search_query)
            if status != "OK":
                return []

            email_ids = messages[0].split()
            
            # Get most recent emails
            email_ids = email_ids[-limit:] if len(email_ids) > limit else email_ids
            
            emails = []
            for eid in reversed(email_ids):
                try:
                    status, msg_data = conn.fetch(eid, "(RFC822)")
                    if status != "OK" or not msg_data or not msg_data[0]:
                        continue

                    raw_email = msg_data[0][1]
                    email_msg = self._parse_email(raw_email, eid.decode(), folder)
                    if email_msg:
                        emails.append(email_msg)
                except Exception as e:
                    logger.debug("[EMAIL] Error parsing email %s: %s", eid, e)
                    continue

            self._last_imap_activity = datetime.now().timestamp()
            logger.info("[EMAIL] Fetched %d emails from %s", len(emails), folder)
            return emails

        except Exception as e:
            logger.error("[EMAIL] Fetch failed: %s", e)
            # Try to reconnect on next call
            self._imap_connection = None
            return []

    def _parse_email(self, raw_email: bytes, uid: str, folder: str) -> Optional[EmailMessage]:
        """
        Parse raw email bytes into EmailMessage.
        
        Args:
            raw_email: Raw email bytes
            uid: Email UID
            folder: Source folder
            
        Returns:
            Parsed EmailMessage or None
        """
        try:
            msg = email.message_from_bytes(raw_email)
            
            # Decode subject
            subject = self._decode_header_value(msg.get("Subject", "No Subject"))
            
            # Decode sender
            sender = self._decode_header_value(msg.get("From", "Unknown"))
            
            # Decode recipient
            recipient = self._decode_header_value(msg.get("To", "Unknown"))
            
            # Parse date
            date_str = msg.get("Date", "")
            try:
                date = email.utils.parsedate_to_datetime(date_str)
            except:
                date = datetime.now()

            # Extract body
            body, html_body = self._extract_body(msg)
            
            # Extract attachments info
            attachments = self._extract_attachments_info(msg)

            return EmailMessage(
                uid=uid,
                subject=subject,
                sender=sender,
                recipient=recipient,
                date=date,
                body=body,
                html_body=html_body,
                attachments=attachments,
                folder=folder,
            )

        except Exception as e:
            logger.error("[EMAIL] Parse error: %s", e)
            return None

    def _decode_header_value(self, value: str) -> str:
        """Decode MIME-encoded header value."""
        try:
            decoded_parts = decode_header(value)
            result = []
            for part, charset in decoded_parts:
                if isinstance(part, bytes):
                    result.append(part.decode(charset or "utf-8", errors="replace"))
                else:
                    result.append(part)
            return "".join(result)
        except:
            return value

    def _extract_body(self, msg: email.message.EmailMessage) -> Tuple[str, Optional[str]]:
        """
        Extract text and HTML body from email.
        
        Returns:
            Tuple of (text_body, html_body)
        """
        text_body = ""
        html_body = None

        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get("Content-Disposition", ""))

                if "attachment" not in content_disposition:
                    try:
                        payload = part.get_payload(decode=True)
                        if payload:
                            charset = part.get_content_charset() or "utf-8"
                            decoded = payload.decode(charset, errors="replace")
                            
                            if content_type == "text/plain":
                                text_body = decoded
                            elif content_type == "text/html":
                                html_body = decoded
                    except:
                        continue
        else:
            try:
                payload = msg.get_payload(decode=True)
                if payload:
                    charset = msg.get_content_charset() or "utf-8"
                    text_body = payload.decode(charset, errors="replace")
            except:
                text_body = str(msg.get_payload())

        return text_body, html_body

    def _extract_attachments_info(self, msg: email.message.EmailMessage) -> List[Dict[str, Any]]:
        """Extract attachment information from email."""
        attachments = []
        
        if msg.is_multipart():
            for part in msg.walk():
                content_disposition = str(part.get("Content-Disposition", ""))
                if "attachment" in content_disposition:
                    filename = part.get_filename() or "unnamed"
                    attachments.append({
                        "filename": filename,
                        "size": len(part.get_payload(decode=True) or b""),
                        "content_type": part.get_content_type(),
                    })
        
        return attachments

    async def send_email(
        self,
        to_address: str,
        subject: str,
        body: str,
        html_body: Optional[str] = None,
        cc: Optional[List[str]] = None,
        bcc: Optional[List[str]] = None,
        reply_to: Optional[str] = None,
    ) -> bool:
        """
        Send email via SMTP.
        
        Args:
            to_address: Primary recipient
            subject: Email subject
            body: Plain text body
            html_body: Optional HTML body
            cc: CC recipients
            bcc: BCC recipients
            reply_to: Reply-to address
            
        Returns:
            True if sent successfully
        """
        try:
            if not self._smtp_connection:
                if not await self.connect_smtp():
                    return False

            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{self.smtp_config.get('from_name', 'CipherX')} <{self.smtp_config['username']}>"
            msg["To"] = to_address
            
            if cc:
                msg["Cc"] = ", ".join(cc)
            if reply_to:
                msg["Reply-To"] = reply_to

            # Attach text body
            msg.attach(MIMEText(body, "plain"))
            
            # Attach HTML body if provided
            if html_body:
                msg.attach(MIMEText(html_body, "html"))

            recipients = [to_address]
            if cc:
                recipients.extend(cc)
            if bcc:
                recipients.extend(bcc)

            self._smtp_connection.sendmail(
                self.smtp_config["username"],
                recipients,
                msg.as_string(),
            )

            logger.info("[EMAIL] Sent email to %s: %s", to_address, subject)
            return True

        except Exception as e:
            logger.error("[EMAIL] Send failed: %s", e)
            self._smtp_connection = None
            return False

    async def send_reply(
        self,
        original_email: EmailMessage,
        reply_body: str,
        reply_html: Optional[str] = None,
    ) -> bool:
        """
        Send reply to an existing email.
        
        Args:
            original_email: Email being replied to
            reply_body: Reply text body
            reply_html: Optional reply HTML body
            
        Returns:
            True if sent successfully
        """
        subject = original_email.subject
        if not subject.startswith("Re:"):
            subject = f"Re: {subject}"

        # Quote original message
        quoted_original = ">> ".join(
            f"> {line}" for line in original_email.body.split("\n")
        )
        full_body = f"{reply_body}\n\nOn {original_email.date.strftime('%Y-%m-%d %H:%M')}, {original_email.sender} wrote:\n{quoted_original}"

        return await self.send_email(
            to_address=original_email.sender,
            subject=subject,
            body=full_body,
            html_body=reply_html,
            reply_to=original_email.recipient,
        )

    async def summarize_emails(self, emails: List[EmailMessage]) -> str:
        """
        Generate summary of multiple emails.
        
        Args:
            emails: List of emails to summarize
            
        Returns:
            Summary text
        """
        if not emails:
            return "No emails to summarize."

        unread_count = sum(1 for e in emails if not e.is_read)
        sender_counts: Dict[str, int] = {}
        
        for email_msg in emails:
            sender = email_msg.sender
            sender_counts[sender] = sender_counts.get(sender, 0) + 1

        summary = (
            f"Email Summary:\n"
            f"Total: {len(emails)} | Unread: {unread_count}\n"
            f"Date Range: {emails[-1].date.strftime('%Y-%m-%d')} to "
            f"{emails[0].date.strftime('%Y-%m-%d')}\n"
            f"\nTop Senders:\n"
        )
        
        for sender, count in sorted(sender_counts.items(), key=lambda x: -x[1])[:5]:
            summary += f"  - {sender}: {count} email(s)\n"

        # Recent unread emails
        recent_unread = [e for e in emails if not e.is_read][:5]
        if recent_unread:
            summary += "\nRecent Unread:\n"
            for e in recent_unread:
                preview = e.body[:100] + "..." if len(e.body) > 100 else e.body
                summary += f"  [{e.date.strftime('%H:%M')}] {e.sender}: {e.subject}\n"
                summary += f"    {preview}\n"

        return summary

    async def mark_as_read(self, uid: str, folder: str = "INBOX") -> bool:
        """Mark email as read."""
        try:
            if not self._imap_connection:
                await self.connect_imap()
            
            self._imap_connection.select(folder)
            self._imap_connection.store(uid, "+FLAGS", "\\Seen")
            return True
        except Exception as e:
            logger.error("[EMAIL] Mark as read failed: %s", e)
            return False

    async def delete_email(self, uid: str, folder: str = "INBOX") -> bool:
        """Move email to trash."""
        try:
            if not self._imap_connection:
                await self.connect_imap()
            
            self._imap_connection.select(folder)
            self._imap_connection.store(uid, "+FLAGS", "\\Deleted")
            self._imap_connection.expunge()
            return True
        except Exception as e:
            logger.error("[EMAIL] Delete failed: %s", e)
            return False

    async def move_to_folder(self, uid: str, source: str, destination: str) -> bool:
        """Move email between folders."""
        try:
            if not self._imap_connection:
                await self.connect_imap()
            
            self._imap_connection.select(source)
            
            # Copy to destination
            copy_result = self._imap_connection.uid("COPY", uid, destination)
            if copy_result[0] == "OK":
                # Mark original as deleted
                self._imap_connection.store(uid, "+FLAGS", "\\Deleted")
                self._imap_connection.expunge()
                return True
            return False
        except Exception as e:
            logger.error("[EMAIL] Move failed: %s", e)
            return False

    async def get_folders(self) -> List[str]:
        """Get list of available folders."""
        try:
            if not self._imap_connection:
                await self.connect_imap()
            
            status, folders = self._imap_connection.list()
            if status == "OK":
                folder_list = []
                for folder in folders:
                    # Parse folder name from response
                    parts = folder.decode().split(' "/" ')
                    if len(parts) >= 2:
                        folder_name = parts[-1].strip('"')
                        folder_list.append(folder_name)
                return folder_list
            return []
        except Exception as e:
            logger.error("[EMAIL] Get folders failed: %s", e)
            return []

    async def search_emails(
        self,
        query: str,
        folder: str = "INBOX",
        limit: int = 20,
    ) -> List[EmailMessage]:
        """
        Search emails by keyword.
        
        Args:
            query: Search query string
            folder: Folder to search
            limit: Max results
            
        Returns:
            Matching emails
        """
        try:
            if not self._imap_connection:
                await self.connect_imap()
            
            conn = self._imap_connection
            conn.select(folder)
            
            # Search in subject and body
            status, messages = conn.search(None, f'OR SUBJECT "{query}" BODY "{query}"')
            if status != "OK":
                return []
            
            email_ids = messages[0].split()[-limit:]
            
            emails = []
            for eid in reversed(email_ids):
                try:
                    status, msg_data = conn.fetch(eid, "(RFC822)")
                    if status == "OK" and msg_data and msg_data[0]:
                        email_msg = self._parse_email(msg_data[0][1], eid.decode(), folder)
                        if email_msg:
                            emails.append(email_msg)
                except:
                    continue
            
            return emails

        except Exception as e:
            logger.error("[EMAIL] Search failed: %s", e)
            return []

    async def disconnect(self) -> None:
        """Close all connections."""
        try:
            if self._imap_connection:
                self._imap_connection.close()
                self._imap_connection.logout()
                self._imap_connection = None
        except:
            pass

        try:
            if self._smtp_connection:
                self._smtp_connection.quit()
                self._smtp_connection = None
        except:
            pass

        logger.info("[EMAIL] Connections closed")

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.disconnect()
