#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                     CIPHERX-NEXUS ULTIMATE ORCHESTRATOR                      ║
║                     Production-Ready Autonomous Multi-Agent System             ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Author: CipherX-Nexus Team                                                  ║
║  Version: 1.0.0                                                              ║
║  License: Proprietary                                                        ║
╚══════════════════════════════════════════════════════════════════════════════╝

The Master Agent that orchestrates all sub-agents via Asyncio.
Features:
  - Telegram Bot API for 2-way control (User-ID locked: 8244634415)
  - Kimi 2.5 (Sonar) integration via OpenAI-compatible API
  - Sub-agent task delegation and monitoring
  - Persistent session management
  - Iron-clad security with 2FA
"""

import asyncio
import json
import logging
import os
import signal
import sys
import time
import traceback
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Third-party imports
import httpx
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# Internal modules
from utils.security import SecurityManager, AuthLevel
from utils.stealth import StealthController
from utils.email_handler import EmailHandler
from agents.base_agent import BaseAgent, Task, TaskPriority, AgentStatus
from agents.content_agent import ContentAgent
from agents.web_coding_agent import WebCodingAgent
from agents.security_agent import SecurityAgent
from social_engine import SocialEngine

# ═══════════════════════════════════════════════════════════════════════════════
# LOGGING CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

class ColoredFormatter(logging.Formatter):
    """Colored log formatter for terminal output."""
    
    COLORS = {
        "DEBUG": "\033[36m",      # Cyan
        "INFO": "\033[32m",       # Green
        "WARNING": "\033[33m",    # Yellow
        "ERROR": "\033[31m",      # Red
        "CRITICAL": "\033[35m",   # Magenta
        "RESET": "\033[0m",
    }

    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelname, self.COLORS["RESET"])
        record.levelname = f"{color}{record.levelname}{self.COLORS['RESET']}"
        return super().format(record)


def setup_logging(config: Dict[str, Any]) -> logging.Logger:
    """Configure logging with rotation and colors."""
    log_level = getattr(logging, config.get("log_level", "INFO"))
    log_file = config.get("log_file", "logs/nexus.log")
    max_size = config.get("max_log_size_mb", 100) * 1024 * 1024
    backup_count = config.get("log_backup_count", 5)
    
    # Ensure log directory exists
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)
    
    # Root logger
    logger = logging.getLogger()
    logger.setLevel(log_level)
    
    # Clear existing handlers
    logger.handlers = []
    
    # File handler with rotation
    from logging.handlers import RotatingFileHandler
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=max_size,
        backupCount=backup_count,
        encoding="utf-8",
    )
    file_handler.setLevel(log_level)
    file_format = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    file_handler.setFormatter(file_format)
    logger.addHandler(file_handler)
    
    # Console handler with colors
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_format = ColoredFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s",
        datefmt="%H:%M:%S",
    )
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)
    
    return logger


# ═══════════════════════════════════════════════════════════════════════════════
# MASTER ORCHESTRATOR CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class NexusOrchestrator:
    """
    CipherX-Nexus Master Orchestrator.
    
    The central brain that:
    - Manages all sub-agent lifecycles
    - Handles Telegram Bot commands and messages
    - Integrates with Kimi 2.5 (Sonar) AI for reasoning
    - Routes tasks to appropriate agents
    - Enforces security policies
    - Monitors system health
    """

    # HARDCODED AUTHORIZED USER ID - DO NOT MODIFY
    AUTHORIZED_USER_ID: int = 8244634415
    
    # Bot version
    VERSION: str = "1.0.0"

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the Nexus Orchestrator.
        
        Args:
            config: Full configuration dictionary from config.json
        """
        self.config = config
        self.start_time = datetime.now()
        
        # Setup logging
        self.logger = setup_logging(config.get("orchestrator", {}))
        self.logger.info("═" * 60)
        self.logger.info("  CIPHERX-NEXUS v%s INITIALIZING", self.VERSION)
        self.logger.info("═" * 60)
        
        # Initialize security (iron-clad)
        self.security = SecurityManager(config.get("security", {}))
        self.logger.info("[CORE] SecurityManager initialized - Lock: User-ID %s", 
                         self.AUTHORIZED_USER_ID)
        
        # Initialize stealth controller
        self.stealth = StealthController(config.get("stealth", {}))
        
        # Initialize email handler
        self.email = EmailHandler(config.get("email", {}))
        
        # Initialize social engine
        self.social = SocialEngine(config.get("social_media", {}), self.security)
        
        # Initialize sub-agents
        self.agents: Dict[str, BaseAgent] = {}
        self._init_agents()
        
        # AI Brain (Kimi 2.5 / Sonar)
        self.ai_config = config.get("ai_brain", {})
        self._ai_client: Optional[httpx.AsyncClient] = None
        
        # Telegram bot
        self.telegram_app: Optional[Application] = None
        self._telegram_config = config.get("telegram", {})
        
        # Task queues
        self._master_queue: asyncio.Queue = asyncio.Queue()
        self._shutdown_event = asyncio.Event()
        
        # System state
        self._system_status = "initializing"
        self._last_health_check = time.time()
        self._message_count = 0
        self._command_count = 0
        
        self.logger.info("[CORE] NexusOrchestrator initialization complete")

    def _init_agents(self) -> None:
        """Initialize all sub-agents."""
        agent_configs = {
            "content": (ContentAgent, "ContentAgent"),
            "web_coding": (WebCodingAgent, "WebCodingAgent"),
            "security": (SecurityAgent, "SecurityAgent"),
        }
        
        for key, (agent_class, name) in agent_configs.items():
            try:
                agent = agent_class(self.config, orchestrator=self)
                self.agents[name] = agent
                self.logger.info("[CORE] Agent registered: %s", name)
            except Exception as e:
                self.logger.error("[CORE] Failed to initialize %s: %s", name, e)

    async def initialize_ai_brain(self) -> bool:
        """
        Initialize AI brain connection (Kimi 2.5 / Sonar).
        
        Returns:
            True if AI brain is ready
        """
        try:
            self._ai_client = httpx.AsyncClient(
                base_url=self.ai_config.get("base_url", "https://api.moonshot.cn/v1"),
                headers={"Authorization": f"Bearer {self.ai_config.get('api_key', '')}"},
                timeout=60.0,
            )
            
            # Test connection
            response = await self._ai_client.get("/models")
            if response.status_code == 200:
                self.logger.info("[AI] Kimi 2.5 brain connected successfully")
                return True
            else:
                self.logger.warning("[AI] Brain connection test returned %d", response.status_code)
                return False

        except Exception as e:
            self.logger.error("[AI] Brain initialization failed: %s", e)
            return False

    async def query_ai_brain(self, prompt: str, context: Optional[str] = None) -> str:
        """
        Query the AI brain for reasoning and response generation.
        
        Args:
            prompt: User prompt
            context: Additional context
            
        Returns:
            AI response text
        """
        if not self._ai_client:
            return "AI Brain not connected. Check API configuration."
        
        try:
            messages = []
            if context:
                messages.append({"role": "system", "content": context})
            messages.append({"role": "user", "content": prompt})
            
            response = await self._ai_client.post(
                "/chat/completions",
                json={
                    "model": self.ai_config.get("model", "kimi-latest"),
                    "messages": messages,
                    "max_tokens": self.ai_config.get("max_tokens", 4096),
                    "temperature": self.ai_config.get("temperature", 0.7),
                },
            )
            
            if response.status_code == 200:
                data = response.json()
                return data["choices"][0]["message"]["content"]
            else:
                return f"AI Brain error: HTTP {response.status_code}"

        except Exception as e:
            self.logger.error("[AI] Query failed: %s", e)
            return f"AI Brain query failed: {str(e)}"

    # ═══════════════════════════════════════════════════════════════════════════
    # TELEGRAM BOT HANDLERS
    # ═══════════════════════════════════════════════════════════════════════════

    async def setup_telegram_bot(self) -> bool:
        """
        Setup Telegram bot with command handlers.
        
        Returns:
            True if bot started successfully
        """
        try:
            token = self._telegram_config.get("bot_token", "")
            if not token or token == "YOUR_TELEGRAM_BOT_TOKEN_HERE":
                self.logger.error("[TELEGRAM] Bot token not configured")
                return False

            self.telegram_app = Application.builder().token(token).build()
            
            # Command handlers
            self.telegram_app.add_handler(CommandHandler("start", self._cmd_start))
            self.telegram_app.add_handler(CommandHandler("help", self._cmd_help))
            self.telegram_app.add_handler(CommandHandler("status", self._cmd_status))
            self.telegram_app.add_handler(CommandHandler("auth", self._cmd_auth))
            self.telegram_app.add_handler(CommandHandler("social", self._cmd_social))
            self.telegram_app.add_handler(CommandHandler("email", self._cmd_email))
            self.telegram_app.add_handler(CommandHandler("content", self._cmd_content))
            self.telegram_app.add_handler(CommandHandler("code", self._cmd_code))
            self.telegram_app.add_handler(CommandHandler("security", self._cmd_security))
            self.telegram_app.add_handler(CommandHandler("shell", self._cmd_shell))
            self.telegram_app.add_handler(CommandHandler("ai", self._cmd_ai))
            self.telegram_app.add_handler(CommandHandler("agents", self._cmd_agents))
            self.telegram_app.add_handler(CommandHandler("sessions", self._cmd_sessions))
            self.telegram_app.add_handler(CommandHandler("log", self._cmd_log))
            self.telegram_app.add_handler(CommandHandler("stop", self._cmd_stop))
            
            # Callback query handler for inline buttons
            self.telegram_app.add_handler(CallbackQueryHandler(self._handle_callback))
            
            # Message handler for text
            self.telegram_app.add_handler(
                MessageHandler(filters.TEXT & ~filters.COMMAND, self._handle_message)
            )
            
            # Error handler
            self.telegram_app.add_error_handler(self._handle_telegram_error)
            
            await self.telegram_app.initialize()
            await self.telegram_app.start()
            
            # Start polling
            await self.telegram_app.updater.start_polling(
                poll_interval=1.0,
                timeout=30,
            )
            
            self.logger.info("[TELEGRAM] Bot started and polling")
            return True

        except Exception as e:
            self.logger.error("[TELEGRAM] Bot setup failed: %s", e)
            return False

    def _is_authorized(self, update: Update) -> bool:
        """
        Check if user is authorized.
        HARDCODED: Only User-ID 8244634415 is authorized.
        """
        user_id = update.effective_user.id
        return user_id == self.AUTHORIZED_USER_ID

    async def _send_unauthorized(self, update: Update) -> None:
        """Send unauthorized access message."""
        user_id = update.effective_user.id
        self.logger.warning("[SECURITY] Unauthorized access attempt from User-ID: %s", user_id)
        
        await update.message.reply_text(
            "╔════════════════════════════════════╗\n"
            "║     🚫 ACCESS DENIED 🚫            ║\n"
            "╠════════════════════════════════════╣\n"
            f"║ Your ID: {user_id}                 ║\n"
            "║ Status: UNAUTHORIZED               ║\n"
            "║                                    ║\n"
            "║ This incident has been logged.     ║\n"
            "╚════════════════════════════════════╝"
        )

    async def _cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        self._message_count += 1
        
        welcome_message = (
            f"🔮 *CipherX-Nexus v{self.VERSION}*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"Welcome, Commander. The system is online.\n\n"
            f"📊 *System Status:* `{self._system_status.upper()}`\n"
            f"⏱ *Uptime:* `{self._get_uptime()}`\n"
            f"🤖 *Active Agents:* `{len(self.agents)}`\n\n"
            f"Use /help for available commands.\n"
            f"Use /auth `<password>` for privileged access."
        )
        
        keyboard = [
            [InlineKeyboardButton("📊 Status", callback_data="status"),
             InlineKeyboardButton("🤖 Agents", callback_data="agents")],
            [InlineKeyboardButton("📧 Email", callback_data="email"),
             InlineKeyboardButton("🌐 Social", callback_data="social")],
            [InlineKeyboardButton("🔒 Security", callback_data="security"),
             InlineKeyboardButton("💻 Coding", callback_data="code")],
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            welcome_message,
            parse_mode="Markdown",
            reply_markup=reply_markup,
        )

    async def _cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /help command."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        help_text = (
            "📖 *CipherX-Nexus Command Reference*\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "*Authentication:*\n"
            "  `/auth <password>` - Authenticate for privileged commands\n\n"
            "*System:*\n"
            "  `/start` - Show welcome message\n"
            "  `/status` - System status and metrics\n"
            "  `/agents` - List active agents\n"
            "  `/sessions` - Social media session status\n"
            "  `/log [n]` - Show last n log lines\n"
            "  `/stop` - Graceful shutdown\n\n"
            "*Social Media:*\n"
            "  `/social post <platform> <text>` - Post update\n"
            "  `/social schedule <platform> <time> <text>` - Schedule post\n"
            "  `/social trends <platform> <keyword>` - Engage trends\n"
            "  `/social dms <platform>` - Auto-reply DMs\n\n"
            "*Email:*\n"
            "  `/email fetch [limit]` - Fetch emails\n"
            "  `/email summary` - Email summary\n"
            "  `/email send <to> <subject> <body>` - Send email\n"
            "  `/email reply <id> <message>` - Reply to email\n\n"
            "*Content:*\n"
            "  `/content title <topic>` - Generate SEO titles\n"
            "  `/content desc <topic>` - Generate meta descriptions\n"
            "  `/content caption <topic>` - Social media captions\n"
            "  `/content prompt <topic>` - AI image prompts\n\n"
            "*Coding:*\n"
            "  `/code generate <lang> <description>` - Generate code\n"
            "  `/code debug <lang>` - Debug code (reply with code)\n"
            "  `/code review <lang>` - Code review\n"
            "  `/code scaffold <type> <name>` - Scaffold project\n\n"
            "*Security:*\n"
            "  `/security scan <target>` - Port scan\n"
            "  `/security web <target>` - Web vulnerability scan\n"
            "  `/security recon <target>` - Full reconnaissance\n"
            "  `/security report <target>` - Generate report\n\n"
            "*Shell (Privileged):*\n"
            "  `/shell <command>` - Execute shell command\n\n"
            "*AI Brain:*\n"
            "  `/ai <prompt>` - Query AI brain\n"
            "  `/ai reason <prompt>` - Deep reasoning mode\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )
        
        await update.message.reply_text(help_text, parse_mode="Markdown")

    async def _cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /status command."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        uptime = self._get_uptime()
        agent_status = "\n".join(
            f"  • `{name}`: {agent.status.value}"
            for name, agent in self.agents.items()
        )
        
        status_text = (
            f"📊 *System Status Report*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"*Version:* `{self.VERSION}`\n"
            f"*Status:* `{self._system_status.upper()}`\n"
            f"*Uptime:* `{uptime}`\n"
            f"*Messages Processed:* `{self._message_count}`\n"
            f"*Commands Executed:* `{self._command_count}`\n\n"
            f"*Active Agents:*\n{agent_status}\n\n"
            f"*Security:*\n"
            f"  Authorized User: `{self.AUTHORIZED_USER_ID}`\n"
            f"  Session Lock: `{'ACTIVE' if self.security.has_privileged_access(self.AUTHORIZED_USER_ID) else 'STANDBY'}`\n\n"
            f"*AI Brain:*\n"
            f"  Status: `{'CONNECTED' if self._ai_client else 'DISCONNECTED'}`\n"
            f"  Model: `{self.ai_config.get('model', 'N/A')}`\n"
        )
        
        await update.message.reply_text(status_text, parse_mode="Markdown")

    async def _cmd_auth(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /auth command for 2FA."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        user_id = update.effective_user.id
        
        if not context.args:
            await update.message.reply_text(
                "🔐 *2FA Authentication Required*\n"
                "Usage: `/auth <master_password>`\n"
                "This unlocks privileged commands.",
                parse_mode="Markdown",
            )
            return

        password = " ".join(context.args)
        success, message = self.security.authenticate_with_password(user_id, password)
        
        if success:
            await update.message.reply_text(
                f"✅ *Authentication Successful*\n"
                f"{message}\n"
                f"Privileged commands are now unlocked.",
                parse_mode="Markdown",
            )
        else:
            await update.message.reply_text(
                f"❌ *Authentication Failed*\n"
                f"{message}",
                parse_mode="Markdown",
            )

    async def _cmd_social(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /social command for social media operations."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "🌐 *Social Media Command*\n"
                "Usage:\n"
                "  `/social post <platform> <text>`\n"
                "  `/social schedule <platform> <time> <text>`\n"
                "  `/social trends <platform> <keyword>`\n"
                "  `/social dms <platform>`\n\n"
                "Platforms: `facebook`, `instagram`, `twitter`, `linkedin`, `youtube`",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1
        action = context.args[0].lower()
        platform = context.args[1].lower() if len(context.args) > 1 else ""

        try:
            if action == "post" and len(context.args) >= 3:
                content = " ".join(context.args[2:])
                result = await self.social.post_update(platform, content)
                await update.message.reply_text(
                    f"📤 *Post Result*\n"
                    f"Platform: `{platform}`\n"
                    f"Status: `{result.get('status', 'unknown')}`\n"
                    f"Message: {result.get('message', 'N/A')}",
                    parse_mode="Markdown",
                )

            elif action == "schedule" and len(context.args) >= 4:
                schedule_time_str = context.args[2]
                content = " ".join(context.args[3:])
                
                try:
                    schedule_time = datetime.fromisoformat(schedule_time_str)
                except:
                    schedule_time = datetime.now() + timedelta(hours=1)
                
                result = await self.social.schedule_video(
                    video_path=content,  # For YouTube scheduling
                    title=content[:100],
                    description=content,
                    scheduled_time=schedule_time,
                )
                await update.message.reply_text(
                    f"📅 *Schedule Result*\n"
                    f"Status: `{result.get('status', 'unknown')}`\n"
                    f"Message: {result.get('message', 'N/A')}",
                    parse_mode="Markdown",
                )

            elif action == "trends" and len(context.args) >= 3:
                keyword = " ".join(context.args[2:])
                result = await self.social.engage_with_trends(platform, keyword)
                await update.message.reply_text(
                    f"🔥 *Trend Engagement*\n"
                    f"Platform: `{platform}`\n"
                    f"Keyword: `{keyword}`\n"
                    f"Engaged: `{result.get('posts_engaged', result.get('tweets_engaged', 0))}`\n"
                    f"Status: `{result.get('status', 'unknown')}`",
                    parse_mode="Markdown",
                )

            elif action == "dms":
                result = await self.social.auto_reply_dms(platform)
                await update.message.reply_text(
                    f"💬 *DM Auto-Reply*\n"
                    f"Platform: `{platform}`\n"
                    f"Processed: `{result.get('messages_processed', result.get('messages_replied', 0))}`\n"
                    f"Status: `{result.get('status', 'unknown')}`",
                    parse_mode="Markdown",
                )

            elif action == "status":
                status = await self.social.get_platform_status()
                status_text = "\n".join(
                    f"  `{p}`: {'🟢' if s['logged_in'] else '🔴'} "
                    f"{'Logged In' if s['logged_in'] else 'Logged Out'}"
                    for p, s in status.items()
                )
                await update.message.reply_text(
                    f"🌐 *Platform Status*\n{status_text}",
                    parse_mode="Markdown",
                )

            else:
                await update.message.reply_text("❌ Invalid social command. Use /help for usage.")

        except Exception as e:
            self.logger.error("[TELEGRAM] Social command error: %s", e)
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def _cmd_email(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /email command."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        if not context.args:
            await update.message.reply_text(
                "📧 *Email Command*\n"
                "Usage:\n"
                "  `/email fetch [limit]` - Fetch emails\n"
                "  `/email summary` - Email summary\n"
                "  `/email send <to> <subject> <body>`\n"
                "  `/email reply <id> <message>`",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1
        action = context.args[0].lower()

        try:
            if action == "fetch":
                limit = int(context.args[1]) if len(context.args) > 1 else 10
                emails = await self.email.fetch_emails(limit=limit)
                
                email_list = "\n".join(
                    f"  `{i+1}.` [{e.date.strftime('%m/%d %H:%M')}] "
                    f"*{e.sender[:30]}* - {e.subject[:50]}"
                    for i, e in enumerate(emails[:limit])
                )
                
                await update.message.reply_text(
                    f"📧 *Email Fetch Results*\n"
                    f"Found: `{len(emails)}` emails\n\n"
                    f"{email_list}",
                    parse_mode="Markdown",
                )

            elif action == "summary":
                emails = await self.email.fetch_emails(limit=50)
                summary = await self.email.summarize_emails(emails)
                await update.message.reply_text(
                    f"📊 *Email Summary*\n```\n{summary}\n```",
                    parse_mode="Markdown",
                )

            elif action == "send" and len(context.args) >= 4:
                to_addr = context.args[1]
                subject = context.args[2]
                body = " ".join(context.args[3:])
                
                success = await self.email.send_email(to_addr, subject, body)
                await update.message.reply_text(
                    f"📤 *Send Result*\n"
                    f"Status: `{'SUCCESS' if success else 'FAILED'}`",
                    parse_mode="Markdown",
                )

            else:
                await update.message.reply_text("❌ Invalid email command.")

        except Exception as e:
            self.logger.error("[TELEGRAM] Email command error: %s", e)
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def _cmd_content(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /content command for content generation."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "📝 *Content Command*\n"
                "Usage:\n"
                "  `/content title <topic>` - SEO titles\n"
                "  `/content desc <topic>` - Meta descriptions\n"
                "  `/content blog <topic>` - Blog outline\n"
                "  `/content caption <topic> [platform]` - Social captions\n"
                "  `/content prompt <topic> [style]` - AI image prompts\n"
                "  `/content hashtags <topic>` - Hashtag suggestions",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1
        action = context.args[0].lower()
        topic = context.args[1]
        platform = context.args[2] if len(context.args) > 2 else "instagram"

        try:
            agent = self.agents.get("ContentAgent")
            if not agent:
                await update.message.reply_text("❌ ContentAgent not available.")
                return

            action_map = {
                "title": "generate_title",
                "desc": "generate_description",
                "blog": "generate_blog",
                "caption": "generate_caption",
                "prompt": "generate_prompt",
                "hashtags": "generate_hashtags",
            }

            payload = {
                "action": action_map.get(action, "generate_title"),
                "topic": topic,
                "platform": platform,
                "keywords": [topic],
            }

            result = await agent.execute(payload)
            
            # Format response based on action
            if action == "title" and "titles" in result:
                titles_text = "\n".join(
                    f"  `{i+1}.` {t['title']} (Score: {t['score']})"
                    for i, t in enumerate(result["titles"][:5])
                )
                response = f"🎯 *SEO Titles for '{topic}'*\n{titles_text}"
                
            elif action == "desc" and "descriptions" in result:
                desc_text = "\n\n".join(
                    f"  `{i+1}.` {d['description'][:150]}..."
                    for i, d in enumerate(result["descriptions"][:3])
                )
                response = f"📝 *Meta Descriptions for '{topic}'*\n{desc_text}"
                
            elif action == "caption" and "caption" in result:
                response = (
                    f"📱 *{platform.title()} Caption*\n"
                    f"```{result['caption']}```\n\n"
                    f"Hashtags: {', '.join(result.get('hashtags', []))}"
                )
                
            elif action == "prompt" and "prompt" in result:
                response = (
                    f"🎨 *AI Image Prompt*\n"
                    f"*Positive:*\n`{result['prompt']}`\n\n"
                    f"*Negative:*\n`{result.get('negative_prompt', '')}`"
                )
                
            elif action == "hashtags":
                hashtags = ", ".join(result.get("hashtags", []))
                response = f"🏷 *Hashtags for '{topic}'*\n{hashtags}"
                
            else:
                response = f"```json\n{json.dumps(result, indent=2, default=str)[:3000]}\n```"

            await update.message.reply_text(response, parse_mode="Markdown")

        except Exception as e:
            self.logger.error("[TELEGRAM] Content command error: %s", e)
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def _cmd_code(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /code command for coding tasks."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "💻 *Code Command*\n"
                "Usage:\n"
                "  `/code generate <lang> <description>`\n"
                "  `/code debug <lang>` (reply to a message with code)\n"
                "  `/code review <lang>` (reply to a message with code)\n"
                "  `/code scaffold <type> <name>`\n\n"
                "Languages: `php`, `python`, `javascript`, `sql`, `bash`\n"
                "Types: `laravel`, `react`, `vue`, `python`",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1
        action = context.args[0].lower()
        language = context.args[1] if len(context.args) > 1 else "python"

        try:
            agent = self.agents.get("WebCodingAgent")
            if not agent:
                await update.message.reply_text("❌ WebCodingAgent not available.")
                return

            if action == "generate":
                description = " ".join(context.args[2:]) if len(context.args) > 2 else "Hello World"
                payload = {
                    "action": "generate_code",
                    "language": language,
                    "description": description,
                }
                result = await agent.execute(payload)
                
                code = result.get("code", "// No code generated")
                response = (
                    f"💻 *Generated {language.upper()} Code*\n"
                    f"*Description:* {description}\n"
                    f"*Lines:* `{result.get('line_count', 0)}`\n"
                    f"```\n{code[:3500]}\n```"
                )
                
            elif action == "scaffold" and len(context.args) >= 3:
                project_name = context.args[2]
                payload = {
                    "action": "scaffold_project",
                    "project_type": language,
                    "project_name": project_name,
                }
                result = await agent.execute(payload)
                
                commands = "\n".join(f"  `{cmd}`" for cmd in result.get("setup_commands", []))
                structure = "\n".join(f"  📁 `{item}`" for item in result.get("structure", []))
                
                response = (
                    f"🏗 *Project Scaffold: {project_name}*\n"
                    f"Type: `{language}`\n\n"
                    f"*Structure:*\n{structure}\n\n"
                    f"*Setup Commands:*\n{commands}"
                )
                
            elif action in ["debug", "review"]:
                # Get code from replied message
                if update.message.reply_to_message:
                    code = update.message.reply_to_message.text or ""
                    payload = {
                        "action": f"{action}_code",
                        "language": language,
                        "code": code,
                    }
                    result = await agent.execute(payload)
                    
                    if action == "debug":
                        issues = "\n".join(f"  ⚠️ {issue}" for issue in result.get("issues", []))
                        suggestions = "\n".join(f"  💡 {s}" for s in result.get("suggestions", []))
                        response = (
                            f"🔍 *Debug Results*\n"
                            f"Issues Found: `{result.get('issues_found', 0)}`\n"
                            f"Severity: `{result.get('severity', 'unknown')}`\n\n"
                            f"*Issues:*\n{issues}\n\n"
                            f"*Suggestions:*\n{suggestions}"
                        )
                    else:
                        response = (
                            f"📋 *Code Review*\n"
                            f"Score: `{result.get('score', 0)}/100`\n"
                            f"Grade: `{result.get('grade', 'N/A')}`\n\n"
                            f"*Findings:*\n"
                            + "\n".join(f"  • {f}" for f in result.get("findings", []))
                        )
                else:
                    response = "❌ Reply to a message containing code to debug/review it."
            else:
                response = "❌ Invalid code command."

            await update.message.reply_text(response, parse_mode="Markdown")

        except Exception as e:
            self.logger.error("[TELEGRAM] Code command error: %s", e)
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def _cmd_security(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /security command for security operations."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        if not context.args or len(context.args) < 2:
            await update.message.reply_text(
                "🔒 *Security Command*\n"
                "*Privileged access required for high-risk commands.*\n\n"
                "Usage:\n"
                "  `/security scan <target>` - Port scan\n"
                "  `/security dir <target>` - Directory brute-force\n"
                "  `/security subdomain <domain>` - Subdomain enum\n"
                "  `/security web <target>` - Web vulnerability scan\n"
                "  `/security ssl <target>` - SSL analysis\n"
                "  `/security recon <target>` - Full reconnaissance\n"
                "  `/security report <target>` - Generate report\n\n"
                "Profiles: `stealth`, `normal`, `aggressive`, `quick`",
                parse_mode="Markdown",
            )
            return

        user_id = update.effective_user.id
        action = context.args[0].lower()
        target = context.args[1]
        profile = context.args[2] if len(context.args) > 2 else "normal"

        # Check privileged access for destructive scans
        high_risk_actions = ["recon", "aggressive", "dir", "subdomain"]
        if action in high_risk_actions and not self.security.has_privileged_access(user_id):
            await update.message.reply_text(
                "🔒 *2FA Required*\n"
                "This command requires privileged access.\n"
                "Use `/auth <password>` to authenticate.",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1

        try:
            agent = self.agents.get("SecurityAgent")
            if not agent:
                await update.message.reply_text("❌ SecurityAgent not available.")
                return

            # Submit as task for long-running operations
            task_payload = {
                "action": self._map_security_action(action),
                "target": target,
                "profile": profile,
            }

            # Send initial response
            status_msg = await update.message.reply_text(
                f"🔍 *Security Scan Initiated*\n"
                f"Action: `{action}`\n"
                f"Target: `{target}`\n"
                f"Profile: `{profile}`\n"
                f"Status: `RUNNING...`",
                parse_mode="Markdown",
            )

            # Execute directly for quick results
            result = await agent.execute(task_payload)

            # Format result
            if "open_ports" in result:
                ports_text = "\n".join(
                    f"  `Port {p['port']}/{p['protocol']}` - {p['service']} "
                    f"({p['state']}) [{'HIGH' if p['risk'] == 'high' else 'LOW'} RISK]"
                    for p in result.get("open_ports", [])
                )
                response = (
                    f"🔍 *Port Scan Results: {target}*\n"
                    f"Open Ports: `{result.get('total_open', 0)}`\n"
                    f"Execution Time: `{result.get('execution_time', 0)}s`\n\n"
                    f"{ports_text}"
                )
                
            elif "vulnerabilities" in result:
                vulns = result.get("vulnerabilities", [])
                risk_summary = result.get("risk_summary", {})
                response = (
                    f"🌐 *Web Scan Results: {target}*\n"
                    f"Vulnerabilities: `{len(vulns)}`\n"
                    f"Risk: Critical: `{risk_summary.get('critical', 0)}` | "
                    f"High: `{risk_summary.get('high', 0)}` | "
                    f"Medium: `{risk_summary.get('medium', 0)}`"
                )
                
            elif "subdomains" in result:
                response = (
                    f"🌍 *Subdomain Results: {target}*\n"
                    f"Total: `{result.get('total_subdomains', 0)}`\n"
                    f"Alive: `{result.get('alive_subdomains', 0)}`\n\n"
                    f"Sample: `{(result.get('subdomains') or ['N/A'])[:5]}`"
                )
                
            elif "results" in result:
                response = (
                    f"🔎 *Recon Results: {target}*\n"
                    f"Phases: `{', '.join(result.get('phases_completed', []))}`\n"
                    f"Risk: `{result.get('risk_assessment', 'UNKNOWN')}`\n\n"
                    f"Executive Summary:\n```\n{result.get('results', {}).get('whois', {}).get('raw', {})}\n```"
                )
                
            else:
                response = f"```json\n{json.dumps(result, indent=2, default=str)[:3500]}\n```"

            # Delete status message and send result
            await status_msg.delete()
            await update.message.reply_text(response, parse_mode="Markdown")

        except Exception as e:
            self.logger.error("[TELEGRAM] Security command error: %s", e)
            await update.message.reply_text(f"❌ Error: {str(e)}")

    def _map_security_action(self, action: str) -> str:
        """Map user command to security agent action."""
        mapping = {
            "scan": "port_scan",
            "dir": "dir_bruteforce",
            "subdomain": "subdomain_enum",
            "web": "web_scan",
            "ssl": "ssl_scan",
            "recon": "full_recon",
            "report": "generate_report",
        }
        return mapping.get(action, "port_scan")

    async def _cmd_shell(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """
        Handle /shell command - PRIVILEGED ONLY.
        Executes sanitized shell commands.
        """
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        user_id = update.effective_user.id
        
        # Strict 2FA check
        if not self.security.has_privileged_access(user_id):
            await update.message.reply_text(
                "🔒 *SHELL ACCESS DENIED*\n"
                "This is a high-risk command requiring 2FA.\n\n"
                "Authenticate with: `/auth <master_password>`",
                parse_mode="Markdown",
            )
            return

        if not context.args:
            await update.message.reply_text(
                "💻 *Shell Command (PRIVILEGED)*\n"
                "Usage: `/shell <command>`\n\n"
                "⚠️ All commands are logged and sanitized.",
                parse_mode="Markdown",
            )
            return

        command = " ".join(context.args)
        
        # Sanitize command
        is_valid, sanitized, warnings = self.security.sanitize_shell_command(command)
        
        if not is_valid:
            warning_text = "\n".join(f"  ⚠️ {w}" for w in warnings)
            await update.message.reply_text(
                f"🚫 *Command Blocked*\n{warning_text}",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1
        self.security.audit_log(user_id, "SHELL_EXEC", {"command": sanitized})

        # Execute with timeout
        try:
            status_msg = await update.message.reply_text(
                f"💻 *Executing*\n`{sanitized}`\nStatus: `RUNNING...`",
                parse_mode="Markdown",
            )

            proc = await asyncio.create_subprocess_shell(
                sanitized,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
            
            output = stdout.decode("utf-8", errors="replace") or stderr.decode("utf-8", errors="replace")
            
            # Truncate long output
            if len(output) > 3800:
                output = output[:3800] + "\n... [truncated]"

            await status_msg.delete()
            
            return_code_emoji = "✅" if proc.returncode == 0 else "⚠️"
            await update.message.reply_text(
                f"{return_code_emoji} *Shell Result*\n"
                f"Command: `{sanitized}`\n"
                f"Exit Code: `{proc.returncode}`\n"
                f"```\n{output}\n```",
                parse_mode="Markdown",
            )

        except asyncio.TimeoutError:
            await status_msg.edit_text("⏱ *Timeout*\nCommand exceeded 120s limit.")
        except Exception as e:
            await update.message.reply_text(f"❌ Execution error: {str(e)}")

    async def _cmd_ai(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /ai command for AI brain queries."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        if not context.args:
            await update.message.reply_text(
                "🧠 *AI Brain Command*\n"
                "Usage:\n"
                "  `/ai <prompt>` - Standard query\n"
                "  `/ai reason <prompt>` - Deep reasoning\n\n"
                f"Model: `{self.ai_config.get('model', 'kimi-latest')}`",
                parse_mode="Markdown",
            )
            return

        self._command_count += 1
        
        action = context.args[0].lower()
        if action == "reason":
            prompt = " ".join(context.args[1:])
            context_msg = (
                "You are CipherX-Nexus AI, an expert reasoning engine. "
                "Think step-by-step and provide detailed analysis."
            )
        else:
            prompt = " ".join(context.args)
            context_msg = None

        try:
            status_msg = await update.message.reply_text(
                "🧠 *AI Brain Processing...*",
                parse_mode="Markdown",
            )

            response = await self.query_ai_brain(prompt, context_msg)
            
            await status_msg.delete()
            
            # Truncate if too long
            if len(response) > 4000:
                response = response[:4000] + "\n\n...[truncated]"

            await update.message.reply_text(
                f"🧠 *AI Response*\n```\n{response}\n```",
                parse_mode="Markdown",
            )

        except Exception as e:
            self.logger.error("[TELEGRAM] AI command error: %s", e)
            await update.message.reply_text(f"❌ AI query failed: {str(e)}")

    async def _cmd_agents(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /agents command."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        agent_list = []
        for name, agent in self.agents.items():
            metrics = agent.metrics
            agent_list.append(
                f"  🤖 *{name}*\n"
                f"     Status: `{metrics['status']}`\n"
                f"     Tasks: `{metrics['tasks_completed']}` completed, "
                f"`{metrics['tasks_failed']}` failed\n"
                f"     Avg Time: `{metrics['avg_execution_time']}s`\n"
            )

        response = (
            f"🤖 *Agent Status*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{'\n'.join(agent_list)}"
        )
        
        await update.message.reply_text(response, parse_mode="Markdown")

    async def _cmd_sessions(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /sessions command for social media sessions."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        try:
            status = await self.social.get_platform_status()
            session_text = "\n".join(
                f"  {'🟢' if s['logged_in'] else '🔴'} `{p}`: "
                f"{'Logged In' if s['logged_in'] else 'Logged Out'} "
                f"(Session: {'Yes' if s['session_exists'] else 'No'})"
                for p, s in status.items()
            )
            
            await update.message.reply_text(
                f"🌐 *Social Media Sessions*\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"{session_text}",
                parse_mode="Markdown",
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def _cmd_log(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /log command."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        lines = int(context.args[0]) if context.args else 20
        
        try:
            log_file = self.config.get("orchestrator", {}).get("log_file", "logs/nexus.log")
            if os.path.exists(log_file):
                with open(log_file, "r") as f:
                    log_lines = f.readlines()
                
                recent = "".join(log_lines[-lines:])
                if len(recent) > 4000:
                    recent = recent[-4000:]
                
                await update.message.reply_text(
                    f"📋 *Last {lines} Log Lines*\n"
                    f"```\n{recent}\n```",
                    parse_mode="Markdown",
                )
            else:
                await update.message.reply_text("❌ Log file not found.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {str(e)}")

    async def _cmd_stop(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /stop command for graceful shutdown."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        user_id = update.effective_user.id
        
        if not self.security.has_privileged_access(user_id):
            await update.message.reply_text(
                "🔒 *SHUTDOWN DENIED*\n"
                "This requires privileged access.\n"
                "Use `/auth <password>` first.",
                parse_mode="Markdown",
            )
            return

        await update.message.reply_text(
            "🛑 *Shutdown Initiated*\n"
            "Gracefully stopping all agents...",
            parse_mode="Markdown",
        )
        
        self._shutdown_event.set()

    async def _handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle inline keyboard callbacks."""
        query = update.callback_query
        await query.answer()
        
        if not self._is_authorized(update):
            return

        action = query.data
        
        if action == "status":
            await self._cmd_status(update, context)
        elif action == "agents":
            await self._cmd_agents(update, context)
        elif action == "email":
            await update.effective_message.reply_text("Use `/email fetch` to check emails.")
        elif action == "social":
            await update.effective_message.reply_text("Use `/social status` to check platforms.")
        elif action == "security":
            await update.effective_message.reply_text("Use `/security scan <target>` to start scanning.")
        elif action == "code":
            await update.effective_message.reply_text("Use `/code generate <lang> <desc>` to generate code.")

    async def _handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle regular text messages."""
        if not self._is_authorized(update):
            await self._send_unauthorized(update)
            return

        self._message_count += 1
        text = update.message.text
        
        # Echo with AI processing for natural language queries
        if text.lower().startswith(("nexus", "hey", "hello", "hi ")):
            try:
                response = await self.query_ai_brain(text)
                await update.message.reply_text(
                    f"🧠 *Nexus AI*\n{response}",
                    parse_mode="Markdown",
                )
            except Exception as e:
                await update.message.reply_text(
                    f"👋 Message received. Use /help for commands.\n"
                    f"(AI query failed: {str(e)})"
                )

    async def _handle_telegram_error(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle Telegram bot errors."""
        self.logger.error("[TELEGRAM] Update error: %s", context.error)
        if isinstance(update, Update) and update.effective_message:
            try:
                await update.effective_message.reply_text(
                    "⚠️ An error occurred while processing your request.\n"
                    "Check logs with /log for details."
                )
            except:
                pass

    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════════════

    def _get_uptime(self) -> str:
        """Get formatted uptime string."""
        delta = datetime.now() - self.start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours}h {minutes}m {seconds}s"

    async def run(self) -> None:
        """
        Main orchestrator run loop.
        Initializes all components and starts event loop.
        """
        self.logger.info("[CORE] Starting NexusOrchestrator...")
        self._system_status = "starting"

        try:
            # Initialize AI brain
            ai_ready = await self.initialize_ai_brain()
            if not ai_ready:
                self.logger.warning("[CORE] AI brain not connected - continuing without AI features")

            # Initialize social engine
            social_ready = await self.social.initialize()
            if not social_ready:
                self.logger.warning("[CORE] Social engine not initialized")

            # Start sub-agents
            for name, agent in self.agents.items():
                try:
                    asyncio.create_task(agent.start())
                    self.logger.info("[CORE] Started agent: %s", name)
                except Exception as e:
                    self.logger.error("[CORE] Failed to start agent %s: %s", name, e)

            # Setup Telegram bot
            bot_ready = await self.setup_telegram_bot()
            if not bot_ready:
                self.logger.error("[CORE] Telegram bot failed to start")
                return

            self._system_status = "running"
            self.logger.info("═" * 60)
            self.logger.info("  CIPHERX-NEXUS v%s IS ONLINE", self.VERSION)
            self.logger.info("  User-ID Lock: %s", self.AUTHORIZED_USER_ID)
            self.logger.info("  AI Brain: %s", "CONNECTED" if ai_ready else "OFFLINE")
            self.logger.info("  Social Engine: %s", "READY" if social_ready else "OFFLINE")
            self.logger.info("  Agents: %d active", len(self.agents))
            self.logger.info("═" * 60)

            # Main loop - keep running until shutdown
            while not self._shutdown_event.is_set():
                try:
                    # Process scheduled posts
                    await self.social.process_scheduled_posts()
                    
                    # Health check every minute
                    if time.time() - self._last_health_check > 60:
                        await self._health_check()
                        self._last_health_check = time.time()
                    
                    # Cleanup expired sessions
                    self.security.cleanup_expired_sessions()
                    
                    await asyncio.sleep(5)

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    self.logger.error("[CORE] Main loop error: %s", e)
                    await asyncio.sleep(10)

        except Exception as e:
            self.logger.critical("[CORE] Fatal error: %s", e)
            traceback.print_exc()
        finally:
            await self.shutdown()

    async def _health_check(self) -> None:
        """Perform periodic health check."""
        for name, agent in self.agents.items():
            health = await agent.health_check()
            if not health.get("healthy"):
                self.logger.warning("[HEALTH] Agent %s is unhealthy: %s", name, health)

    async def shutdown(self) -> None:
        """Graceful shutdown of all components."""
        self.logger.info("[CORE] Initiating graceful shutdown...")
        self._system_status = "shutting_down"

        # Stop Telegram bot
        if self.telegram_app:
            try:
                await self.telegram_app.updater.stop()
                await self.telegram_app.stop()
                await self.telegram_app.shutdown()
                self.logger.info("[CORE] Telegram bot stopped")
            except Exception as e:
                self.logger.error("[CORE] Error stopping Telegram: %s", e)

        # Stop agents
        for name, agent in self.agents.items():
            try:
                await agent.stop()
                self.logger.info("[CORE] Stopped agent: %s", name)
            except Exception as e:
                self.logger.error("[CORE] Error stopping agent %s: %s", name, e)

        # Close social engine
        try:
            await self.social.close()
            self.logger.info("[CORE] Social engine closed")
        except Exception as e:
            self.logger.error("[CORE] Error closing social engine: %s", e)

        # Close email connections
        try:
            await self.email.disconnect()
            self.logger.info("[CORE] Email connections closed")
        except Exception as e:
            self.logger.error("[CORE] Error closing email: %s", e)

        # Close AI client
        if self._ai_client:
            await self._ai_client.aclose()

        self._system_status = "offline"
        self.logger.info("═" * 60)
        self.logger.info("  CIPHERX-NEXUS SHUTDOWN COMPLETE")
        self.logger.info("  Uptime: %s", self._get_uptime())
        self.logger.info("═" * 60)

    async def handle_agent_event(self, agent_name: str, event: Dict[str, Any]) -> None:
        """
        Handle events from sub-agents.
        
        Args:
            agent_name: Name of the agent that emitted the event
            event: Event data
        """
        event_type = event.get("type", "unknown")
        
        if event_type in ["task_failed", "agent_stopped"]:
            self.logger.warning("[EVENT] %s: %s - %s", agent_name, event_type, event.get("data", {}))
        else:
            self.logger.debug("[EVENT] %s: %s", agent_name, event_type)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def load_config(config_path: str = "config.json") -> Dict[str, Any]:
    """
    Load configuration from JSON file.
    
    Args:
        config_path: Path to config file
        
    Returns:
        Configuration dictionary
    """
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        
        # Override with environment variables where applicable
        env_overrides = {
            "telegram.bot_token": os.environ.get("NEXUS_BOT_TOKEN"),
            "ai_brain.api_key": os.environ.get("NEXUS_AI_KEY"),
            "security.master_password_plaintext": os.environ.get("NEXUS_MASTER_PASSWORD"),
        }
        
        for key_path, value in env_overrides.items():
            if value:
                parts = key_path.split(".")
                target = config
                for part in parts[:-1]:
                    target = target.setdefault(part, {})
                target[parts[-1]] = value
        
        return config

    except FileNotFoundError:
        print(f"ERROR: Configuration file not found: {config_path}")
        print("Please copy config.json.template to config.json and configure it.")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON in config file: {e}")
        sys.exit(1)


async def main():
    """Main entry point."""
    # Load configuration
    config = load_config()
    
    # Create and run orchestrator
    orchestrator = NexusOrchestrator(config)
    
    # Handle signals for graceful shutdown
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, lambda: asyncio.create_task(orchestrator.shutdown()))
    
    try:
        await orchestrator.run()
    except KeyboardInterrupt:
        await orchestrator.shutdown()
    except Exception as e:
        logging.critical("Fatal error in main: %s", e)
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
