"""
CIPHERX-NEXUS SECURITY AGENT MODULE
Cyber security operations with Kali Linux tool integration.
Handles reconnaissance, scanning, and reporting like a pro grey-hat hacker.
"""

import asyncio
import json
import logging
import os
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class SecurityAgent(BaseAgent):
    """
    Cyber Security Agent for penetration testing and security operations.
    
    Capabilities:
    - Nmap port scanning and service enumeration
    - Dirsearch web directory brute-forcing
    - Subdomain enumeration
    - HTTP vulnerability scanning
    - SSL/TLS analysis
    - Report generation
    - Command sanitization and safe execution
    """

    # Kali Linux tool paths
    TOOLS = {
        "nmap": "/usr/bin/nmap",
        "dirsearch": "/usr/bin/dirsearch",
        "subfinder": "/usr/bin/subfinder",
        "httpx": "/usr/bin/httpx",
        "naabu": "/usr/bin/naabu",
        "nikto": "/usr/bin/nikto",
        "sqlmap": "/usr/bin/sqlmap",
        "wpscan": "/usr/bin/wpscan",
        "gobuster": "/usr/bin/gobuster",
        "ffuf": "/usr/bin/ffuf",
        "whatweb": "/usr/bin/whatweb",
        "theharvester": "/usr/bin/theHarvester",
        "amass": "/usr/bin/amass",
        "whois": "/usr/bin/whois",
        "dig": "/usr/bin/dig",
        "openssl": "/usr/bin/openssl",
    }

    # Risk levels for scan intensity
    SCAN_PROFILES = {
        "stealth": {
            "nmap_args": "-sS -T2 -p- --max-retries 2 --max-rtt-timeout 500ms",
            "description": "Slow, stealthy scan to avoid detection",
        },
        "normal": {
            "nmap_args": "-sV -sC -O --version-intensity 5",
            "description": "Standard scan with service detection",
        },
        "aggressive": {
            "nmap_args": "-sV -sC -A -O --version-intensity 9 --script vuln",
            "description": "Comprehensive scan with vulnerability detection",
        },
        "quick": {
            "nmap_args": "-sV -F --top-ports 1000",
            "description": "Fast scan of top 1000 ports",
        },
    }

    def __init__(self, config: Dict[str, Any], orchestrator: Optional[Any] = None):
        """
        Initialize security agent.
        
        Args:
            config: Agent configuration with cyber_security settings
            orchestrator: Parent orchestrator reference
        """
        super().__init__("SecurityAgent", config, orchestrator)
        
        self.sec_config = config.get("cyber_security", {})
        self.tools_path = self.sec_config.get("tools_path", "/usr/bin")
        self.wordlists = self.sec_config.get("wordlists", {})
        self.report_output = self.sec_config.get("report_output", "output/security_reports")
        self.max_scan_duration = self.sec_config.get("max_scan_duration_minutes", 60)
        self.rate_limit = self.sec_config.get("rate_limit_requests_per_second", 10)
        
        # Ensure report directory exists
        Path(self.report_output).mkdir(parents=True, exist_ok=True)
        
        logger.info("[SECURITY] SecurityAgent initialized - Tools: %s", list(self.TOOLS.keys()))

    async def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute security task.
        
        Payload options:
        - action: "port_scan" | "dir_bruteforce" | "subdomain_enum" |
                  "web_scan" | "ssl_scan" | "full_recon" | "whois" |
                  "dns_enum" | "vuln_scan" | "generate_report"
        - target: Target host/URL/IP
        - profile: Scan profile (stealth|normal|aggressive|quick)
        - ports: Specific ports to scan
        - wordlist: Custom wordlist path
        
        Returns:
            Security scan results
        """
        action = payload.get("action", "port_scan")
        
        action_map = {
            "port_scan": self._port_scan,
            "dir_bruteforce": self._dir_bruteforce,
            "subdomain_enum": self._subdomain_enum,
            "web_scan": self._web_scan,
            "ssl_scan": self._ssl_scan,
            "full_recon": self._full_recon,
            "whois": self._whois_lookup,
            "dns_enum": self._dns_enum,
            "vuln_scan": self._vuln_scan,
            "generate_report": self._generate_report,
        }

        handler = action_map.get(action)
        if not handler:
            return {"error": f"Unknown security action: {action}"}

        # Validate target
        target = payload.get("target", "")
        if not target and action != "generate_report":
            return {"error": "No target specified"}

        return await handler(payload)

    async def _port_scan(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute Nmap port scan.
        
        Target format: IP, hostname, or CIDR range
        """
        target = payload.get("target", "")
        profile = payload.get("profile", "normal")
        custom_ports = payload.get("ports", "")
        
        profile_config = self.SCAN_PROFILES.get(profile, self.SCAN_PROFILES["normal"])
        
        # Build nmap command
        nmap_cmd = [self.TOOLS["nmap"]]
        nmap_cmd.extend(profile_config["nmap_args"].split())
        
        if custom_ports:
            nmap_cmd.extend(["-p", custom_ports])
        
        # Add rate limiting
        nmap_cmd.extend(["--max-rate", str(self.rate_limit)])
        
        # Add output format
        xml_output = f"{self.report_output}/nmap_{self._sanitize_filename(target)}.xml"
        nmap_cmd.extend(["-oX", xml_output])
        
        nmap_cmd.append(target)

        result = await self._run_tool("nmap", nmap_cmd, timeout=self.max_scan_duration * 60)
        
        # Parse results
        open_ports = self._parse_nmap_output(result.get("stdout", ""))
        
        return {
            "scan_type": "port_scan",
            "target": target,
            "profile": profile,
            "command": " ".join(nmap_cmd),
            "open_ports": open_ports,
            "total_open": len(open_ports),
            "xml_report": xml_output if os.path.exists(xml_output) else None,
            "raw_output": result.get("stdout", "")[:2000],
            "execution_time": result.get("execution_time", 0),
            "timestamp": datetime.now().isoformat(),
        }

    def _parse_nmap_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse Nmap output for open ports."""
        open_ports = []
        
        for line in output.split("\n"):
            # Match lines like "80/tcp  open   http     Apache httpd 2.4.41"
            match = re.search(
                r"(\d+)/(tcp|udp)\s+(open|filtered|closed)\s+(\S+)\s*(.*)",
                line,
            )
            if match:
                port, protocol, state, service, version = match.groups()
                open_ports.append({
                    "port": int(port),
                    "protocol": protocol,
                    "state": state,
                    "service": service,
                    "version": version.strip(),
                    "risk": self._assess_port_risk(int(port), service),
                })
        
        return open_ports

    def _assess_port_risk(self, port: int, service: str) -> str:
        """Assess risk level of open port."""
        high_risk_ports = {21, 23, 25, 53, 110, 135, 139, 445, 1433, 3306, 3389, 5432, 5900, 8080}
        medium_risk_services = ["telnet", "ftp", "smtp", "snmp", "ms-wbt-server"]
        
        if port in high_risk_ports:
            return "high"
        if any(svc in service.lower() for svc in medium_risk_services):
            return "medium"
        return "low"

    async def _dir_bruteforce(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute directory brute-force using dirsearch or gobuster.
        """
        target = payload.get("target", "")
        wordlist = payload.get("wordlist", self.wordlists.get("dirb", "/usr/share/dirb/wordlists/common.txt"))
        extensions = payload.get("extensions", "php,html,js,txt,json,xml")
        threads = payload.get("threads", 50)

        # Try dirsearch first, fallback to gobuster
        tool_name = "dirsearch"
        tool_path = self.TOOLS["dirsearch"]
        
        if not os.path.exists(tool_path):
            tool_name = "gobuster"
            tool_path = self.TOOLS["gobuster"]
            cmd = [
                tool_path, "dir",
                "-u", target,
                "-w", wordlist,
                "-x", extensions,
                "-t", str(threads),
                "-o", f"{self.report_output}/dirs_{self._sanitize_filename(target)}.txt",
            ]
        else:
            cmd = [
                tool_path,
                "-u", target,
                "-w", wordlist,
                "-e", extensions,
                "-t", str(threads),
                "--json-report", f"{self.report_output}/dirs_{self._sanitize_filename(target)}.json",
            ]

        result = await self._run_tool(tool_name, cmd, timeout=1800)  # 30 min timeout
        
        # Parse found directories
        findings = self._parse_dirsearch_output(result.get("stdout", ""))
        
        return {
            "scan_type": "directory_bruteforce",
            "target": target,
            "tool": tool_name,
            "command": " ".join(cmd),
            "findings": findings,
            "total_found": len(findings),
            "interesting_findings": [f for f in findings if f.get("status") in [200, 301, 302, 401, 403]],
            "execution_time": result.get("execution_time", 0),
            "timestamp": datetime.now().isoformat(),
        }

    def _parse_dirsearch_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse dirsearch/gobuster output."""
        findings = []
        
        for line in output.split("\n"):
            # Match gobuster output: /admin (Status: 301) [Size: 169]
            match = re.search(r"(/\S+)\s+\(Status:\s+(\d+)\).*\[Size:\s+(\d+)\]", line)
            if match:
                path, status, size = match.groups()
                findings.append({
                    "path": path,
                    "status": int(status),
                    "size": int(size),
                    "interesting": int(status) in [200, 301, 401, 403, 500],
                })
        
        return findings

    async def _subdomain_enum(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enumerate subdomains using subfinder and amass.
        """
        target = payload.get("target", "")
        
        # Use subfinder
        subfinder_cmd = [
            self.TOOLS["subfinder"],
            "-d", target,
            "-all",
            "-o", f"{self.report_output}/subdomains_{self._sanitize_filename(target)}.txt",
        ]

        result = await self._run_tool("subfinder", subfinder_cmd, timeout=600)
        
        subdomains = [
            line.strip()
            for line in result.get("stdout", "").split("\n")
            if line.strip() and target in line
        ]

        # Probe with httpx
        alive_subdomains = []
        if subdomains:
            # Write subdomains to temp file for httpx
            temp_file = f"/tmp/subdomains_{self._sanitize_filename(target)}.txt"
            with open(temp_file, "w") as f:
                f.write("\n".join(subdomains))

            httpx_cmd = [
                self.TOOLS["httpx"],
                "-l", temp_file,
                "-o", f"{self.report_output}/alive_subdomains_{self._sanitize_filename(target)}.txt",
            ]
            
            httpx_result = await self._run_tool("httpx", httpx_cmd, timeout=300)
            alive_subdomains = [
                line.strip()
                for line in httpx_result.get("stdout", "").split("\n")
                if line.strip()
            ]

        return {
            "scan_type": "subdomain_enumeration",
            "target": target,
            "total_subdomains": len(subdomains),
            "alive_subdomains": len(alive_subdomains),
            "subdomains": subdomains[:100],  # Limit output
            "alive_list": alive_subdomains[:50],
            "timestamp": datetime.now().isoformat(),
        }

    async def _web_scan(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute web vulnerability scan using Nikto.
        """
        target = payload.get("target", "")
        
        nikto_cmd = [
            self.TOOLS["nikto"],
            "-h", target,
            "-Format", "json",
            "-o", f"{self.report_output}/nikto_{self._sanitize_filename(target)}.json",
        ]

        result = await self._run_tool("nikto", nikto_cmd, timeout=1800)
        
        # Parse findings
        vulnerabilities = self._parse_nikto_output(result.get("stdout", ""))
        
        return {
            "scan_type": "web_vulnerability_scan",
            "target": target,
            "command": " ".join(nikto_cmd),
            "vulnerabilities": vulnerabilities,
            "risk_summary": self._summarize_vulns(vulnerabilities),
            "timestamp": datetime.now().isoformat(),
        }

    def _parse_nikto_output(self, output: str) -> List[Dict[str, Any]]:
        """Parse Nikto scan output."""
        vulns = []
        
        for line in output.split("\n"):
            # Nikto output patterns
            if "OSVDB" in line or "CVE" in line:
                match = re.search(r"(OSVDB-\d+|CVE-\d{4}-\d+):\s*(.+)", line)
                if match:
                    vulns.append({
                        "id": match.group(1),
                        "description": match.group(2),
                        "severity": "medium",  # Default, would need CVSS lookup
                    })
            elif "X-" in line and "Header" in line:
                vulns.append({
                    "type": "header",
                    "description": line.strip(),
                    "severity": "low",
                })
        
        return vulns

    def _summarize_vulns(self, vulns: List[Dict[str, Any]]) -> Dict[str, int]:
        """Summarize vulnerability counts by severity."""
        summary = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for v in vulns:
            sev = v.get("severity", "info")
            summary[sev] = summary.get(sev, 0) + 1
        return summary

    async def _ssl_scan(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        SSL/TLS security scan.
        """
        target = payload.get("target", "")
        port = payload.get("port", 443)
        
        # Use OpenSSL for SSL analysis
        openssl_cmd = [
            self.TOOLS["openssl"], "s_client",
            "-connect", f"{target}:{port}",
            "-servername", target,
        ]

        result = await self._run_tool("openssl", openssl_cmd, timeout=60)
        
        # Analyze SSL output
        ssl_info = self._parse_ssl_output(result.get("stdout", ""))
        
        return {
            "scan_type": "ssl_scan",
            "target": target,
            "port": port,
            "ssl_info": ssl_info,
            "recommendations": self._ssl_recommendations(ssl_info),
            "timestamp": datetime.now().isoformat(),
        }

    def _parse_ssl_output(self, output: str) -> Dict[str, Any]:
        """Parse OpenSSL s_client output."""
        info = {
            "protocol": None,
            "cipher": None,
            "certificate": {},
        }
        
        for line in output.split("\n"):
            if "Protocol" in line and ":" in line:
                info["protocol"] = line.split(":")[-1].strip()
            elif "Cipher" in line and ":" in line:
                info["cipher"] = line.split(":")[-1].strip()
            elif "subject=" in line:
                info["certificate"]["subject"] = line.split("subject=")[-1]
            elif "issuer=" in line:
                info["certificate"]["issuer"] = line.split("issuer=")[-1]
        
        return info

    def _ssl_recommendations(self, ssl_info: Dict[str, Any]) -> List[str]:
        """Generate SSL hardening recommendations."""
        recs = []
        protocol = ssl_info.get("protocol", "")
        
        if "TLSv1.0" in protocol or "TLSv1.1" in protocol or "SSLv" in protocol:
            recs.append("UPGRADE: Disable TLS 1.0/1.1, enforce TLS 1.2+")
        
        if ssl_info.get("cipher"):
            cipher = ssl_info["cipher"]
            if "NULL" in cipher or "EXPORT" in cipher or "RC4" in cipher:
                recs.append("WEAK CIPHER: Disable weak cipher suites")
        
        if not recs:
            recs.append("SSL configuration looks good. Enable HSTS header.")
        
        return recs

    async def _full_recon(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Full reconnaissance - combines multiple scans.
        """
        target = payload.get("target", "")
        
        logger.info("[SECURITY] Starting full recon on %s", target)
        
        # Run scans in parallel where possible
        results = {}
        
        # Phase 1: WHOIS + DNS (fast, run in parallel)
        whois_task = asyncio.create_task(self._whois_lookup({"target": target}))
        dns_task = asyncio.create_task(self._dns_enum({"target": target}))
        
        results["whois"] = await whois_task
        results["dns"] = await dns_task
        
        # Phase 2: Port scan
        results["port_scan"] = await self._port_scan({
            **payload,
            "profile": "normal",
        })
        
        # Phase 3: Web scan if web ports open
        open_ports = [p["port"] for p in results["port_scan"].get("open_ports", [])]
        if 80 in open_ports or 443 in open_ports or 8080 in open_ports:
            web_payload = {"target": f"http://{target}" if 80 in open_ports else f"https://{target}"}
            results["web_scan"] = await self._web_scan(web_payload)
            results["directories"] = await self._dir_bruteforce(web_payload)
        
        # Phase 4: Subdomain enumeration
        results["subdomains"] = await self._subdomain_enum({"target": target})
        
        # Generate comprehensive report
        report_file = await self._save_full_report(target, results)
        
        return {
            "scan_type": "full_reconnaissance",
            "target": target,
            "phases_completed": list(results.keys()),
            "results": results,
            "risk_assessment": self._assess_overall_risk(results),
            "report_file": report_file,
            "timestamp": datetime.now().isoformat(),
        }

    async def _whois_lookup(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Perform WHOIS lookup."""
        target = payload.get("target", "")
        
        cmd = [self.TOOLS["whois"], target]
        result = await self._run_tool("whois", cmd, timeout=30)
        
        # Parse WHOIS data
        whois_data = {}
        for line in result.get("stdout", "").split("\n"):
            if ":" in line and not line.startswith("%"):
                key, value = line.split(":", 1)
                whois_data[key.strip()] = value.strip()
        
        return {
            "scan_type": "whois",
            "target": target,
            "registrar": whois_data.get("Registrar", "N/A"),
            "creation_date": whois_data.get("Creation Date", "N/A"),
            "expiration_date": whois_data.get("Registry Expiry Date", "N/A"),
            "name_servers": whois_data.get("Name Server", "N/A"),
            "raw": whois_data,
        }

    async def _dns_enum(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """DNS enumeration with dig."""
        target = payload.get("target", "")
        
        # A records
        a_cmd = [self.TOOLS["dig"], target, "A", "+short"]
        a_result = await self._run_tool("dig", a_cmd, timeout=30)
        
        # MX records
        mx_cmd = [self.TOOLS["dig"], target, "MX", "+short"]
        mx_result = await self._run_tool("dig", mx_cmd, timeout=30)
        
        # NS records
        ns_cmd = [self.TOOLS["dig"], target, "NS", "+short"]
        ns_result = await self._run_tool("dig", ns_cmd, timeout=30)
        
        # TXT records (SPF, DMARC)
        txt_cmd = [self.TOOLS["dig"], target, "TXT", "+short"]
        txt_result = await self._run_tool("dig", txt_cmd, timeout=30)

        return {
            "scan_type": "dns_enumeration",
            "target": target,
            "a_records": [l.strip() for l in a_result.get("stdout", "").split("\n") if l.strip()],
            "mx_records": [l.strip() for l in mx_result.get("stdout", "").split("\n") if l.strip()],
            "ns_records": [l.strip() for l in ns_result.get("stdout", "").split("\n") if l.strip()],
            "txt_records": [l.strip() for l in txt_result.get("stdout", "").split("\n") if l.strip()],
        }

    async def _vuln_scan(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Vulnerability scan with SQLMap or WPScan.
        """
        target = payload.get("target", "")
        scan_type = payload.get("vuln_type", "web")
        
        if "wordpress" in target.lower() or scan_type == "wordpress":
            cmd = [
                self.TOOLS["wpscan"],
                "--url", target,
                "--enumerate", "vp,vt,cb",
                "-o", f"{self.report_output}/wpscan_{self._sanitize_filename(target)}.json",
                "-f", "json",
            ]
            result = await self._run_tool("wpscan", cmd, timeout=1800)
        else:
            # Generic web vuln scan with nmap scripts
            cmd = [
                self.TOOLS["nmap"],
                "--script", "http-vuln-*,ssl-heartbleed,ssl-poodle",
                "-p", "80,443,8080",
                target,
            ]
            result = await self._run_tool("nmap", cmd, timeout=1800)
        
        return {
            "scan_type": "vulnerability_scan",
            "target": target,
            "tool_used": "wpscan" if "wordpress" in target.lower() else "nmap-vuln",
            "output": result.get("stdout", "")[:3000],
            "timestamp": datetime.now().isoformat(),
        }

    async def _generate_report(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive security report."""
        target = payload.get("target", "")
        scan_results = payload.get("scan_results", {})
        
        report = {
            "report_title": f"Security Assessment Report - {target}",
            "generated_at": datetime.now().isoformat(),
            "executive_summary": self._generate_executive_summary(scan_results),
            "findings": scan_results,
            "recommendations": self._generate_recommendations(scan_results),
            "risk_matrix": self._build_risk_matrix(scan_results),
        }
        
        # Save report
        report_file = f"{self.report_output}/final_report_{self._sanitize_filename(target)}.json"
        with open(report_file, "w") as f:
            json.dump(report, f, indent=2)
        
        return {
            "scan_type": "report_generation",
            "report_file": report_file,
            "summary": report["executive_summary"],
            "total_findings": sum(
                len(v.get("vulnerabilities", [])) 
                for v in scan_results.values() 
                if isinstance(v, dict)
            ),
        }

    def _generate_executive_summary(self, results: Dict[str, Any]) -> str:
        """Generate executive summary from scan results."""
        summaries = []
        
        if "port_scan" in results:
            open_ports = results["port_scan"].get("total_open", 0)
            summaries.append(f"Port scan identified {open_ports} open ports.")
        
        if "web_scan" in results:
            vulns = len(results["web_scan"].get("vulnerabilities", []))
            summaries.append(f"Web scan found {vulns} potential issues.")
        
        if "subdomains" in results:
            subs = results["subdomains"].get("total_subdomains", 0)
            summaries.append(f"Subdomain enumeration discovered {subs} subdomains.")
        
        return " ".join(summaries) if summaries else "Security assessment completed."

    def _generate_recommendations(self, results: Dict[str, Any]) -> List[str]:
        """Generate security recommendations."""
        recs = []
        
        if "port_scan" in results:
            high_risk = [
                p for p in results["port_scan"].get("open_ports", [])
                if p.get("risk") == "high"
            ]
            if high_risk:
                ports = ", ".join(str(p["port"]) for p in high_risk)
                recs.append(f"Close or restrict access to high-risk ports: {ports}")
        
        if "ssl_scan" in results:
            recs.extend(results["ssl_scan"].get("recommendations", []))
        
        recs.extend([
            "Implement Web Application Firewall (WAF)",
            "Enable centralized logging and monitoring",
            "Conduct regular penetration testing",
            "Keep all software and dependencies updated",
        ])
        
        return recs

    def _build_risk_matrix(self, results: Dict[str, Any]) -> Dict[str, int]:
        """Build risk assessment matrix."""
        matrix = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        
        for scan_type, scan_data in results.items():
            if isinstance(scan_data, dict) and "risk_summary" in scan_data:
                for level, count in scan_data["risk_summary"].items():
                    matrix[level] = matrix.get(level, 0) + count
        
        return matrix

    def _assess_overall_risk(self, results: Dict[str, Any]) -> str:
        """Assess overall risk level."""
        risk_score = 0
        
        if "port_scan" in results:
            high_risk_ports = sum(
                1 for p in results["port_scan"].get("open_ports", [])
                if p.get("risk") == "high"
            )
            risk_score += high_risk_ports * 10
        
        if "web_scan" in results:
            vulns = len(results["web_scan"].get("vulnerabilities", []))
            risk_score += vulns * 5
        
        if risk_score > 50:
            return "CRITICAL"
        elif risk_score > 30:
            return "HIGH"
        elif risk_score > 10:
            return "MEDIUM"
        return "LOW"

    async def _run_tool(
        self, 
        tool_name: str, 
        cmd: List[str], 
        timeout: int = 300,
    ) -> Dict[str, Any]:
        """
        Execute security tool with safety checks.
        
        Args:
            tool_name: Name of the tool
            cmd: Command arguments
            timeout: Maximum execution time
            
        Returns:
            Tool execution results
        """
        start_time = __import__("time").time()
        
        try:
            logger.info("[SECURITY] Running %s: %s", tool_name, " ".join(cmd[:5]) + "...")
            
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
            
            execution_time = __import__("time").time() - start_time
            
            return {
                "tool": tool_name,
                "return_code": proc.returncode,
                "stdout": stdout.decode("utf-8", errors="replace"),
                "stderr": stderr.decode("utf-8", errors="replace"),
                "execution_time": round(execution_time, 2),
                "success": proc.returncode == 0,
            }

        except asyncio.TimeoutError:
            logger.warning("[SECURITY] %s timed out after %ds", tool_name, timeout)
            return {
                "tool": tool_name,
                "error": f"Timeout after {timeout}s",
                "execution_time": timeout,
                "success": False,
            }
        except Exception as e:
            logger.error("[SECURITY] %s error: %s", tool_name, e)
            return {
                "tool": tool_name,
                "error": str(e),
                "success": False,
            }

    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize target name for use in filenames."""
        return re.sub(r'[^a-zA-Z0-9._-]', '_', filename)[:50]

    async def _save_full_report(self, target: str, results: Dict[str, Any]) -> str:
        """Save full recon report to file."""
        report_file = f"{self.report_output}/full_recon_{self._sanitize_filename(target)}.json"
        
        report = {
            "target": target,
            "generated_at": datetime.now().isoformat(),
            "results": results,
        }
        
        with open(report_file, "w") as f:
            json.dump(report, f, indent=2, default=str)
        
        return report_file
