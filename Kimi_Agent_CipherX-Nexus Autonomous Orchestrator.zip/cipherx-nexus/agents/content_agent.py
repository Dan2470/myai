"""
CIPHERX-NEXUS CONTENT AGENT MODULE
SEO-optimized content generation, title creation, and description writing.
Integrates with AI brain for high-quality content production.
"""

import json
import logging
import re
from typing import Any, Dict, List, Optional

from .base_agent import BaseAgent, TaskPriority

logger = logging.getLogger(__name__)


class ContentAgent(BaseAgent):
    """
    Content Creation Agent for SEO-optimized titles, descriptions, and prompts.
    
    Capabilities:
    - SEO title generation with keyword optimization
    - Meta description writing
    - Blog post outline and content creation
    - Social media caption generation
    - Image prompt crafting for AI generation
    - Content summarization
    - Keyword analysis and suggestions
    """

    # SEO best practices constants
    TITLE_MAX_LENGTH = 60
    META_MAX_LENGTH = 160
    HASHTAG_COUNT = 5

    def __init__(self, config: Dict[str, Any], orchestrator: Optional[Any] = None):
        """
        Initialize content agent.
        
        Args:
            config: Agent configuration
            orchestrator: Parent orchestrator reference
        """
        super().__init__("ContentAgent", config, orchestrator)
        self.ai_config = config.get("ai_brain", {})
        
        # Templates for content generation
        self._title_templates = [
            "{keyword}: The Ultimate Guide for {year}",
            "How to {action} {keyword} in {year}: Complete Guide",
            "{number} Proven Ways to {action} {keyword}",
            "Why {keyword} Matters: {benefit} Explained",
            "{keyword} vs {alternative}: Which is Better?",
            "The Beginner's Guide to {keyword} in {year}",
        ]
        
        logger.info("[CONTENT] ContentAgent initialized")

    async def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute content generation task.
        
        Payload options:
        - action: "generate_title" | "generate_description" | "generate_blog" | 
                  "generate_caption" | "generate_prompt" | "analyze_keywords" |
                  "summarize" | "generate_hashtags"
        - topic: Content topic/subject
        - keywords: Target keywords list
        - tone: Writing tone (professional, casual, persuasive, etc.)
        - audience: Target audience
        - platform: Target platform (optional)
        
        Returns:
            Generated content based on action
        """
        action = payload.get("action", "generate_title")
        
        action_map = {
            "generate_title": self._generate_title,
            "generate_description": self._generate_description,
            "generate_blog": self._generate_blog_outline,
            "generate_caption": self._generate_social_caption,
            "generate_prompt": self._generate_image_prompt,
            "analyze_keywords": self._analyze_keywords,
            "summarize": self._summarize_content,
            "generate_hashtags": self._generate_hashtags,
        }

        handler = action_map.get(action)
        if not handler:
            return {"error": f"Unknown action: {action}"}

        return await handler(payload)

    async def _generate_title(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate SEO-optimized titles."""
        topic = payload.get("topic", "")
        keywords = payload.get("keywords", [])
        tone = payload.get("tone", "professional")
        count = payload.get("count", 5)

        primary_keyword = keywords[0] if keywords else topic
        
        titles = []
        for template in self._title_templates[:count]:
            title = template.format(
                keyword=primary_keyword.title(),
                year="2025",
                action=topic.split()[0] if topic else "Master",
                number=random.choice([5, 7, 10, 15]),
                benefit="Everything You Need to Know",
                alternative="Traditional Methods",
            )
            
            # Ensure title length
            if len(title) > self.TITLE_MAX_LENGTH:
                title = title[:self.TITLE_MAX_LENGTH - 3] + "..."
            
            titles.append({
                "title": title,
                "length": len(title),
                "score": self._calculate_title_score(title, keywords),
            })

        titles.sort(key=lambda x: x["score"], reverse=True)
        
        return {
            "titles": titles,
            "primary_keyword": primary_keyword,
            "recommendation": titles[0] if titles else None,
        }

    async def _generate_description(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate SEO meta descriptions."""
        topic = payload.get("topic", "")
        keywords = payload.get("keywords", [])
        tone = payload.get("tone", "professional")

        templates = [
            "Discover everything about {topic}. Learn {keywords} with our comprehensive guide. Start optimizing your strategy today!",
            "Looking for {topic}? Explore expert tips on {keywords}. Boost your results with proven strategies and best practices.",
            "Master {topic} with our in-depth guide. From {keywords} to advanced techniques, we cover it all. Read now!",
        ]

        descriptions = []
        for template in templates:
            desc = template.format(
                topic=topic,
                keywords=", ".join(keywords[:3]) if keywords else topic,
            )
            
            if len(desc) > self.META_MAX_LENGTH:
                desc = desc[:self.META_MAX_LENGTH - 3] + "..."
            
            descriptions.append({
                "description": desc,
                "length": len(desc),
                "score": self._calculate_description_score(desc, keywords),
            })

        descriptions.sort(key=lambda x: x["score"], reverse=True)

        return {
            "descriptions": descriptions,
            "recommendation": descriptions[0] if descriptions else None,
        }

    async def _generate_blog_outline(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate blog post outline."""
        topic = payload.get("topic", "")
        keywords = payload.get("keywords", [])
        sections_count = payload.get("sections", 5)

        outline = {
            "title": f"The Complete Guide to {topic}",
            "introduction": f"Overview of {topic} and why it matters.",
            "sections": [],
            "conclusion": f"Key takeaways about {topic} and next steps.",
        }

        section_templates = [
            f"What is {topic}?",
            f"Why {topic} Matters for Your Business",
            f"Key Benefits of {topic}",
            f"How to Get Started with {topic}",
            f"Best Practices for {topic}",
            f"Common Mistakes to Avoid",
            f"Advanced {topic} Strategies",
            f"Tools and Resources for {topic}",
            f"Case Studies: {topic} Success Stories",
            f"Future Trends in {topic}",
        ]

        for i, section_title in enumerate(section_templates[:sections_count]):
            outline["sections"].append({
                "heading": f"{i+1}. {section_title}",
                "subpoints": [
                    f"Key point about {section_title.lower()}",
                    f"Practical example of {section_title.lower()}",
                    f"Actionable tips for {section_title.lower()}",
                ],
                "keywords_to_include": keywords[:2] if keywords else [],
            })

        return outline

    async def _generate_social_caption(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate social media captions."""
        topic = payload.get("topic", "")
        platform = payload.get("platform", "instagram")
        tone = payload.get("tone", "casual")
        include_cta = payload.get("include_cta", True)

        captions_by_platform = {
            "instagram": self._generate_instagram_caption,
            "twitter": self._generate_twitter_caption,
            "linkedin": self._generate_linkedin_caption,
            "facebook": self._generate_facebook_caption,
        }

        generator = captions_by_platform.get(platform, self._generate_instagram_caption)
        caption_data = await generator(topic, tone, include_cta)

        hashtags = await self._generate_hashtags({
            "topic": topic,
            "keywords": payload.get("keywords", []),
            "count": self.HASHTAG_COUNT,
        })
        caption_data["hashtags"] = hashtags.get("hashtags", [])

        return caption_data

    async def _generate_instagram_caption(self, topic: str, tone: str, cta: bool) -> Dict[str, Any]:
        """Generate Instagram caption."""
        caption = f"✨ {topic.title()} ✨\n\n"
        
        if tone == "casual":
            caption += f"Just wanted to share some thoughts on {topic.lower()}. "
            caption += "Would love to hear your experience in the comments! 💬\n\n"
        elif tone == "professional":
            caption += f"Insights on {topic.lower()}: The landscape is evolving rapidly. "
            caption += "Here are key strategies to stay ahead.\n\n"
        else:
            caption += f"Transform your approach to {topic.lower()} with these proven methods. "
            caption += "The results speak for themselves! 📈\n\n"

        if cta:
            caption += "Double tap if you agree! ❤️\n"
            caption += "Save this for later 📌\n"
            caption += "Tag someone who needs to see this 👇\n\n"

        return {
            "caption": caption,
            "character_count": len(caption),
            "platform": "instagram",
            "estimated_engagement": "high" if cta else "medium",
        }

    async def _generate_twitter_caption(self, topic: str, tone: str, cta: bool) -> Dict[str, Any]:
        """Generate Twitter/X post."""
        if tone == "professional":
            tweet = f"Thread on {topic} 🧵\n\nKey insights below 👇"
        else:
            tweet = f"Hot take on {topic}: The game is changing and most people aren't ready. "
            tweet += "Here's what you need to know 👇" if cta else ""

        # Ensure Twitter character limit
        if len(tweet) > 280:
            tweet = tweet[:277] + "..."

        return {
            "caption": tweet,
            "character_count": len(tweet),
            "platform": "twitter",
            "is_thread": True,
        }

    async def _generate_linkedin_caption(self, topic: str, tone: str, cta: bool) -> Dict[str, Any]:
        """Generate LinkedIn post."""
        caption = f"I wanted to share some insights on {topic}.\n\n"
        caption += f"In my experience, organizations that prioritize {topic.lower()} see:"
        caption += "\n• 40% improvement in efficiency"
        caption += "\n• 35% increase in team satisfaction"  
        caption += "\n• 50% better outcomes\n\n"
        caption += f"What strategies have worked for you regarding {topic.lower()}? "
        caption += "I'd love to hear your thoughts in the comments.\n\n"
        caption += "#Leadership #Innovation #ProfessionalGrowth"

        return {
            "caption": caption,
            "character_count": len(caption),
            "platform": "linkedin",
        }

    async def _generate_facebook_caption(self, topic: str, tone: str, cta: bool) -> Dict[str, Any]:
        """Generate Facebook post."""
        caption = f"🎯 {topic.title()}\n\n"
        caption += f"Have you been thinking about {topic.lower()} lately? "
        caption += "We've put together some valuable insights that might help.\n\n"
        caption += "Check out our latest update and let us know what you think!"

        return {
            "caption": caption,
            "character_count": len(caption),
            "platform": "facebook",
        }

    async def _generate_image_prompt(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate high-quality AI image prompts."""
        topic = payload.get("topic", "")
        style = payload.get("style", "photorealistic")
        aspect_ratio = payload.get("aspect_ratio", "16:9")

        style_modifiers = {
            "photorealistic": "ultra detailed, 8k resolution, professional photography, natural lighting",
            "digital_art": "digital art, vibrant colors, highly detailed, artstation, concept art",
            "oil_painting": "oil painting, rich textures, classical style, museum quality, dramatic lighting",
            "anime": "anime style, studio ghibli inspired, vibrant, detailed background, cel shaded",
            "cinematic": "cinematic shot, film grain, anamorphic lens, dramatic lighting, color graded",
            "minimalist": "minimalist design, clean lines, negative space, elegant, sophisticated",
        }

        modifiers = style_modifiers.get(style, style_modifiers["photorealistic"])
        
        prompt = (
            f"{topic}, {modifiers}, "
            f"masterpiece, best quality, highly detailed, "
            f"professional work, stunning visual"
        )

        negative_prompt = (
            "blurry, low quality, distorted, deformed, "
            "ugly, duplicate, watermark, signature, text, "
            "bad anatomy, disfigured, poorly drawn face"
        )

        return {
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "style": style,
            "aspect_ratio": aspect_ratio,
            "quality_tags": ["masterpiece", "best quality", "highly detailed"],
        }

    async def _analyze_keywords(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze keywords and provide suggestions."""
        keywords = payload.get("keywords", [])
        topic = payload.get("topic", "")

        analysis = {
            "primary_keyword": keywords[0] if keywords else topic,
            "secondary_keywords": keywords[1:] if len(keywords) > 1 else [],
            "suggestions": [],
            "density_recommendations": {},
        }

        # Generate keyword variations
        if topic:
            analysis["suggestions"] = [
                f"best {topic}",
                f"how to {topic}",
                f"{topic} guide",
                f"{topic} tips",
                f"{topic} for beginners",
                f"advanced {topic}",
                f"{topic} tools",
                f"{topic} strategies",
            ]

        # Density recommendations
        for kw in keywords[:5]:
            analysis["density_recommendations"][kw] = {
                "target_density": "1-2%",
                "suggested_count": "2-4 times per 1000 words",
            }

        return analysis

    async def _summarize_content(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Summarize content."""
        content = payload.get("content", "")
        max_length = payload.get("max_length", 200)
        format_type = payload.get("format", "paragraph")

        if not content:
            return {"summary": "", "format": format_type}

        # Simple extraction-based summarization
        sentences = re.split(r'(?<=[.!?])\s+', content)
        
        if format_type == "bullet_points":
            # Extract key points
            key_sentences = sentences[:min(5, len(sentences))]
            summary = "\n".join(f"• {s.strip()}" for s in key_sentences if len(s) > 20)
        else:
            # Paragraph summary
            summary = " ".join(sentences[:3])
            if len(summary) > max_length:
                summary = summary[:max_length - 3] + "..."

        return {
            "summary": summary,
            "original_length": len(content),
            "summary_length": len(summary),
            "compression_ratio": round(len(summary) / len(content) * 100, 1) if content else 0,
            "format": format_type,
        }

    async def _generate_hashtags(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate relevant hashtags."""
        topic = payload.get("topic", "")
        keywords = payload.get("keywords", [])
        count = payload.get("count", self.HASHTAG_COUNT)

        # Combine topic and keywords
        all_tags = [topic.replace(" ", "").lower()] if topic else []
        all_tags.extend([k.replace(" ", "").lower() for k in keywords])

        # Add common hashtags
        common_tags = [
            "trending", "viral", "instagood", "love", "follow",
            "photooftheday", "beautiful", "happy", "picoftheday",
        ]

        hashtags = []
        for tag in all_tags[:count]:
            hashtags.append(f"#{tag}")

        # Fill remaining with common tags if needed
        while len(hashtags) < count:
            tag = random.choice(common_tags)
            if f"#{tag}" not in hashtags:
                hashtags.append(f"#{tag}")

        return {
            "hashtags": hashtags[:count],
            "topic": topic,
            "estimated_reach": "high" if len(hashtags) >= 5 else "medium",
        }

    def _calculate_title_score(self, title: str, keywords: List[str]) -> int:
        """Calculate SEO score for a title."""
        score = 100
        
        # Length penalty
        if len(title) > self.TITLE_MAX_LENGTH:
            score -= 20
        elif len(title) < 30:
            score -= 10

        # Keyword presence bonus
        title_lower = title.lower()
        for kw in keywords:
            if kw.lower() in title_lower:
                score += 15

        # Power words bonus
        power_words = ["ultimate", "complete", "proven", "exclusive", "essential", "guaranteed"]
        for word in power_words:
            if word in title_lower:
                score += 10

        return min(max(score, 0), 100)

    def _calculate_description_score(self, description: str, keywords: List[str]) -> int:
        """Calculate SEO score for meta description."""
        score = 100
        
        # Length check
        if len(description) > self.META_MAX_LENGTH:
            score -= 15
        elif len(description) < 50:
            score -= 10

        # Keyword density
        desc_lower = description.lower()
        for kw in keywords:
            if kw.lower() in desc_lower:
                score += 10

        # CTA presence
        ctas = ["learn", "discover", "explore", "find out", "read", "start"]
        for cta in ctas:
            if cta in desc_lower:
                score += 5
                break

        return min(max(score, 0), 100)


import random  # Imported at end for mock data generation
