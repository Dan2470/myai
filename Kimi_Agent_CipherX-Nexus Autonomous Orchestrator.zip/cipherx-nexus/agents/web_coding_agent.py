"""
CIPHERX-NEXUS WEB CODING AGENT MODULE
Expert Laravel, PHP, MySQL, and Python coding assistant.
Handles code generation, debugging, and project scaffolding.
"""

import json
import logging
import os
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class WebCodingAgent(BaseAgent):
    """
    Web/AI Coding Agent for development tasks.
    
    Capabilities:
    - Laravel/PHP code generation and debugging
    - MySQL query optimization
    - Python script development
    - Project scaffolding and setup
    - Code review and analysis
    - Git operations
    - Docker configuration
    """

    SUPPORTED_LANGUAGES = ["php", "python", "javascript", "typescript", "sql", "bash"]

    def __init__(self, config: Dict[str, Any], orchestrator: Optional[Any] = None):
        """
        Initialize web coding agent.
        
        Args:
            config: Agent configuration with web_coding settings
            orchestrator: Parent orchestrator reference
        """
        super().__init__("WebCodingAgent", config, orchestrator)
        
        self.web_config = config.get("web_coding", {})
        self.laravel_path = self.web_config.get("laravel_path", "/var/www/laravel")
        self.php_version = self.web_config.get("php_version", "8.2")
        self.python_path = self.web_config.get("python_path", "/usr/bin/python3")
        self.node_path = self.web_config.get("node_path", "/usr/bin/node")
        
        # Code templates
        self._templates = self._load_templates()
        
        logger.info("[CODING] WebCodingAgent initialized - PHP %s", self.php_version)

    def _load_templates(self) -> Dict[str, str]:
        """Load code templates."""
        return {
            "laravel_controller": """<?php

namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;
use Illuminate\\Http\\JsonResponse;

class {class_name} extends Controller
{{
    /**
     * Display a listing of the resource.
     */
    public function index(): JsonResponse
    {{
        // Implementation here
        return response()->json(['data' => []]);
    }}

    /**
     * Store a newly created resource.
     */
    public function store(Request $request): JsonResponse
    {{
        $validated = $request->validate([
            // Validation rules
        ]);
        
        // Implementation here
        return response()->json(['message' => 'Created successfully'], 201);
    }}

    /**
     * Display the specified resource.
     */
    public function show(int $id): JsonResponse
    {{
        // Implementation here
        return response()->json(['data' => []]);
    }}

    /**
     * Update the specified resource.
     */
    public function update(Request $request, int $id): JsonResponse
    {{
        $validated = $request->validate([
            // Validation rules
        ]);
        
        // Implementation here
        return response()->json(['message' => 'Updated successfully']);
    }}

    /**
     * Remove the specified resource.
     */
    public function destroy(int $id): JsonResponse
    {{
        // Implementation here
        return response()->json(['message' => 'Deleted successfully']);
    }}
}}
""",
            "laravel_model": """<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\Relations;
use Illuminate\\Database\\Eloquent\\SoftDeletes;

class {class_name} extends Model
{{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        // Fillable attributes
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    protected $hidden = [
        // Hidden attributes
    ];

    // Relationships
    // public function user(): Relations\\BelongsTo
    // {{
    //     return $this->belongsTo(User::class);
    // }}
}}
""",
            "laravel_migration": """<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{{
    /**
     * Run the migrations.
     */
    public function up(): void
    {{
        Schema::create('{table_name}', function (Blueprint $table) {{
            $table->id();
            // Add your columns here
            $table->string('name');
            $table->text('description')->nullable();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->timestamps();
            $table->softDeletes();
        }});
    }}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {{
        Schema::dropIfExists('{table_name}');
    }}
}};
""",
            "python_script": """#!/usr/bin/env python3
\"\"\"
{description}
Author: CipherX-Nexus
Date: {date}
\"\"\"

import argparse
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    \"\"\"Main function.\"\"\"
    parser = argparse.ArgumentParser(description='{description}')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # Your implementation here
        logger.info('Process started')
        
        # Main logic
        
        logger.info('Process completed successfully')
        return 0
        
    except Exception as e:
        logger.error(f'Error: {{e}}')
        return 1


if __name__ == '__main__':
    exit(main())
""",
        }

    async def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute coding task.
        
        Payload options:
        - action: "generate_code" | "debug_code" | "scaffold_project" |
                  "review_code" | "optimize_query" | "run_script" | "git_operation"
        - language: Target language
        - code: Existing code (for debug/review)
        - description: What to generate
        - project_type: "laravel" | "react" | "vue" | "python"
        
        Returns:
            Coding task result
        """
        action = payload.get("action", "generate_code")
        
        action_map = {
            "generate_code": self._generate_code,
            "debug_code": self._debug_code,
            "scaffold_project": self._scaffold_project,
            "review_code": self._review_code,
            "optimize_query": self._optimize_query,
            "run_script": self._run_script,
            "git_operation": self._git_operation,
        }

        handler = action_map.get(action)
        if not handler:
            return {"error": f"Unknown action: {action}"}

        return await handler(payload)

    async def _generate_code(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Generate code based on description."""
        language = payload.get("language", "php")
        description = payload.get("description", "")
        component_type = payload.get("component_type", "general")

        if language == "php" and component_type in ["controller", "model", "migration"]:
            code = self._generate_laravel_component(component_type, payload)
        elif language == "python":
            code = self._templates["python_script"].format(
                description=description,
                date=__import__("datetime").datetime.now().strftime("%Y-%m-%d"),
            )
        else:
            code = self._generate_generic_code(language, description)

        return {
            "code": code,
            "language": language,
            "component_type": component_type,
            "line_count": len(code.split("\n")),
            "notes": self._get_code_notes(language, component_type),
        }

    def _generate_laravel_component(self, component_type: str, payload: Dict[str, Any]) -> str:
        """Generate Laravel component code."""
        class_name = payload.get("class_name", "Example")
        table_name = payload.get("table_name", "examples")

        template_key = f"laravel_{component_type}"
        template = self._templates.get(template_key, "")
        
        return template.format(class_name=class_name, table_name=table_name)

    def _generate_generic_code(self, language: str, description: str) -> str:
        """Generate generic code snippet."""
        templates = {
            "javascript": f"// {{description}}\nfunction implementation() {{\n  // TODO: Implement\n  console.log('Implementation pending');\n}}\n\nmodule.exports = {{ implementation }};",
            "typescript": f"// {{description}}\ninterface Props {{\n  // Define props\n}}\n\nfunction Component(props: Props): JSX.Element {{\n  return <div>Implementation</div>;\n}}\n\nexport default Component;",
            "sql": f"-- {{description}}\nSELECT *\nFROM table_name\nWHERE condition = true\nORDER BY created_at DESC\nLIMIT 100;",
            "bash": f"#!/bin/bash\n# {{description}}\nset -euo pipefail\n\necho 'Starting process...'\n# Implementation here\necho 'Process complete!'",
        }
        return templates.get(language, f"# {description}\n# Implementation in {language}")

    async def _debug_code(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Debug existing code."""
        code = payload.get("code", "")
        language = payload.get("language", "")
        error_message = payload.get("error_message", "")

        issues = []
        suggestions = []

        # PHP-specific checks
        if language == "php":
            if "mysql_" in code and "mysqli_" not in code:
                issues.append("Using deprecated mysql_* functions. Use PDO or mysqli.")
                suggestions.append("Replace with PDO prepared statements for security.")
            
            if "$_GET" in code or "$_POST" in code:
                if "htmlspecialchars" not in code and "filter_input" not in code:
                    issues.append("Potential XSS vulnerability: Input not sanitized.")
                    suggestions.append("Use htmlspecialchars() or filter_input() for user input.")
            
            if "eval(" in code:
                issues.append("CRITICAL: eval() is extremely dangerous.")
                suggestions.append("Remove eval() and use safer alternatives.")

        # Python-specific checks
        if language == "python":
            if "except:" in code and "except Exception" not in code:
                issues.append("Bare except clause catches all exceptions including KeyboardInterrupt.")
                suggestions.append("Use 'except Exception as e:' for better error handling.")
            
            if "os.system" in code:
                issues.append("os.system() is insecure. Use subprocess module instead.")
                suggestions.append("Replace with subprocess.run() for safer execution.")

        # General checks
        if len(code) > 1000 and "function " not in code and "def " not in code and "class " not in code:
            suggestions.append("Consider breaking code into functions for better maintainability.")

        return {
            "issues_found": len(issues),
            "issues": issues,
            "suggestions": suggestions,
            "severity": "high" if any("CRITICAL" in i for i in issues) else "medium" if issues else "low",
            "fixed_code": self._suggest_fixes(code, issues) if issues else code,
        }

    def _suggest_fixes(self, code: str, issues: List[str]) -> str:
        """Suggest code fixes based on issues."""
        fixed = code
        
        for issue in issues:
            if "XSS" in issue:
                fixed = fixed.replace("$_GET[", "htmlspecialchars($_GET[")
                fixed = fixed.replace("$_POST[", "htmlspecialchars($_POST[")
            elif "eval()" in issue:
                fixed = fixed.replace("eval(", "# REMOVED eval( # SECURITY RISK")
            elif "os.system" in issue:
                fixed = fixed.replace("os.system", "subprocess.run")
        
        return fixed

    async def _scaffold_project(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Scaffold new project."""
        project_type = payload.get("project_type", "laravel")
        project_name = payload.get("project_name", "my-project")
        output_path = payload.get("output_path", "./")

        commands = []
        structure = []

        if project_type == "laravel":
            commands = [
                f"composer create-project laravel/laravel {project_name}",
                f"cd {project_name} && php artisan key:generate",
                f"cd {project_name} && php artisan migrate",
                f"cd {project_name} && php artisan serve",
            ]
            structure = [
                "app/Http/Controllers/",
                "app/Models/",
                "app/Services/",
                "database/migrations/",
                "resources/views/",
                "routes/",
                "tests/",
                "config/",
            ]
        elif project_type == "python":
            commands = [
                f"mkdir {project_name}",
                f"cd {project_name} && python3 -m venv venv",
                f"cd {project_name} && source venv/bin/activate && pip install -r requirements.txt",
            ]
            structure = [
                "src/",
                "tests/",
                "docs/",
                "scripts/",
                "requirements.txt",
                "setup.py",
                "README.md",
                ".env.example",
            ]
        elif project_type == "react":
            commands = [
                f"npx create-react-app {project_name}",
                f"cd {project_name} && npm start",
            ]
            structure = [
                "src/components/",
                "src/pages/",
                "src/hooks/",
                "src/services/",
                "src/utils/",
                "public/",
                "package.json",
            ]

        return {
            "project_type": project_type,
            "project_name": project_name,
            "setup_commands": commands,
            "structure": structure,
            "next_steps": [
                f"Run: {commands[0]}" if commands else "Setup project manually",
                "Configure .env file",
                "Set up database connections",
                "Run initial migrations",
                "Start development server",
            ],
        }

    async def _review_code(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Review code quality."""
        code = payload.get("code", "")
        language = payload.get("language", "")

        score = 100
        findings = []

        # Check code length
        lines = code.split("\n")
        if len(lines) > 500:
            findings.append("File is quite long. Consider splitting into modules.")
            score -= 10

        # Check comments
        comment_count = sum(1 for line in lines if line.strip().startswith(("#", "//", "*", "\"\"\"", "/*")))
        comment_ratio = comment_count / max(len(lines), 1)
        if comment_ratio < 0.1:
            findings.append("Low comment ratio. Add docstrings/comments for complex logic.")
            score -= 15

        # Check function length
        if language in ["python", "php", "javascript"]:
            in_function = False
            function_lines = 0
            for line in lines:
                if any(kw in line for kw in ["def ", "function ", "async def"]):
                    in_function = True
                    function_lines = 0
                elif in_function:
                    function_lines += 1
                    if function_lines > 50:
                        findings.append("Function exceeds 50 lines. Consider refactoring.")
                        score -= 10
                        in_function = False

        # Security checks
        if "password" in code.lower() and "hash" not in code.lower():
            findings.append("Potential plaintext password handling detected.")
            score -= 20

        return {
            "score": max(0, score),
            "grade": "A" if score >= 90 else "B" if score >= 80 else "C" if score >= 70 else "D" if score >= 60 else "F",
            "findings": findings,
            "metrics": {
                "total_lines": len(lines),
                "comment_ratio": round(comment_ratio * 100, 1),
                "estimated_complexity": "high" if len(lines) > 300 else "medium" if len(lines) > 100 else "low",
            },
        }

    async def _optimize_query(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize SQL query."""
        query = payload.get("query", "")
        
        optimizations = []
        optimized = query

        # Common optimizations
        if "SELECT *" in query.upper():
            optimizations.append("Replace SELECT * with specific columns for better performance.")
            optimized = re.sub(r"SELECT\s+\*", "SELECT col1, col2, col3", optimized, flags=re.IGNORECASE)

        if "WHERE" in query.upper() and "INDEX" not in query.upper():
            optimizations.append("Ensure WHERE clause columns are indexed.")

        if "JOIN" in query.upper():
            if "EXPLAIN" not in query.upper():
                optimizations.append("Use EXPLAIN to analyze query execution plan.")
            
            if "ON " in query.upper():
                optimizations.append("Ensure JOIN conditions use indexed columns.")

        if "ORDER BY" in query.upper() and "LIMIT" not in query.upper():
            optimizations.append("Consider adding LIMIT for large result sets.")

        if "N+1" in query or len(re.findall(r"SELECT.*FROM", query, re.IGNORECASE)) > 2:
            optimizations.append("Potential N+1 query. Consider eager loading or JOINs.")

        return {
            "original_query": query,
            "optimized_query": optimized,
            "optimizations": optimizations,
            "impact": "high" if len(optimizations) > 2 else "medium" if optimizations else "low",
        }

    async def _run_script(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Run a script and capture output."""
        script_path = payload.get("script_path", "")
        interpreter = payload.get("interpreter", "python3")
        args = payload.get("args", [])
        timeout = payload.get("timeout", 60)

        if not os.path.exists(script_path):
            return {"error": f"Script not found: {script_path}"}

        try:
            cmd = [interpreter, script_path] + args
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            return {
                "return_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "success": result.returncode == 0,
            }

        except subprocess.TimeoutExpired:
            return {"error": f"Script timed out after {timeout}s"}
        except Exception as e:
            return {"error": str(e)}

    async def _git_operation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Execute Git operations."""
        operation = payload.get("git_command", "status")
        repo_path = payload.get("repo_path", ".")
        message = payload.get("commit_message", "")
        branch = payload.get("branch", "main")

        git_commands = {
            "status": ["git", "-C", repo_path, "status"],
            "pull": ["git", "-C", repo_path, "pull", "origin", branch],
            "push": ["git", "-C", repo_path, "push", "origin", branch],
            "commit": ["git", "-C", repo_path, "commit", "-m", message],
            "add": ["git", "-C", repo_path, "add", "."],
            "log": ["git", "-C", repo_path, "log", "--oneline", "-10"],
            "branch": ["git", "-C", repo_path, "branch", "-a"],
            "checkout": ["git", "-C", repo_path, "checkout", branch],
        }

        cmd = git_commands.get(operation)
        if not cmd:
            return {"error": f"Unknown git operation: {operation}"}

        try:
            if operation == "commit":
                # Add first, then commit
                subprocess.run(["git", "-C", repo_path, "add", "."], capture_output=True)

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            return {
                "operation": operation,
                "success": result.returncode == 0,
                "output": result.stdout if result.returncode == 0 else result.stderr,
                "branch": branch,
            }

        except Exception as e:
            return {"error": str(e)}

    def _get_code_notes(self, language: str, component_type: str) -> List[str]:
        """Get implementation notes for generated code."""
        notes = {
            "php": [
                "Follow PSR-12 coding standards",
                "Use dependency injection for testability",
                "Implement form request validation for complex rules",
            ],
            "python": [
                "Use type hints for better code clarity",
                "Add unit tests with pytest",
                "Use virtual environment for dependencies",
            ],
            "javascript": [
                "Use ESLint for code quality",
                "Add JSDoc comments for documentation",
                "Consider TypeScript for type safety",
            ],
        }
        return notes.get(language, ["Review generated code before deployment"])


import datetime  # For template generation
