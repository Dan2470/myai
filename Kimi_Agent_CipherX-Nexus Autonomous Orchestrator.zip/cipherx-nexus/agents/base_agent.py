"""
CIPHERX-NEXUS BASE AGENT MODULE
Abstract base class for all autonomous sub-agents.
Provides task management, status tracking, and lifecycle hooks.
"""

import asyncio
import json
import logging
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class AgentStatus(Enum):
    """Agent execution status states."""
    IDLE = "idle"
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYING = "retrying"
    TERMINATED = "terminated"


class TaskPriority(Enum):
    """Task priority levels."""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


@dataclass
class TaskResult:
    """Result of a task execution."""
    task_id: str
    agent_name: str
    status: str
    data: Any = None
    error: Optional[str] = None
    execution_time: float = 0.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @property
    def is_success(self) -> bool:
        """Check if task succeeded."""
        return self.status == "success" and self.error is None


@dataclass
class Task:
    """Represents a task for an agent to execute."""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = "unnamed"
    description: str = ""
    priority: TaskPriority = TaskPriority.NORMAL
    payload: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    max_retries: int = 3
    timeout_seconds: int = 300
    dependencies: List[str] = field(default_factory=list)
    callback: Optional[Callable] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (excluding callback)."""
        data = asdict(self)
        data.pop("callback", None)
        return data


class BaseAgent(ABC):
    """
    Abstract base class for all CipherX-Nexus sub-agents.
    
    Provides:
    - Async task execution with priority queue
    - Status lifecycle management
    - Error handling and retry logic
    - Event emission for orchestrator communication
    - Resource cleanup
    """

    def __init__(
        self,
        name: str,
        config: Dict[str, Any],
        orchestrator: Optional[Any] = None,
    ):
        """
        Initialize base agent.
        
        Args:
            name: Agent identifier
            config: Agent configuration
            orchestrator: Reference to parent orchestrator
        """
        self.name = name
        self.config = config
        self.orchestrator = orchestrator
        
        # Status and state
        self.status = AgentStatus.IDLE
        self.current_task: Optional[Task] = None
        self.task_history: List[TaskResult] = []
        
        # Task queue
        self._task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._running_tasks: Set[asyncio.Task] = set()
        self._shutdown_event = asyncio.Event()
        
        # Metrics
        self._tasks_completed = 0
        self._tasks_failed = 0
        self._total_execution_time = 0.0
        self._start_time: Optional[float] = None
        
        # Event callbacks
        self._event_handlers: Dict[str, List[Callable]] = {}
        
        logger.info("[AGENT:%s] Initialized", self.name)

    @property
    def is_running(self) -> bool:
        """Check if agent is currently running."""
        return self.status in (AgentStatus.RUNNING, AgentStatus.RETRYING)

    @property
    def is_available(self) -> bool:
        """Check if agent is available for new tasks."""
        return self.status in (AgentStatus.IDLE, AgentStatus.RUNNING)

    @property
    def metrics(self) -> Dict[str, Any]:
        """Get agent performance metrics."""
        return {
            "agent_name": self.name,
            "status": self.status.value,
            "tasks_completed": self._tasks_completed,
            "tasks_failed": self._tasks_failed,
            "total_execution_time": round(self._total_execution_time, 2),
            "avg_execution_time": round(
                self._total_execution_time / max(self._tasks_completed, 1), 2
            ),
            "uptime": round(time.time() - (self._start_time or time.time()), 2),
            "queue_size": self._task_queue.qsize(),
            "current_task": self.current_task.name if self.current_task else None,
        }

    async def start(self) -> None:
        """Start the agent's main processing loop."""
        self.status = AgentStatus.RUNNING
        self._start_time = time.time()
        self._shutdown_event.clear()
        
        logger.info("[AGENT:%s] Started", self.name)
        self.emit_event("agent_started", {"agent": self.name})

        # Start task processor
        processor = asyncio.create_task(self._process_tasks())
        self._running_tasks.add(processor)
        
        try:
            await processor
        except asyncio.CancelledError:
            logger.info("[AGENT:%s] Task processor cancelled", self.name)
        except Exception as e:
            logger.error("[AGENT:%s] Task processor error: %s", self.name, e)
            self.status = AgentStatus.FAILED

    async def stop(self) -> None:
        """Gracefully stop the agent."""
        logger.info("[AGENT:%s] Stopping...", self.name)
        self.status = AgentStatus.TERMINATED
        self._shutdown_event.set()

        # Cancel running tasks
        for task in self._running_tasks:
            if not task.done():
                task.cancel()
        
        if self._running_tasks:
            await asyncio.gather(*self._running_tasks, return_exceptions=True)
        
        self._running_tasks.clear()
        await self.cleanup()
        
        self.emit_event("agent_stopped", {"agent": self.name})
        logger.info("[AGENT:%s] Stopped", self.name)

    async def submit_task(self, task: Task) -> str:
        """
        Submit a task to the agent's queue.
        
        Args:
            task: Task to execute
            
        Returns:
            Task ID
        """
        priority_value = task.priority.value
        await self._task_queue.put((priority_value, time.time(), task))
        
        logger.info("[AGENT:%s] Task submitted: %s (priority: %s)",
                    self.name, task.name, task.priority.name)
        self.emit_event("task_submitted", task.to_dict())
        
        return task.task_id

    async def submit_task_dict(self, task_dict: Dict[str, Any]) -> str:
        """
        Submit a task from dictionary.
        
        Args:
            task_dict: Task parameters
            
        Returns:
            Task ID
        """
        priority = TaskPriority(task_dict.get("priority", 2))
        task = Task(
            name=task_dict.get("name", "unnamed"),
            description=task_dict.get("description", ""),
            priority=priority,
            payload=task_dict.get("payload", {}),
            max_retries=task_dict.get("max_retries", 3),
            timeout_seconds=task_dict.get("timeout_seconds", 300),
        )
        return await self.submit_task(task)

    async def _process_tasks(self) -> None:
        """Main task processing loop."""
        while not self._shutdown_event.is_set():
            try:
                # Wait for tasks with timeout
                try:
                    _, _, task = await asyncio.wait_for(
                        self._task_queue.get(), timeout=1.0
                    )
                except asyncio.TimeoutError:
                    continue

                await self._execute_task(task)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("[AGENT:%s] Task processor error: %s", self.name, e)
                await asyncio.sleep(1)

    async def _execute_task(self, task: Task) -> TaskResult:
        """
        Execute a single task with error handling and retries.
        
        Args:
            task: Task to execute
            
        Returns:
            TaskResult with execution details
        """
        self.current_task = task
        start_time = time.time()
        last_error = None

        for attempt in range(task.max_retries + 1):
            if self._shutdown_event.is_set():
                break

            try:
                self.status = AgentStatus.RUNNING
                
                # Execute with timeout
                result_data = await asyncio.wait_for(
                    self.execute(task.payload),
                    timeout=task.timeout_seconds,
                )

                execution_time = time.time() - start_time
                self._total_execution_time += execution_time
                self._tasks_completed += 1

                result = TaskResult(
                    task_id=task.task_id,
                    agent_name=self.name,
                    status="success",
                    data=result_data,
                    execution_time=round(execution_time, 2),
                )

                self.task_history.append(result)
                self.current_task = None
                
                # Call callback if provided
                if task.callback:
                    try:
                        if asyncio.iscoroutinefunction(task.callback):
                            await task.callback(result)
                        else:
                            task.callback(result)
                    except Exception as e:
                        logger.error("[AGENT:%s] Callback error: %s", self.name, e)

                self.emit_event("task_completed", result.to_dict())
                logger.info("[AGENT:%s] Task %s completed in %.2fs",
                            self.name, task.name, execution_time)
                
                self.status = AgentStatus.IDLE
                return result

            except asyncio.TimeoutError:
                last_error = f"Task timeout after {task.timeout_seconds}s"
                self.status = AgentStatus.RETRYING
                logger.warning("[AGENT:%s] Task %s timeout (attempt %d/%d)",
                               self.name, task.name, attempt + 1, task.max_retries + 1)

            except Exception as e:
                last_error = str(e)
                self.status = AgentStatus.RETRYING
                logger.error("[AGENT:%s] Task %s error (attempt %d/%d): %s",
                             self.name, task.name, attempt + 1, task.max_retries + 1, e)

            # Retry delay with exponential backoff
            if attempt < task.max_retries:
                delay = min(2 ** attempt, 30)
                await asyncio.sleep(delay)

        # All retries exhausted
        execution_time = time.time() - start_time
        self._tasks_failed += 1

        result = TaskResult(
            task_id=task.task_id,
            agent_name=self.name,
            status="failed",
            error=last_error,
            execution_time=round(execution_time, 2),
        )

        self.task_history.append(result)
        self.current_task = None
        self.status = AgentStatus.FAILED

        self.emit_event("task_failed", result.to_dict())
        logger.error("[AGENT:%s] Task %s failed after %d attempts",
                     self.name, task.name, task.max_retries + 1)

        return result

    @abstractmethod
    async def execute(self, payload: Dict[str, Any]) -> Any:
        """
        Execute the agent's primary logic.
        Must be implemented by subclasses.
        
        Args:
            payload: Task payload with parameters
            
        Returns:
            Task execution result
        """
        pass

    async def cleanup(self) -> None:
        """
        Cleanup resources. Override in subclasses for custom cleanup.
        """
        logger.info("[AGENT:%s] Cleanup completed", self.name)

    def emit_event(self, event_type: str, data: Dict[str, Any]) -> None:
        """
        Emit event to registered handlers and orchestrator.
        
        Args:
            event_type: Type of event
            data: Event data
        """
        event = {
            "type": event_type,
            "agent": self.name,
            "timestamp": datetime.utcnow().isoformat(),
            "data": data,
        }

        # Call registered handlers
        handlers = self._event_handlers.get(event_type, [])
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    asyncio.create_task(handler(event))
                else:
                    handler(event)
            except Exception as e:
                logger.error("[AGENT:%s] Event handler error: %s", self.name, e)

        # Notify orchestrator
        if self.orchestrator:
            try:
                asyncio.create_task(
                    self.orchestrator.handle_agent_event(self.name, event)
                )
            except Exception as e:
                logger.debug("[AGENT:%s] Orchestrator notification failed: %s", self.name, e)

    def on_event(self, event_type: str, handler: Callable) -> None:
        """
        Register event handler.
        
        Args:
            event_type: Event type to listen for
            handler: Callback function
        """
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)

    def get_task_history(
        self,
        limit: int = 50,
        status_filter: Optional[str] = None,
    ) -> List[TaskResult]:
        """
        Get task execution history.
        
        Args:
            limit: Maximum number of results
            status_filter: Filter by status
            
        Returns:
            List of task results
        """
        history = self.task_history
        if status_filter:
            history = [r for r in history if r.status == status_filter]
        return history[-limit:]

    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check.
        
        Returns:
            Health status dictionary
        """
        return {
            "agent": self.name,
            "status": self.status.value,
            "healthy": self.status not in (AgentStatus.FAILED, AgentStatus.TERMINATED),
            "metrics": self.metrics,
            "timestamp": datetime.utcnow().isoformat(),
        }

    def __repr__(self) -> str:
        return f"BaseAgent(name={self.name}, status={self.status.value})"
