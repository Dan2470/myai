#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# CIPHERX-NEXUS ONE-CLICK INSTALLER
# For Ubuntu 20.04/22.04/24.04 LTS
# 
# Usage:
#   chmod +x setup.sh
#   sudo ./setup.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ─── Colors ───
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ─── Configuration ───
PYTHON_VERSION="3.11"
PROJECT_DIR="/opt/cipherx-nexus"
SERVICE_NAME="cipherx-nexus"
USER_NAME="nexus"
REPO_URL=""  # Set if cloning from git

# ─── Helper Functions ───
print_banner() {
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════════════════════╗"
    echo "║                     CIPHERX-NEXUS INSTALLER v1.0.0                           ║"
    echo "║                  Production-Ready Multi-Agent System                         ║"
    echo "╚══════════════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[OK]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "\n${BOLD}${CYAN}► $1${NC}"
}

# ─── Check Root ───
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This installer must be run as root (use sudo)"
        exit 1
    fi
}

# ─── Check Ubuntu ───
check_os() {
    if ! grep -q "Ubuntu" /etc/os-release 2>/dev/null; then
        log_warning "This script is designed for Ubuntu. Continuing anyway..."
    fi
    
    UBUNTU_VERSION=$(grep VERSION_ID /etc/os-release | cut -d'"' -f2)
    log_info "Detected Ubuntu version: $UBUNTU_VERSION"
}

# ─── System Update ───
system_update() {
    log_step "Updating system packages..."
    apt-get update -qq
    apt-get upgrade -y -qq
    log_success "System updated"
}

# ─── Install System Dependencies ───
install_system_deps() {
    log_step "Installing system dependencies..."
    
    apt-get install -y -qq \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        curl \
        wget \
        git \
        build-essential \
        libssl-dev \
        zlib1g-dev \
        libbz2-dev \
        libreadline-dev \
        libsqlite3-dev \
        llvm \
        libncurses5-dev \
        libncursesw5-dev \
        xz-utils \
        tk-dev \
        libffi-dev \
        liblzma-dev \
        python3-openssl \
        fonts-liberation \
        libappindicator3-1 \
        libasound2 \
        libatk-bridge2.0-0 \
        libatk1.0-0 \
        libatspi2.0-0 \
        libcups2 \
        libdbus-1-3 \
        libdrm2 \
        libgbm1 \
        libgtk-3-0 \
        libnspr4 \
        libnss3 \
        libxcomposite1 \
        libxdamage1 \
        libxfixes3 \
        libxkbcommon0 \
        libxrandr2 \
        xdg-utils \
        libu2f-udev \
        libvulkan1 \
        unzip \
        p7zip-full \
        jq \
        htop \
        tree \
        vim \
        nano \
        logrotate \
        ufw \
        fail2ban \
        ntp \
        2>&1 | grep -v "^Selecting\|^Preparing\|^Unpacking\|^Setting up\|^Processing\|^Need to get\|^Get:" || true
    
    log_success "System dependencies installed"
}

# ─── Install Python 3.10+ ───
install_python() {
    log_step "Installing Python ${PYTHON_VERSION}..."
    
    # Add deadsnakes PPA for newer Python versions
    add-apt-repository -y ppa:deadsnakes/ppa 2>/dev/null || true
    apt-get update -qq
    
    apt-get install -y -qq \
        python${PYTHON_VERSION} \
        python${PYTHON_VERSION}-venv \
        python${PYTHON_VERSION}-dev \
        python${PYTHON_VERSION}-distutils \
        python3-pip \
        2>&1 | grep -v "^Selecting\|^Preparing\|^Unpacking\|^Setting up" || true
    
    # Set python3.11 as default python3
    update-alternatives --install /usr/bin/python3 python3 /usr/bin/python${PYTHON_VERSION} 1 || true
    update-alternatives --install /usr/bin/python python /usr/bin/python${PYTHON_VERSION} 1 || true
    
    # Upgrade pip
    python3 -m pip install --upgrade pip setuptools wheel -q
    
    PYTHON_INSTALLED=$(python3 --version 2>&1)
    log_success "Python installed: $PYTHON_INSTALLED"
}

# ─── Install Node.js (for Playwright + web tools) ───
install_nodejs() {
    log_step "Installing Node.js 20.x..."
    
    # Remove old Node.js if exists
    apt-get remove -y nodejs npm 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/nodesource*
    
    # Install NodeSource repository
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
    apt-get install -y -qq nodejs 2>&1 | grep -v "^Selecting\|^Preparing" || true
    
    NODE_VERSION=$(node --version)
    NPM_VERSION=$(npm --version)
    log_success "Node.js installed: $NODE_VERSION (npm $NPM_VERSION)"
}

# ─── Install Playwright & Chromium ───
install_playwright() {
    log_step "Installing Playwright and Chromium..."
    
    # Install Playwright browsers
    python3 -m playwright install chromium 2>&1 | while read line; do
        if [[ "$line" == *"Downloading"* ]] || [[ "$line" == *"chromium"* ]]; then
            echo -ne "\r${BLUE}[INFO]${NC} $line"
        fi
    done
    echo ""
    
    # Install browser dependencies
    python3 -m playwright install-deps chromium 2>&1 | tail -5
    
    log_success "Playwright + Chromium ready"
}

# ─── Setup Project ───
setup_project() {
    log_step "Setting up CipherX-Nexus project..."
    
    # Create project directory
    mkdir -p ${PROJECT_DIR}
    
    # Create user
    if ! id "${USER_NAME}" &>/dev/null; then
        useradd -r -s /bin/bash -d ${PROJECT_DIR} -M ${USER_NAME} 2>/dev/null || true
        log_info "Created user: ${USER_NAME}"
    fi
    
    # If current directory has the project files, copy them
    if [[ -f "nexus_core.py" ]] && [[ -f "config.json" ]]; then
        log_info "Copying project files from current directory..."
        cp -r . ${PROJECT_DIR}/
    elif [[ -n "$REPO_URL" ]]; then
        log_info "Cloning from repository..."
        git clone ${REPO_URL} ${PROJECT_DIR} 2>/dev/null || true
    else
        log_warning "Project files not found in current directory."
        log_info "Please manually copy project files to ${PROJECT_DIR}/"
    fi
    
    # Create virtual environment
    cd ${PROJECT_DIR}
    python3 -m venv venv
    source venv/bin/activate
    
    # Install Python dependencies
    log_info "Installing Python dependencies..."
    pip install -r requirements.txt -q 2>&1 | tail -3
    
    # Create necessary directories
    mkdir -p logs sessions output/security_reports
    
    # Set permissions
    chown -R ${USER_NAME}:${USER_NAME} ${PROJECT_DIR}
    chmod +x nexus_core.py 2>/dev/null || true
    
    log_success "Project setup complete at ${PROJECT_DIR}"
}

# ─── Create Systemd Service ───
create_service() {
    log_step "Creating systemd service..."
    
    cat > /etc/systemd/system/${SERVICE_NAME}.service << 'EOF'
[Unit]
Description=CipherX-Nexus Autonomous Multi-Agent System
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=nexus
Group=nexus
WorkingDirectory=/opt/cipherx-nexus
Environment="PATH=/opt/cipherx-nexus/venv/bin:/usr/local/bin:/usr/bin:/bin"
Environment="PYTHONPATH=/opt/cipherx-nexus"
Environment="NEXUS_MASTER_PASSWORD="
Environment="NEXUS_BOT_TOKEN="
Environment="NEXUS_AI_KEY="
ExecStart=/opt/cipherx-nexus/venv/bin/python /opt/cipherx-nexus/nexus_core.py
ExecStop=/bin/kill -SIGTERM $MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=cipherx-nexus

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/cipherx-nexus/logs /opt/cipherx-nexus/sessions /opt/cipherx-nexus/output
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable ${SERVICE_NAME}.service
    
    log_success "Systemd service created: ${SERVICE_NAME}"
}

# ─── Configure Firewall ───
setup_firewall() {
    log_step "Configuring firewall..."
    
    ufw default deny incoming 2>/dev/null || true
    ufw default allow outgoing 2>/dev/null || true
    ufw allow ssh 2>/dev/null || true
    ufw allow 80/tcp 2>/dev/null || true
    ufw allow 443/tcp 2>/dev/null || true
    
    # Enable UFW if not already enabled
    if ! ufw status | grep -q "Status: active"; then
        echo "y" | ufw enable 2>/dev/null || true
    fi
    
    log_success "Firewall configured"
}

# ─── Configure Fail2Ban ───
setup_fail2ban() {
    log_step "Configuring fail2ban..."
    
    cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5
backend = systemd

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3
EOF

    systemctl restart fail2ban 2>/dev/null || true
    systemctl enable fail2ban 2>/dev/null || true
    
    log_success "Fail2Ban configured"
}

# ─── Install Security Tools (Optional) ───
install_security_tools() {
    log_step "Installing security tools (optional)..."
    
    # Nmap
    if ! command -v nmap &> /dev/null; then
        apt-get install -y -qq nmap 2>&1 | tail -1 || true
        log_info "nmap installed"
    fi
    
    # Additional tools (don't fail if unavailable)
    OPTIONAL_TOOLS="dirsearch gobuster sqlmap nikto whois dnsutils"
    for tool in $OPTIONAL_TOOLS; do
        apt-get install -y -qq $tool 2>/dev/null && log_info "$tool installed" || log_warning "$tool not available in repos"
    done
    
    log_success "Security tools installed"
}

# ─── Create Config Template ───
create_config_template() {
    if [[ ! -f "${PROJECT_DIR}/config.json" ]]; then
        log_info "Creating config.json from template..."
        cp config.json ${PROJECT_DIR}/config.json 2>/dev/null || true
    fi
}

# ─── Print Final Instructions ───
print_final_instructions() {
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                  INSTALLATION COMPLETE!                                      ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BOLD}Next Steps:${NC}"
    echo ""
    echo -e "  1. ${CYAN}Configure${NC} your API keys in ${YELLOW}${PROJECT_DIR}/config.json${NC}:"
    echo -e "     • Telegram Bot Token"
    echo -e "     • Kimi AI API Key"
    echo -e "     • Master Password"
    echo -e "     • Social media credentials (optional)"
    echo -e "     • Email credentials (optional)"
    echo ""
    echo -e "  2. ${CYAN}Set environment variables${NC} (optional, overrides config):"
    echo -e "     ${YELLOW}export NEXUS_BOT_TOKEN='your_token'${NC}"
    echo -e "     ${YELLOW}export NEXUS_AI_KEY='your_key'${NC}"
    echo -e "     ${YELLOW}export NEXUS_MASTER_PASSWORD='strong_password'${NC}"
    echo ""
    echo -e "  3. ${CYAN}Start the service:${NC}"
    echo -e "     ${YELLOW}sudo systemctl start ${SERVICE_NAME}${NC}"
    echo ""
    echo -e "  4. ${CYAN}Check status:${NC}"
    echo -e "     ${YELLOW}sudo systemctl status ${SERVICE_NAME}${NC}"
    echo -e "     ${YELLOW}sudo journalctl -u ${SERVICE_NAME} -f${NC}"
    echo ""
    echo -e "  5. ${CYAN}Manage:${NC}"
    echo -e "     ${YELLOW}sudo systemctl stop ${SERVICE_NAME}${NC}"
    echo -e "     ${YELLOW}sudo systemctl restart ${SERVICE_NAME}${NC}"
    echo ""
    echo -e "  6. ${CYAN}Interact via Telegram:${NC}"
    echo -e "     Send /start to your bot"
    echo ""
    echo -e "${BOLD}Project Location:${NC} ${YELLOW}${PROJECT_DIR}${NC}"
    echo -e "${BOLD}Logs:${NC} ${YELLOW}${PROJECT_DIR}/logs/nexus.log${NC}"
    echo -e "${BOLD}Config:${NC} ${YELLOW}${PROJECT_DIR}/config.json${NC}"
    echo ""
    echo -e "${GREEN}══════════════════════════════════════════════════════════════════════════════${NC}"
}

# ─── Main Installation Flow ───
main() {
    print_banner
    
    log_info "Starting CipherX-Nexus installation..."
    log_info "Target directory: ${PROJECT_DIR}"
    
    # Pre-flight checks
    check_root
    check_os
    
    # Installation steps
    system_update
    install_system_deps
    install_python
    install_nodejs
    setup_project
    install_playwright
    create_service
    setup_firewall
    setup_fail2ban
    install_security_tools
    create_config_template
    
    # Done
    print_final_instructions
}

# ─── Run ───
main "$@"
