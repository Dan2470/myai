# Telegram Interface Reference

Telegram Bot API integration, command parsing, session management, inline keyboards, file transfers, and conversation flow patterns for Nova-OS.

## Table of Contents

1. [Bot API Client Setup](#bot-api-client-setup)
2. [Message Handling](#message-handling)
3. [Command Parsing](#command-parsing)
4. [Session Management](#session-management)
5. [Inline Keyboards](#inline-keyboards)
6. [File Transfers](#file-transfers)
7. [Long-Running Operations](#long-running-operations)
8. [Message Formatting](#message-formatting)
9. [Error Handling & Retries](#error-handling--retries)
10. [Webhook vs Polling](#webhook-vs-polling)

## Bot API Client Setup

### Client Initialization

```python
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command, CommandObject
from aiogram.enums import ParseMode

bot = Bot(token=os.environ["NOVA_OS_BOT_TOKEN"])
dp = Dispatcher()
router = Router()
dp.include_router(router)

# Owner verification middleware
OWNER_ID = int(os.environ.get("NOVA_OS_OWNER_ID", 0))
AUTHORIZED_USERS = set()  # Loaded from state DB on startup

def is_authorized(user_id: int) -> bool:
    return user_id == OWNER_ID or user_id in AUTHORIZED_USERS
```

### Environment Variables

| Variable | Required | Description |
|---|---|---|
| `NOVA_OS_BOT_TOKEN` | Yes | Telegram Bot API token from @BotFather |
| `NOVA_OS_OWNER_ID` | Yes | Telegram user ID of the Owner (integer) |
| `NOVA_OS_WEBHOOK_URL` | No* | HTTPS URL for webhook mode |
| `NOVA_OS_WEBHOOK_SECRET` | No* | Secret token for webhook validation |

*Required only for webhook mode. Polling used if webhook URL not set.

## Message Handling

### Command Handlers

```python
@router.message(Command("status"))
async def cmd_status(message: Message):
    if not is_authorized(message.from_user.id):
        await message.answer("Access denied. Your Telegram ID is not authorized for /status.")
        return
    
    # Gather system status
    status = await gather_system_status()
    await message.answer(format_status(status), parse_mode=ParseMode.MARKDOWN)

@router.message(Command("exec"))
async def cmd_exec(message: Message, command: CommandObject):
    if not is_authorized(message.from_user.id):
        await message.answer("Access denied.")
        return
    
    if not command.args:
        await message.answer("Usage: `/exec <command>`")
        return
    
    # Validate command safety
    cmd = command.args
    if not is_safe_command(cmd):
        await message.answer("Command contains potentially unsafe operations. Cancelled.")
        return
    
    # Execute and report
    result = await shell(cmd)
    await message.answer(format_shell_result(result), parse_mode=ParseMode.MARKDOWN)
```

### Natural Language Processing

For non-command messages, use pattern matching to infer intent:

```python
@router.message(F.text)
async def handle_text(message: Message):
    if not is_authorized(message.from_user.id):
        return
    
    text = message.text.lower().strip()
    
    # Intent classification patterns
    if any(w in text for w in ["cpu", "load", "processor"]):
        await cmd_status(message)
    elif any(w in text for w in ["disk", "space", "storage", "full"]):
        await message.answer(await disk_status())
    elif any(w in text for w in ["memory", "ram", "swap"]):
        await message.answer(await memory_status())
    elif any(w in text for w in ["restart", "reboot", "service"]):
        # Extract service name if present
        await handle_service_intent(message, text)
    else:
        await message.answer(
            "I didn't understand that. Available commands: /help\n"
            "Or try: 'show cpu', 'disk space', 'restart nginx'"
        )
```

## Command Parsing

### Safe Command Validation

```python
import re

# Dangerous patterns that require explicit confirmation
DESTRUCTIVE_PATTERNS = [
    r"rm\s+-rf\s+/[^\s]*\b",      # rm -rf /
    r"dd\s+if=.*of=/dev/[sh]d",    # dd to disk
    r">\s*/etc/\w+",               # redirect to /etc files
    r"mkfs\.\w+\s+/dev/",          # format device
    r"shutdown\b", r"reboot\b", r"halt\b",
    r":\(\)\{\s*:\|\:&\};\b",      # fork bomb
    r"curl\s+.*\s*\|\s*sh",        # curl | sh
    r"wget\s+.*\s*\|\s*sh",        # wget | sh
]

PROTECTED_PATHS = ["/etc/passwd", "/etc/shadow", "/etc/sudoers", "/boot"]

def is_safe_command(cmd: str) -> bool:
    """Check if command requires confirmation before execution."""
    for pattern in DESTRUCTIVE_PATTERNS:
        if re.search(pattern, cmd, re.IGNORECASE):
            return False
    return True

def requires_confirmation(cmd: str) -> bool:
    """Check if command requires explicit user confirmation."""
    if not is_safe_command(cmd):
        return True
    # Any write operation to protected paths
    for path in PROTECTED_PATHS:
        if path in cmd:
            return True
    return False
```

### Confirmation Flow

```python
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

pending_confirmations = {}  # user_id -> command_context

async def request_confirmation(message: Message, cmd: str, reason: str):
    confirmation_id = f"{message.from_user.id}_{int(time.time())}"
    pending_confirmations[confirmation_id] = {
        "command": cmd,
        "user_id": message.from_user.id,
        "timestamp": time.time()
    }
    
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Confirm", callback_data=f"confirm:{confirmation_id}"),
            InlineKeyboardButton(text="Cancel", callback_data=f"cancel:{confirmation_id}")
        ]
    ])
    
    await message.answer(
        f"This command requires confirmation:\n"
        f"```\n{cmd}\n```\n"
        f"Reason: {reason}\n"
        f"Expires in 60 seconds.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=keyboard
    )

@router.callback_query(F.data.startswith("confirm:"))
async def handle_confirm(callback: CallbackQuery):
    confirmation_id = callback.data.split(":", 1)[1]
    ctx = pending_confirmations.pop(confirmation_id, None)
    
    if not ctx or ctx["user_id"] != callback.from_user.id:
        await callback.answer("Confirmation expired or invalid.", show_alert=True)
        return
    
    await callback.answer("Executing...")
    result = await shell(ctx["command"])
    await callback.message.answer(format_shell_result(result))
```

## Session Management

### Conversation Context

```python
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime, timedelta

@dataclass
class UserSession:
    user_id: int
    role: str  # "owner", "operator", "viewer"
    started_at: datetime
    last_activity: datetime
    conversation_context: list = field(default_factory=list)
    pending_command: Optional[str] = None
    mode: str = "normal"  # normal, maintenance, diagnostic

# Session store (backed by SQLite)
active_sessions: dict[int, UserSession] = {}

async def get_or_create_session(user_id: int) -> UserSession:
    if user_id not in active_sessions:
        role = await get_user_role_from_db(user_id)
        active_sessions[user_id] = UserSession(
            user_id=user_id,
            role=role,
            started_at=datetime.utcnow(),
            last_activity=datetime.utcnow()
        )
    else:
        active_sessions[user_id].last_activity = datetime.utcnow()
    return active_sessions[user_id]

async def cleanup_expired_sessions(timeout_minutes: int = 30):
    now = datetime.utcnow()
    expired = [
        uid for uid, s in active_sessions.items()
        if now - s.last_activity > timedelta(minutes=timeout_minutes)
    ]
    for uid in expired:
        del active_sessions[uid]
```

### Context Preservation

For multi-step conversations, maintain context across messages:

```python
@router.message(Command("deploy"))
async def cmd_deploy(message: Message, command: CommandObject):
    session = await get_or_create_session(message.from_user.id)
    
    if not command.args:
        await message.answer("Available targets:\n" + list_deploy_targets())
        session.pending_command = "deploy:awaiting_target"
        return
    
    target = command.args.strip()
    if session.pending_command == "deploy:awaiting_target":
        # User responded with target
        session.conversation_context.append({"target": target})
        await execute_deploy(message, target)
        session.pending_command = None
```

## Inline Keyboards

### Standard Keyboards

```python
def confirm_keyboard(confirmation_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Confirm", callback_data=f"confirm:{confirmation_id}"),
            InlineKeyboardButton(text="Cancel", callback_data=f"cancel:{confirmation_id}")
        ]
    ])

def service_control_keyboard(service: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Start", callback_data=f"svc:start:{service}"),
            InlineKeyboardButton(text="Stop", callback_data=f"svc:stop:{service}"),
            InlineKeyboardButton(text="Restart", callback_data=f"svc:restart:{service}"),
        ],
        [
            InlineKeyboardButton(text="Logs", callback_data=f"svc:logs:{service}"),
            InlineKeyboardButton(text="Status", callback_data=f"svc:status:{service}"),
        ]
    ])

def paginated_keyboard(items: list, page: int, per_page: int = 5, callback_prefix: str = "page") -> InlineKeyboardMarkup:
    total_pages = (len(items) + per_page - 1) // per_page
    start = page * per_page
    page_items = items[start:start + per_page]
    
    buttons = []
    for item in page_items:
        buttons.append([InlineKeyboardButton(text=item["label"], callback_data=item["callback"])])
    
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="Prev", callback_data=f"{callback_prefix}:{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page+1}/{total_pages}", callback_data="noop"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton(text="Next", callback_data=f"{callback_prefix}:{page+1}"))
    buttons.append(nav)
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)
```

## File Transfers

### Upload to User

```python
from aiogram.types import FSInputFile, BufferedInputFile

async def send_file(message: Message, file_path: str, caption: str = None):
    path = Path(file_path)
    if not path.exists():
        await message.answer(f"File not found: {file_path}")
        return
    
    if path.stat().st_size > 50 * 1024 * 1024:  # 50MB Telegram limit
        await message.answer("File too large for direct transfer. Use /download_link instead.")
        return
    
    file = FSInputFile(path)
    await message.answer_document(file, caption=caption or path.name)
```

### Receive from User

```python
@router.message(F.document)
async def handle_document(message: Message):
    if not is_authorized(message.from_user.id):
        return
    
    doc = message.document
    if doc.file_size > 20 * 1024 * 1024:
        await message.answer("File too large. Maximum 20MB.")
        return
    
    # Download to workspace
    workspace = Path("/tmp/nova-os/uploads") / str(message.from_user.id)
    workspace.mkdir(parents=True, exist_ok=True)
    
    file_path = workspace / doc.file_name
    await bot.download(doc, destination=file_path)
    
    await message.answer(f"File received: `{doc.file_name}` ({doc.file_size} bytes)\nSaved to: `{file_path}`")
```

### Log File Streaming

For large log files, stream in chunks:

```python
async def send_log_chunks(message: Message, log_path: str, lines: int = 100):
    path = Path(log_path)
    if not path.exists():
        await message.answer(f"Log file not found: {log_path}")
        return
    
    # Read last N lines
    result = await shell(f"tail -n {lines} {log_path}")
    
    # Split into Telegram-sized chunks (max 4096 chars)
    chunks = []
    current = "```\n"
    for line in result['stdout'].split('\n'):
        if len(current) + len(line) + 1 > 4000:
            chunks.append(current + "\n```")
            current = "```\n" + line + "\n"
        else:
            current += line + "\n"
    chunks.append(current + "```")
    
    for chunk in chunks:
        await message.answer(chunk, parse_mode=ParseMode.MARKDOWN)
```

## Long-Running Operations

### Progress Updates

For operations that take > 5 seconds, send periodic updates:

```python
async def long_operation_with_progress(message: Message, coro, description: str):
    status_msg = await message.answer(f"{description}...\nProgress: 0%")
    
    progress = {"percent": 0}
    
    async def update_progress(pct: int):
        if pct != progress["percent"]:
            progress["percent"] = pct
            try:
                await status_msg.edit_text(f"{description}...\nProgress: {pct}%")
            except Exception:
                pass  # Message not changed or other error
    
    try:
        result = await coro(progress_callback=update_progress)
        await status_msg.edit_text(f"{description}...\nComplete!")
        return result
    except Exception as e:
        await status_msg.edit_text(f"{description}...\nFailed: {e}")
        raise
```

### Background Task Notification

```python
async def run_background_task(task_id: str, coro, notify_user_id: int):
    """Run a task in background, notify user on completion."""
    try:
        result = await coro
        await bot.send_message(
            notify_user_id,
            f"Task `{task_id}` completed successfully.\nResult: {result}",
            parse_mode=ParseMode.MARKDOWN
        )
    except Exception as e:
        await bot.send_message(
            notify_user_id,
            f"Task `{task_id}` failed.\nError: {str(e)[:500]}",
            parse_mode=ParseMode.MARKDOWN
        )

# Usage
asyncio.create_task(run_background_task("backup_001", backup_database(), OWNER_ID))
```

## Message Formatting

### Status Formatting

```python
def format_status(status: dict) -> str:
    return (
        f"Server: `{status['hostname']}`\n"
        f"Uptime: {status['uptime']}\n"
        f"Load: {status['loadavg']}\n\n"
        f"CPU: {status['cpu_percent']}% | {status['cpu_cores']} cores\n"
        f"RAM: {status['ram_used']}/{status['ram_total']} ({status['ram_percent']}%)\n"
        f"Disk: {status['disk_used']}/{status['disk_total']} ({status['disk_percent']}%)\n\n"
        f"Net: In {status['net_in']}/s | Out {status['net_out']}/s"
    )

def format_shell_result(result: dict) -> str:
    output = result['stdout'][:3500] if result['stdout'] else "(no output)"
    if result['returncode'] != 0:
        output += f"\n\nSTDERR:\n{result['stderr'][:1000]}"
    
    return (
        f"```\n$ {result['command']}\n"
        f"{output}\n"
        f"```\n"
        f"Exit: {result['returncode']} | Duration: {result['duration_ms']}ms"
    )
```

### Parse Mode Rules

- Use `ParseMode.MARKDOWN` for most responses
- Escape backticks inside code blocks by using double backticks
- Keep messages under 4096 characters (Telegram limit)
- Use `

` for paragraph breaks

## Error Handling & Retries

### Telegram API Retries

```python
import random
from aiogram.exceptions import TelegramRetryAfter, TelegramNetworkError

async def send_with_retry(coro, max_retries: int = 3):
    for attempt in range(max_retries):
        try:
            return await coro
        except TelegramRetryAfter as e:
            wait = e.retry_after + random.uniform(0, 1)
            await asyncio.sleep(wait)
        except TelegramNetworkError:
            wait = 2 ** attempt + random.uniform(0, 1)
            await asyncio.sleep(wait)
        except Exception:
            if attempt == max_retries - 1:
                raise
            await asyncio.sleep(2 ** attempt)
```

## Webhook vs Polling

### Webhook Setup (Production)

```python
from aiohttp import web

async def webhook_handler(request: web.Request) -> web.Response:
    """Handle incoming Telegram updates via webhook."""
    secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token")
    if secret != os.environ.get("NOVA_OS_WEBHOOK_SECRET"):
        return web.Response(status=403)
    
    update = await request.json()
    await dp.feed_update(bot, update)
    return web.Response(status=200)

async def init_webhook():
    await bot.set_webhook(
        url=os.environ["NOVA_OS_WEBHOOK_URL"],
        secret_token=os.environ.get("NOVA_OS_WEBHOOK_SECRET"),
        allowed_updates=["message", "callback_query"]
    )
    
    app = web.Application()
    app.router.add_post("/webhook", webhook_handler)
    return app
```

### Polling Setup (Development / Fallback)

```python
async def init_polling():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)
```

### Selection Logic

```python
async def start():
    if os.environ.get("NOVA_OS_WEBHOOK_URL"):
        app = await init_webhook()
        runner = web.AppRunner(app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", int(os.environ.get("PORT", 8080)))
        await site.start()
        await notify_owner("Nova-OS online (webhook mode). Monitoring active.")
    else:
        await notify_owner("Nova-OS online (polling mode). Monitoring active.")
        await init_polling()
```
