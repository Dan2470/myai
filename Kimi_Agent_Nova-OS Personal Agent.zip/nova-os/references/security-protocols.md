# Security & Governance Reference

Role-based access control, secret management, command sandboxing, audit logging, and intrusion response for Nova-OS.

## Table of Contents

1. [Authorization Model](#authorization-model)
2. [Secret Management](#secret-management)
3. [Command Sandboxing](#command-sandboxing)
4. [Audit Logging](#audit-logging)
5. [Intrusion Detection & Response](#intrusion-detection--response)
6. [Secure Communication](#secure-communication)
7. [Credential Rotation](#credential-rotation)
8. [Backup Encryption](#backup-encryption)
9. [Incident Response Playbook](#incident-response-playbook)

## Authorization Model

### Role Definitions

| Role | Telegram ID Source | Capabilities |
|---|---|---|
| **Owner** | `NOVA_OS_OWNER_ID` env var | Full system control, user management, emergency operations, lockdown mode |
| **Operator** | state.db `authorized_users` table | Shell execution (non-destructive), service restart, log viewing, deployment trigger, monitoring config |
| **Viewer** | state.db `authorized_users` table | Read-only: status, logs, metrics, query commands. No execution. |

### Permission Matrix

| Operation | Owner | Operator | Viewer |
|---|---|---|---|
| `/exec <cmd>` | Any command | Non-destructive only | Denied |
| `/deploy <target>` | Any target | Whitelisted targets | Denied |
| `/systemctl *` | Any service | Whitelisted services | Denied |
| `/config set` | All settings | Read-only | Denied |
| `/user add/remove` | Yes | Denied | Denied |
| `/panic`, `/lockdown` | Yes | Denied | Denied |
| `/status`, `/logs` | Yes | Yes | Yes |
| `/monitor` | Configure | Configure | View only |

### User Management Commands

```python
@router.message(Command("user"))
async def cmd_user(message: Message):
    """Owner-only user management."""
    if message.from_user.id != OWNER_ID:
        await message.answer("Owner only.")
        return
    
    # /user add <telegram_id> <role>
    # /user remove <telegram_id>
    # /user list
    pass
```

## Secret Management

### Encryption Architecture

Secrets are encrypted at rest using **Age** (Filippo Valsorda) with a master key. The master key is provided via `NOVA_OS_MASTER_KEY` environment variable and never persisted.

```
Secret Value → Age Encrypt → Store in /opt/nova-os/secrets/
                                          ↓
                                    SQLite reference:
                                    secrets_ref (name, filepath, checksum, accessed_at)
```

### Secret Operations

```python
import age
import hashlib
from pathlib import Path

SECRETS_DIR = Path("/opt/nova-os/secrets")
MASTER_KEY = os.environ["NOVA_OS_MASTER_KEY"]  # age private key

async def store_secret(name: str, value: str) -> dict:
    """Encrypt and store a secret. Value never hits disk unencrypted."""
    recipient = age.x25519_recipient_from_private_key(MASTER_KEY)
    
    encrypted = age.encrypt(value.encode(), [recipient])
    
    secret_file = SECRETS_DIR / f"{name}.age"
    secret_file.write_bytes(encrypted)
    
    checksum = hashlib.sha256(value.encode()).hexdigest()[:16]
    
    # Store reference in DB (not the value)
    await db.execute(
        "INSERT OR REPLACE INTO secrets_ref (name, filepath, checksum, created_at) VALUES (?, ?, ?, ?)",
        (name, str(secret_file), checksum, datetime.utcnow())
    )
    
    return {"name": name, "checksum": checksum, "path": str(secret_file)}

async def resolve_secret(name: str) -> str:
    """Retrieve and decrypt a secret. Log access."""
    row = await db.fetchone(
        "SELECT filepath FROM secrets_ref WHERE name = ?", (name,)
    )
    if not row:
        raise KeyError(f"Secret not found: {name}")
    
    secret_file = Path(row["filepath"])
    if not secret_file.exists():
        raise FileNotFoundError(f"Secret file missing: {secret_file}")
    
    encrypted = secret_file.read_bytes()
    identity = age.x25519_identity_from_private_key(MASTER_KEY)
    decrypted = age.decrypt(identity, encrypted)
    
    # Audit log access
    await audit_log("SECRET_ACCESS", {"secret_name": name, "user": context.user_id})
    
    return decrypted.decode()

async def rotate_secret(name: str, new_value: str) -> dict:
    """Rotate a secret with zero-downtime update."""
    # Store new value alongside old
    old_file = SECRETS_DIR / f"{name}.age"
    new_file = SECRETS_DIR / f"{name}.age.new"
    
    recipient = age.x25519_recipient_from_private_key(MASTER_KEY)
    new_file.write_bytes(age.encrypt(new_value.encode(), [recipient]))
    
    # Atomic swap
    old_backup = old_file.with_suffix(".age.old")
    old_file.rename(old_backup)
    new_file.rename(old_file)
    old_backup.unlink()
    
    await audit_log("SECRET_ROTATE", {"secret_name": name})
    
    return {"name": name, "status": "rotated"}
```

### Secret Categories

| Category | Examples | Rotation Schedule |
|---|---|---|
| API Tokens | `github_api_token`, `cloudflare_api_token` | 90 days |
| Database Credentials | `postgres_password`, `mysql_password` | 180 days |
| Cloud Credentials | `aws_access_key`, `gcp_service_key` | 90 days |
| Certificates | `tls_private_key` | On expiry or 365 days |
| Telegram | `bot_token` | On compromise only |

## Command Sandboxing

### Firejail Profile

All shell commands from non-Owner users execute inside Firejail sandbox:

```bash
# Default Nova-OS sandbox profile
# /etc/firejail/nova-os.profile

include /etc/firejail/disable-common.inc
include /etc/firejail/disable-devel.inc
include /etc/firejail/disable-interpreters.inc
include /etc/firejail/disable-passwdmgr.inc
include /etc/firejail/disable-programs.inc
include /etc/firejail/disable-xdg.inc

whitelist /tmp/nova-os/
whitelist /var/log/nova-os/
read-only /var/log/
read-only /opt/nova-os/

caps.drop all
seccomp
nonewprivs
noroot
netfilter
private-tmp
```

### Sandbox Execution

```python
async def sandboxed_shell(cmd: str, user_id: int, timeout: int = 30) -> dict:
    """Execute command inside firejail sandbox for non-Owner users."""
    if user_id == OWNER_ID:
        return await shell(cmd, timeout=timeout)  # Owner: direct execution
    
    sandboxed_cmd = f"firejail --profile=/etc/firejail/nova-os.profile --quiet {cmd}"
    return await shell(sandboxed_cmd, timeout=timeout)
```

### Restricted Command Patterns

These patterns are blocked for Operators (allowed for Owner):

- `rm -rf /`, `rm -rf /*`, `rm -rf /etc`, `rm -rf /boot`
- `mkfs.*` on any device
- `dd if=... of=/dev/...`
- `shutdown`, `reboot`, `halt`, `init 0`
- Any write to `/etc/passwd`, `/etc/shadow`, `/etc/sudoers`
- Any modification of Nova-OS's own files in `/opt/nova-os/`
- `curl ... | sh` or `wget ... | sh` patterns
- Network configuration changes (`iptables`, `nftables`)

## Audit Logging

### Audit Events

All privileged operations are logged to SQLite and forwarded to `/var/log/nova-os/audit.log`:

```python
from datetime import datetime
import json

AUDIT_LOG = Path("/var/log/nova-os/audit.log")

async def audit_log(event_type: str, details: dict):
    """Write immutable audit log entry."""
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "event": event_type,
        "user_id": details.get("user_id"),
        "command": details.get("command"),
        "exit_code": details.get("exit_code"),
        "duration_ms": details.get("duration_ms"),
        "metadata": details
    }
    
    # SQLite persistent storage
    await db.execute(
        "INSERT INTO audit (timestamp, event_type, user_id, command, exit_code, details) VALUES (?, ?, ?, ?, ?, ?)",
        (entry["timestamp"], event_type, entry["user_id"], entry.get("command"), entry.get("exit_code"), json.dumps(details))
    )
    
    # Append-only file log
    with open(AUDIT_LOG, "a") as f:
        f.write(json.dumps(entry) + "\n")
```

### Audit Event Types

| Event | Trigger | Data Retention |
|---|---|---|
| `COMMAND_EXEC` | Any /exec command | 2 years |
| `SECRET_ACCESS` | Secret retrieval | 2 years |
| `SECRET_ROTATE` | Secret rotation | 2 years |
| `DEPLOY_TRIGGER` | Deployment initiated | 2 years |
| `USER_AUTH` | Login / auth check | 1 year |
| `USER_ADD` | User added | Indefinite |
| `USER_REMOVE` | User removed | Indefinite |
| `MODE_CHANGE` | Maintenance/lockdown/ diagnostic | 1 year |
| `FILE_ACCESS` | Sensitive file read | 1 year |
| `CONFIG_CHANGE` | System configuration modified | 2 years |
| `ALERT_ACK` | Alert acknowledged | 1 year |
| `PANIC_TRIGGER` | Emergency containment | Indefinite |

### Log Integrity

Audit logs are append-only. File permissions:

```bash
chown nova-os:nova-os /var/log/nova-os/audit.log
chmod 640 /var/log/nova-os/audit.log
chattr +a /var/log/nova-os/audit.log  # append-only attribute
```

## Intrusion Detection & Response

### Monitoring Triggers

| Condition | Check Interval | Threshold | Response |
|---|---|---|---|
| Failed SSH login | 60s | >5 attempts / 1 min | Alert Owner, temp firewall block |
| Failed auth | 60s | >3 attempts / 5 min | Lockdown mode |
| New listening port | 300s | Any unexpected | Alert Owner |
| File integrity (AIDE) | 3600s | Any change | Alert Owner, log details |
| Sudo escalation | 60s | Any non-whitelisted | Alert Owner, block command |
| Unusual process | 300s | CPU > 90% unknown process | Alert Owner, capture process info |
| Reverse shell pattern | 60s | lsof suspicious FDs | Lockdown mode, preserve evidence |

### Automated Response Actions

```python
async def intrusion_response(trigger: str, details: dict):
    """Execute automated containment based on trigger type."""
    
    if trigger == "brute_force_ssh":
        # Block IP at firewall level
        ip = details["source_ip"]
        await shell(f"sudo ufw insert 1 deny from {ip} to any port 22")
        await notify_owner(f"Blocked SSH brute force from {ip}")
    
    elif trigger == "failed_auth_spike":
        # Enter lockdown mode
        await enter_lockdown("Auth failure spike detected")
    
    elif trigger == "reverse_shell_detected":
        # Immediate containment
        await enter_lockdown("Potential reverse shell detected")
        # Preserve process tree for forensic analysis
        await shell("ps auxf > /opt/nova-os/forensics/process_tree_$(date +%s).txt")
        await shell("ss -tlnp >> /opt/nova-os/forensics/network_$(date +%s).txt")
        await shell("lsof -i > /opt/nova-os/forensics/open_connections_$(date +%s).txt")
```

### Fail2ban Integration

```bash
# Install and configure fail2ban for SSH
sudo apt-get install -y fail2ban

# /etc/fail2ban/jail.local
[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 5
findtime = 600
bantime = 3600

# Nova-OS custom filter for bot auth
[nova-os-auth]
enabled = true
filter = nova-os-auth
logpath = /var/log/nova-os/audit.log
maxretry = 3
findtime = 300
bantime = 86400
```

## Secure Communication

### Telegram Message Security

- All bot communications use Telegram's MTProto encryption (client-server and server-client)
- Sensitive data never sent in plain text in Telegram messages
- Secret references use UUIDs, never actual values
- File transfers over Telegram use Telegram's encrypted file storage

### Webhook Security

```python
# Secret token validation
async def validate_webhook(request: web.Request) -> bool:
    expected = os.environ.get("NOVA_OS_WEBHOOK_SECRET", "")
    received = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    return hmac.compare_digest(expected, received)

# IP whitelist for webhooks (if behind reverse proxy)
ALLOWED_IPS = {"149.154.160.0/20", "91.108.4.0/22"}
```

### API Credential Storage

All API credentials stored encrypted. Runtime resolution only:

```python
# NEVER do this:
API_KEY = "sk-1234567890abcdef"  # FORBIDDEN

# ALWAYS do this:
API_KEY = await resolve_secret("service_api_key")
```

## Credential Rotation

### Automated Rotation Schedule

```python
async def check_rotation_schedule():
    """Run daily. Notify about upcoming rotations."""
    rows = await db.fetchall(
        "SELECT name, last_rotated, rotation_days FROM secrets_ref WHERE rotation_days > 0"
    )
    
    for row in rows:
        age_days = (datetime.utcnow() - row["last_rotated"]).days
        remaining = row["rotation_days"] - age_days
        
        if remaining <= 7:
            await notify_owner(
                f"Secret `{row['name']}` expires in {remaining} days. "
                f"Use `/rotate {row['name']}` to rotate."
            )
```

## Backup Encryption

### Backup Encryption Process

```bash
# Create encrypted backup
age --recipient $(cat /opt/nova-os/backup_recipient.txt) \
    -o /backup/nova-os_$(date +%Y%m%d_%H%M%S).tar.gz.age \
    /backup/nova-os_$(date +%Y%m%d_%H%M%S).tar.gz

# Decrypt backup
age --identity /opt/nova-os/backup_identity.txt \
    -o backup.tar.gz \
    backup.tar.gz.age
```

### Backup Verification

```python
async def verify_backup(backup_path: str) -> dict:
    """Verify backup integrity by decrypting and checking structure."""
    # Decrypt to temp location
    temp = Path("/tmp/nova-os/verify") / str(int(time.time()))
    temp.mkdir(parents=True)
    
    result = await shell(
        f"age --identity /opt/nova-os/backup_identity.txt -o {temp}/backup.tar.gz {backup_path}"
    )
    
    if result["returncode"] != 0:
        return {"valid": False, "error": "Decryption failed"}
    
    # Check tarball structure
    result = await shell(f"tar tzf {temp}/backup.tar.gz | head -20")
    files = result["stdout"].split("\n")
    
    required = ["state.db", "config.yaml", "secrets/"]
    missing = [r for r in required if not any(r in f for f in files)]
    
    # Cleanup temp
    await shell(f"rm -rf {temp}")
    
    return {
        "valid": len(missing) == 0,
        "missing": missing,
        "file_count": len(files)
    }
```

## Incident Response Playbook

### Severity Classification

| Level | Criteria | Response Time | Notification |
|---|---|---|---|
| **Critical** | Data breach, unauthorized root access, ransomware | Immediate | Owner + Emergency contacts |
| **High** | Failed auth spike, reverse shell suspected, cert expiry < 24h | 5 minutes | Owner |
| **Medium** | Unusual process, disk full, service down > 10 min | 15 minutes | Owner |
| **Low** | Failed login 1-5 attempts, SSL expiry < 7 days, update available | 1 hour | Info message |

### Containment Procedures

**Lockdown Mode Activation (`/panic` or automatic):**

1. Stop accepting commands from non-Owner users
2. Preserve current process state to `/opt/nova-os/forensics/`
3. Disable webhook if active (prevent further external triggers)
4. Create firewall rule: block all inbound except SSH from Owner's known IP
5. Capture: process tree, network connections, open files, recent logs
6. Send alert to Owner with forensic summary
7. Enter diagnostic mode for all subsequent operations

**Recovery from Lockdown:**

1. Owner executes `/lockdown off` with reason
2. Validate Owner identity (two-factor via pre-shared code)
3. Review all actions taken during lockdown
4. Restore normal webhook/listening state
5. Notify Owner: "Lockdown lifted. Normal operations resumed."

### Forensic Evidence Preservation

```bash
# Automated forensic collection
forensics_dir="/opt/nova-os/forensics/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$forensics_dir"

ps auxf > "$forensics_dir/process_tree.txt"
netstat -tlnp > "$forensics_dir/listening_ports.txt"
ss -tn > "$forensics_dir/tcp_connections.txt"
lsof -i > "$forensics_dir/open_network_files.txt"
cat /var/log/auth.log | tail -1000 > "$forensics_dir/auth.log"
journalctl --since "1 hour ago" > "$forensics_dir/recent_journal.txt"
dpkg -l > "$forensics_dir/installed_packages.txt"
cat /proc/meminfo > "$forensics_dir/memory.txt"
df -h > "$forensics_dir/disk_usage.txt"

# Hash all evidence
find "$forensics_dir" -type f -exec sha256sum {} \; > "$forensics_dir/manifest.sha256"
```
