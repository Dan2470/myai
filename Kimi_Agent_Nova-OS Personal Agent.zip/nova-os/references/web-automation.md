# Web Intelligence Reference

Browser automation, REST API consumption, webhook server setup, data extraction, form automation, and multi-platform integrations for Nova-OS.

## Table of Contents

1. [HTTP Client Patterns](#http-client-patterns)
2. [REST API Consumption](#rest-api-consumption)
3. [Browser Automation](#browser-automation)
4. [Data Extraction](#data-extraction)
5. [Webhook Server](#webhook-server)
6. [Cloud Platform CLIs](#cloud-platform-clis)
7. [GitHub Integration](#github-integration)
8. [DNS & Certificate Automation](#dns--certificate-automation)
9. [Form Automation](#form-automation)
10. [Rate Limiting & Resilience](#rate-limiting--resilience)

## HTTP Client Patterns

### Client Setup

```python
import httpx
from typing import Optional

class WebClient:
    """Shared HTTP client with connection pooling and timeout defaults."""
    
    def __init__(self, timeout: float = 30.0):
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout),
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
            headers={"User-Agent": "Nova-OS/1.0 (Autonomous System Agent)"}
        )
    
    async def request(
        self,
        method: str,
        url: str,
        headers: dict = None,
        json_data: dict = None,
        params: dict = None,
        auth: tuple = None
    ) -> httpx.Response:
        return await self.client.request(
            method=method,
            url=url,
            headers=headers,
            json=json_data,
            params=params,
            auth=auth
        )
    
    async def close(self):
        await self.client.aclose()

# Global client instance
web = WebClient()
```

### Response Handling

```python
async def handle_response(response: httpx.Response, expect_json: bool = True):
    """Standardized response processing with error classification."""
    if response.status_code == 200:
        return response.json() if expect_json else response.text
    elif response.status_code == 204:
        return None
    elif response.status_code == 401:
        raise AuthenticationError(f"Invalid credentials for {response.url}")
    elif response.status_code == 403:
        raise PermissionError(f"Access denied for {response.url}")
    elif response.status_code == 404:
        raise NotFoundError(f"Resource not found: {response.url}")
    elif response.status_code == 429:
        retry_after = int(response.headers.get("Retry-After", 60))
        raise RateLimitError(f"Rate limited. Retry after {retry_after}s", retry_after)
    elif response.status_code >= 500:
        raise ServerError(f"Server error {response.status_code} from {response.url}")
    else:
        raise APIError(f"HTTP {response.status_code}: {response.text[:500]}")
```

## REST API Consumption

### Generic CRUD Pattern

```python
class APIClient:
    """Generic REST API client with Nova-OS conventions."""
    
    def __init__(self, base_url: str, api_key: str = None, auth_header: str = "Authorization"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.auth_header = auth_header
    
    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers[self.auth_header] = f"Bearer {self.api_key}"
        return headers
    
    async def get(self, endpoint: str, params: dict = None):
        response = await web.client.get(
            f"{self.base_url}{endpoint}",
            headers=self._headers(),
            params=params
        )
        return await handle_response(response)
    
    async def post(self, endpoint: str, data: dict = None):
        response = await web.client.post(
            f"{self.base_url}{endpoint}",
            headers=self._headers(),
            json=data
        )
        return await handle_response(response)
    
    async def put(self, endpoint: str, data: dict = None):
        response = await web.client.put(
            f"{self.base_url}{endpoint}",
            headers=self._headers(),
            json=data
        )
        return await handle_response(response)
    
    async def delete(self, endpoint: str):
        response = await web.client.delete(
            f"{self.base_url}{endpoint}",
            headers=self._headers()
        )
        return await handle_response(response)
```

### Secret Resolution

API keys are never hardcoded. They are referenced by name and resolved at runtime:

```python
async def resolve_secret(secret_name: str) -> str:
    """Resolve a secret from the encrypted vault."""
    # Implementation in security-protocols.md
    # Returns decrypted secret value
    pass

# Usage
api_key = await resolve_secret("github_api_token")
github = APIClient("https://api.github.com", api_key)
```

## Browser Automation

### Playwright Setup

```python
from playwright.async_api import async_playwright, Browser, BrowserContext

_browser: Browser = None
_context: BrowserContext = None

async def get_browser() -> Browser:
    global _browser
    if _browser is None:
        pw = await async_playwright().start()
        _browser = await pw.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"]
        )
    return _browser

async def get_context() -> BrowserContext:
    global _context
    if _context is None:
        browser = await get_browser()
        _context = await browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
    return _context

async def close_browser():
    global _browser, _context
    if _context:
        await _context.close()
        _context = None
    if _browser:
        await _browser.close()
        _browser = None
```

### Navigation & Interaction

```python
async def browser_navigate(url: str, wait_for: str = None, timeout: int = 30000):
    """Navigate to URL with optional wait condition."""
    context = await get_context()
    page = await context.new_page()
    
    try:
        await page.goto(url, wait_until="networkidle", timeout=timeout)
        if wait_for:
            await page.wait_for_selector(wait_for, timeout=timeout)
        content = await page.content()
        return {"content": content, "url": page.url, "status": 200}
    except Exception as e:
        return {"error": str(e), "url": url}
    finally:
        await page.close()

async def browser_click(url: str, selector: str, wait_for_navigation: bool = True):
    """Click element on page."""
    context = await get_context()
    page = await context.new_page()
    
    try:
        await page.goto(url, wait_until="networkidle")
        async with page.expect_navigation() if wait_for_navigation else page.expect_timeout(0):
            await page.click(selector)
        return {"content": await page.content(), "url": page.url}
    finally:
        await page.close()

async def browser_form_submit(url: str, form_data: dict, submit_selector: str = "button[type=submit]"):
    """Fill and submit a form."""
    context = await get_context()
    page = await context.new_page()
    
    try:
        await page.goto(url, wait_until="networkidle")
        for field, value in form_data.items():
            await page.fill(f"[name='{field}'], #{field}, [placeholder='{field}' i]", value)
        await page.click(submit_selector)
        await page.wait_for_load_state("networkidle")
        return {"content": await page.content(), "url": page.url}
    finally:
        await page.close()
```

### Screenshot & PDF

```python
async def browser_screenshot(url: str, output_path: str, full_page: bool = True):
    """Capture screenshot of webpage."""
    context = await get_context()
    page = await context.new_page()
    
    try:
        await page.goto(url, wait_until="networkidle")
        await page.screenshot(path=output_path, full_page=full_page)
        return {"path": output_path, "size": Path(output_path).stat().st_size}
    finally:
        await page.close()

async def browser_pdf(url: str, output_path: str):
    """Generate PDF from webpage."""
    context = await get_context()
    page = await context.new_page()
    
    try:
        await page.goto(url, wait_until="networkidle")
        await page.pdf(path=output_path, format="A4")
        return {"path": output_path, "size": Path(output_path).stat().st_size}
    finally:
        await page.close()
```

## Data Extraction

### HTML Parsing

```python
from bs4 import BeautifulSoup

def extract_text(html: str, selector: str) -> list:
    """Extract text content by CSS selector."""
    soup = BeautifulSoup(html, "html.parser")
    elements = soup.select(selector)
    return [el.get_text(strip=True) for el in elements]

def extract_table(html: str, table_selector: str = "table") -> list[dict]:
    """Extract HTML table to list of dicts."""
    soup = BeautifulSoup(html, "html.parser")
    table = soup.select_one(table_selector)
    if not table:
        return []
    
    headers = [th.get_text(strip=True) for th in table.find_all("th")]
    rows = []
    for tr in table.find_all("tr")[1:]:
        cells = [td.get_text(strip=True) for td in tr.find_all(["td", "th"])]
        if cells:
            rows.append(dict(zip(headers, cells)))
    return rows

def extract_links(html: str, base_url: str = None) -> list[dict]:
    """Extract all links from HTML."""
    soup = BeautifulSoup(html, "html.parser")
    links = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if base_url and href.startswith("/"):
            href = base_url.rstrip("/") + href
        links.append({
            "text": a.get_text(strip=True),
            "href": href,
            "title": a.get("title", "")
        })
    return links
```

### JSON API Data Extraction

```python
def extract_nested(data: dict, path: str, default=None):
    """Safely extract nested dict value by dot path."""
    keys = path.split(".")
    current = data
    for key in keys:
        if isinstance(current, dict) and key in current:
            current = current[key]
        else:
            return default
    return current

# Example
total_count = extract_nested(api_response, "data.repositories.totalCount", 0)
```

## Webhook Server

### Generic Webhook Handler

```python
from aiohttp import web
import hmac
import hashlib

class WebhookManager:
    """Manage incoming webhooks from external services."""
    
    def __init__(self, secret: str = None):
        self.handlers = {}
        self.secret = secret
    
    def register(self, path: str, handler, verify_signature: bool = False):
        """Register a webhook handler at a specific path."""
        self.handlers[path] = {
            "handler": handler,
            "verify_signature": verify_signature
        }
    
    async def handle(self, request: web.Request) -> web.Response:
        path = request.path
        if path not in self.handlers:
            return web.Response(status=404)
        
        config = self.handlers[path]
        body = await request.read()
        
        # Signature verification (for supported services)
        if config["verify_signature"] and self.secret:
            signature = request.headers.get("X-Hub-Signature-256", "")
            expected = "sha256=" + hmac.new(
                self.secret.encode(), body, hashlib.sha256
            ).hexdigest()
            if not hmac.compare_digest(signature, expected):
                return web.Response(status=401)
        
        payload = await request.json() if body else {}
        try:
            await config["handler"](payload, request.headers)
            return web.Response(status=200)
        except Exception as e:
            logger.error(f"Webhook handler error: {e}")
            return web.Response(status=500)

# Global instance
webhook_mgr = WebhookManager()

# Example registration
async def github_webhook_handler(payload: dict, headers: dict):
    event = headers.get("X-GitHub-Event")
    if event == "push":
        branch = payload["ref"].split("/")[-1]
        if branch == "main":
            await trigger_deploy("github_push", payload)
    elif event == "workflow_run":
        if payload["workflow_run"]["conclusion"] == "success":
            await notify_owner(f"CI passed for {payload['repository']['full_name']}")

webhook_mgr.register("/webhooks/github", github_webhook_handler, verify_signature=True)
```

## Cloud Platform CLIs

### AWS CLI

```bash
# Configuration via environment or ~/.aws/
export AWS_DEFAULT_REGION=us-east-1

# Common operations
aws ec2 describe-instances --filters "Name=instance-state-name,Values=running" --query 'Reservations[*].Instances[*].[InstanceId,InstanceType,PublicIpAddress,Tags[?Key==Name].Value|[0]]' --output table

aws s3 ls s3://<bucket>/ --recursive --human-readable --summarize

aws logs tail <log-group> --follow

aws rds describe-db-instances --query 'DBInstances[*].[DBInstanceIdentifier,DBInstanceStatus,Endpoint.Address]'
```

### GCP CLI

```bash
# Configuration via service account
gcloud auth activate-service-account --key-file=<keyfile>

# Common operations
gcloud compute instances list --format="table(name, zone, status, networkInterfaces[0].accessConfigs[0].natIP)"

gcloud logging read "resource.type=gae_app" --limit=50 --format=json
```

### Azure CLI

```bash
# Login via service principal
az login --service-principal -u <app-id> -p <secret> --tenant <tenant>

# Common operations
az vm list --show-details --output table

az webapp log tail --name <app> --resource-group <rg>
```

## GitHub Integration

### Repository Operations

```python
async def github_request(endpoint: str, method: str = "GET", data: dict = None):
    token = await resolve_secret("github_api_token")
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json"
    }
    response = await web.client.request(
        method=method,
        url=f"https://api.github.com{endpoint}",
        headers=headers,
        json=data
    )
    return await handle_response(response)

# Workflows
async def trigger_workflow(repo: str, workflow_id: str, branch: str = "main", inputs: dict = None):
    return await github_request(
        f"/repos/{repo}/actions/workflows/{workflow_id}/dispatches",
        method="POST",
        data={"ref": branch, "inputs": inputs or {}}
    )

async def get_workflow_runs(repo: str, workflow_id: str, limit: int = 5):
    return await github_request(
        f"/repos/{repo}/actions/workflows/{workflow_id}/runs?per_page={limit}"
    )

# Repository info
async def get_repo_info(repo: str):
    return await github_request(f"/repos/{repo}")

async def list_repos(org: str):
    return await github_request(f"/orgs/{org}/repos?per_page=100")
```

## DNS & Certificate Automation

### Cloudflare DNS

```python
async def cloudflare_request(endpoint: str, method: str = "GET", data: dict = None):
    token = await resolve_secret("cloudflare_api_token")
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    response = await web.client.request(
        method=method,
        url=f"https://api.cloudflare.com/client/v4{endpoint}",
        headers=headers,
        json=data
    )
    result = await handle_response(response)
    if not result.get("success"):
        raise APIError(f"Cloudflare error: {result.get('errors', 'Unknown')}")
    return result["result"]

async def dns_list_records(zone_id: str):
    return await cloudflare_request(f"/zones/{zone_id}/dns_records")

async def dns_update_record(zone_id: str, record_id: str, record_type: str, name: str, content: str):
    return await cloudflare_request(
        f"/zones/{zone_id}/dns_records/{record_id}",
        method="PUT",
        data={"type": record_type, "name": name, "content": content, "ttl": 1}
    )
```

### Let's Encrypt Certificate Automation

```bash
# Issue certificate (DNS challenge via Cloudflare plugin)
sudo certbot certonly \
    --dns-cloudflare \
    --dns-cloudflare-credentials /opt/nova-os/secrets/cloudflare.ini \
    -d "*.example.com" -d "example.com" \
    --agree-tos --non-interactive --expand

# Renew all certificates
sudo certbot renew --quiet

# Certificate info
sudo openssl x509 -in /etc/letsencrypt/live/example.com/fullchain.pem -noout -text

# Days until expiry
echo $(( ($(date -d "$(sudo openssl x509 -in /etc/letsencrypt/live/example.com/cert.pem -noout -enddate | cut -d= -f2)" +%s) - $(date +%s)) / 86400 ))
```

## Form Automation

### Generic Form Submission

```python
async def submit_form(
    url: str,
    fields: dict,
    submit_button: str = "button[type=submit]",
    wait_for_selector: str = None
) -> dict:
    """
    Fill and submit a web form.
    
    Args:
        url: Form page URL
        fields: Dict of {field_name: value}
        submit_button: CSS selector for submit button
        wait_for_selector: Optional selector to wait for after submit
    """
    context = await get_context()
    page = await context.new_page()
    
    try:
        await page.goto(url, wait_until="networkidle")
        
        for field_name, value in fields.items():
            # Try multiple selector strategies
            selectors = [
                f"input[name='{field_name}']",
                f"textarea[name='{field_name}']",
                f"select[name='{field_name}']",
                f"#{field_name}",
                f"[placeholder='{field_name}' i]",
                f"label:has-text('{field_name}') + input",
            ]
            
            element = None
            for selector in selectors:
                try:
                    element = await page.wait_for_selector(selector, timeout=2000)
                    if element:
                        break
                except:
                    continue
            
            if not element:
                raise ValueError(f"Could not find form field: {field_name}")
            
            tag_name = await element.evaluate("el => el.tagName")
            
            if tag_name == "SELECT":
                await page.select_option(selectors[0], value)
            elif tag_name == "INPUT":
                input_type = await element.evaluate("el => el.type")
                if input_type == "checkbox":
                    if value:
                        await element.check()
                    else:
                        await element.uncheck()
                elif input_type == "radio":
                    await page.click(f"input[type=radio][value='{value}']")
                elif input_type == "file":
                    await element.set_input_files(value)
                else:
                    await element.fill(str(value))
            elif tag_name == "TEXTAREA":
                await element.fill(str(value))
        
        # Submit form
        if submit_button:
            await page.click(submit_button)
        
        if wait_for_selector:
            await page.wait_for_selector(wait_for_selector, timeout=30000)
        else:
            await page.wait_for_load_state("networkidle")
        
        return {
            "success": True,
            "url": page.url,
            "content": await page.content()
        }
        
    finally:
        await page.close()
```

## Rate Limiting & Resilience

### Circuit Breaker

```python
import time
from enum import Enum

class CircuitState(Enum):
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if recovered

class CircuitBreaker:
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = CircuitState.CLOSED
        self.failures = 0
        self.last_failure_time = 0
    
    async def call(self, coro, *args, **kwargs):
        if self.state == CircuitState.OPEN:
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = CircuitState.HALF_OPEN
            else:
                raise ServiceUnavailable("Circuit breaker is OPEN")
        
        try:
            result = await coro(*args, **kwargs)
            if self.state == CircuitState.HALF_OPEN:
                self.state = CircuitState.CLOSED
                self.failures = 0
            return result
        except Exception as e:
            self.failures += 1
            self.last_failure_time = time.time()
            if self.failures >= self.failure_threshold:
                self.state = CircuitState.OPEN
            raise

# Usage
github_breaker = CircuitBreaker(failure_threshold=3, recovery_timeout=300)
result = await github_breaker.call(github_request, "/user")
```

### Exponential Backoff

```python
import random

async def with_backoff(coro, max_retries: int = 5, base_delay: float = 1.0, max_delay: float = 60.0):
    for attempt in range(max_retries):
        try:
            return await coro
        except (RateLimitError, ServerError) as e:
            if attempt == max_retries - 1:
                raise
            
            delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)
            if hasattr(e, 'retry_after'):
                delay = max(delay, e.retry_after)
            
            await asyncio.sleep(delay)
```
