# System Control Reference

Shell execution, process management, filesystem operations, service control, package management, container operations, and database access patterns for Nova-OS.

## Table of Contents

1. [Shell Execution Patterns](#shell-execution-patterns)
2. [Process Management](#process-management)
3. [Filesystem Operations](#filesystem-operations)
4. [Service Management](#service-management)
5. [Package Management](#package-management)
6. [Docker & Container Operations](#docker--container-operations)
7. [Database Operations](#database-operations)
8. [Network Diagnostics](#network-diagnostics)
9. [Log Analysis Patterns](#log-analysis-patterns)
10. [Resource Monitoring](#resource-monitoring)

## Shell Execution Patterns

### Command Execution Wrapper

All shell commands execute through `subprocess` with asyncio support. Use the wrapper pattern:

```python
import asyncio
import subprocess

async def shell(cmd: str, timeout: int = 30, cwd: str = None, env: dict = None) -> dict:
    """
    Execute shell command with structured output.
    
    Returns: {
        'stdout': str,
        'stderr': str,
        'returncode': int,
        'duration_ms': int,
        'command': str
    }
    """
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
        env={**os.environ, **(env or {})}
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return {
            'stdout': stdout.decode('utf-8', errors='replace').strip(),
            'stderr': stderr.decode('utf-8', errors='replace').strip(),
            'returncode': proc.returncode,
            'duration_ms': int((asyncio.get_event_loop().time() - start) * 1000),
            'command': cmd
        }
    except asyncio.TimeoutError:
        proc.kill()
        return {'stdout': '', 'stderr': 'Command timed out', 'returncode': -1, 'duration_ms': timeout * 1000, 'command': cmd}
```

### Privilege Escalation

Nova-OS runs as unprivileged user `nova-os`. Use `sudo` for specific whitelisted commands only. The `/etc/sudoers.d/nova-os` file defines allowed commands:

```
nova-os ALL=(root) NOPASSWD: /bin/systemctl *, /usr/bin/apt-get update, /usr/bin/certbot *, /usr/sbin/ufw *
```

Always validate command against whitelist before execution. Never pass user input directly to sudo commands without sanitization.

### Command Sanitization

All user input that reaches shell commands must pass through `shlex.quote()`:

```python
import shlex
safe_arg = shlex.quote(user_input)
result = await shell(f"ls -la {safe_arg}")
```

Never use f-string interpolation for command construction without shlex.quote. Prefer parameterized approaches.

### Exit Code Interpretation

| Code Range | Meaning | Action |
|---|---|---|
| 0 | Success | Report results |
| 1 | General error | Investigate stderr |
| 2 | Misuse of command | Check syntax |
| 126 | Command not executable | Permission issue |
| 127 | Command not found | Check PATH / package |
| 128+N | Fatal signal N | Process killed by signal |
| 130 | Ctrl+C (SIGINT) | Interrupted by user |
| 137 | SIGKILL (OOM or kill -9) | Resource exhaustion |
| 255 | Exit status out of range | SSH or remote error |

## Process Management

### Process Inspection

```bash
# All processes with resource usage
ps aux --sort=-%mem | head -20

# Process tree with PIDs and commands
pstree -p

# Specific process details
ps -p <PID> -o pid,ppid,cmd,%cpu,%mem,etime,nlwp

# Open files by process
lsof -p <PID>

# Process environment
cat /proc/<PID>/environ | tr '\0' '\n'
```

### Process Control

```bash
# Graceful termination
kill -TERM <PID>

# Force kill (last resort)
kill -KILL <PID>

# Kill by name (verify first)
pkill -f <pattern>
killall <name>

# Send SIGHUP to reload config
kill -HUP <PID>
```

Nova-OS always attempts SIGTERM first, waits 10s, then SIGKILL if still running.

### Background Jobs

```python
# Start long-running process detached from terminal
async def start_daemon(cmd: str, log_file: str, working_dir: str = None) -> int:
    proc = await asyncio.create_subprocess_shell(
        f"nohup {cmd} >> {log_file} 2>&1 & echo $!",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=working_dir
    )
    stdout, _ = await proc.communicate()
    pid = int(stdout.decode().strip())
    return pid
```

## Filesystem Operations

### Path Conventions

- Configuration: `/opt/nova-os/config.yaml`
- State database: `/opt/nova-os/state.db`
- Logs: `/var/log/nova-os/`
- Temp workspace: `/tmp/nova-os/`
- Backups: `/opt/nova-os/backups/`
- Scripts: `/opt/nova-os/scripts/`
- Secrets (encrypted): `/opt/nova-os/secrets/`

### Safe File Operations

```python
import pathlib
import tempfile
import shutil

NOVA_ROOT = pathlib.Path("/opt/nova-os")
PROTECTED_PATHS = [
    "/", "/boot", "/etc", "/usr", "/var",
    "/root", "/home", "/dev", "/proc", "/sys"
]

def is_safe_path(target: str) -> bool:
    """Prevent operations on protected system paths."""
    resolved = pathlib.Path(target).resolve()
    return not any(resolved == pathlib.Path(p) or p in str(resolved) for p in PROTECTED_PATHS)

def safe_write(path: str, content: str, mode: str = "w") -> dict:
    """Atomic write with backup."""
    target = pathlib.Path(path)
    if not is_safe_path(path):
        return {"error": "Path is protected", "path": path}
    
    # Create backup if file exists
    if target.exists():
        backup = target.with_suffix(f".backup.{int(time.time())}")
        shutil.copy2(target, backup)
    
    # Atomic write via temp file
    tmp = tempfile.NamedTemporaryFile(mode=mode, delete=False, dir=target.parent)
    try:
        tmp.write(content)
        tmp.close()
        shutil.move(tmp.name, target)
        return {"success": True, "path": str(target), "bytes": len(content)}
    except Exception as e:
        os.unlink(tmp.name)
        return {"error": str(e), "path": path}
```

### Disk Usage Management

```bash
# Human-readable disk usage
df -h

# Directory size breakdown
du -sh /opt/nova-os/* | sort -rh | head -20

# Find large files (>100MB)
find /var/log -type f -size +100M -exec ls -lh {} \;

# Inode usage
df -i
```

### Log Rotation

```bash
# Manual log rotation via logrotate
sudo logrotate -f /etc/logrotate.d/nova-os

# Compress old logs
find /var/log/nova-os -name "*.log" -mtime +7 -exec gzip {} \;

# Purge logs older than 30 days
find /var/log/nova-os -name "*.gz" -mtime +30 -delete
```

## Service Management

### systemd Operations

```bash
# Service status
systemctl is-active <service>
systemctl is-enabled <service>

# Service control (via sudo whitelist)
sudo systemctl start <service>
sudo systemctl stop <service>
sudo systemctl restart <service>
sudo systemctl reload <service>

# View service logs
journalctl -u <service> -n 50 --no-pager
journalctl -u <service> --since "10 minutes ago" --no-pager
journalctl -u <service> -f  # follow

# List failed services
systemctl --failed --no-pager

# Service dependencies
systemctl list-dependencies <service> --no-pager
```

### Custom Nova-OS Service

The Nova-OS agent itself runs as a systemd service at `/etc/systemd/system/nova-os.service`:

```ini
[Unit]
Description=Nova-OS Master Agent
After=network.target

[Service]
Type=simple
User=nova-os
Group=nova-os
WorkingDirectory=/opt/nova-os
Environment=PYTHONPATH=/opt/nova-os
EnvironmentFile=/opt/nova-os/.env
ExecStart=/opt/nova-os/venv/bin/python -m nova_os.agent
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

## Package Management

### APT Operations

```bash
# Update package lists (whitelisted)
sudo apt-get update

# Upgrade (requires explicit confirmation via Telegram)
sudo apt-get upgrade -y

# Install specific package
sudo apt-get install -y <package>

# Remove package
sudo apt-get remove --purge <package>

# Search packages
apt-cache search <term>

# Show package info
apt-cache show <package>

# List installed packages matching pattern
dpkg -l | grep <pattern>

# Check for security updates
/usr/lib/update-notifier/apt-check --human-readable
```

### Python Environment

Nova-OS runs in its own virtual environment:

```bash
# Venv location
/opt/nova-os/venv/

# Install packages
/opt/nova-os/venv/bin/pip install <package>

# List installed
/opt/nova-os/venv/bin/pip list

# Requirements freeze
/opt/nova-os/venv/bin/pip freeze > /opt/nova-os/requirements.txt
```

## Docker & Container Operations

### Container Lifecycle

```bash
# List containers
docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

# Container stats
docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}"

# Container logs
docker logs --tail 50 <container>

# Start / stop / restart
docker start <container>
docker stop <container>  # sends SIGTERM, waits 10s, then SIGKILL
docker restart <container>

# Execute command in running container
docker exec -it <container> <command>

# Inspect container config
docker inspect <container>
```

### Image Management

```bash
# List images
docker images --format "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"

# Pull image
docker pull <image>:<tag>

# Remove unused images
docker image prune -a -f

# Build image
docker build -t <tag> -f <Dockerfile> <context>
```

### Compose Operations

```bash
# Deploy stack
docker compose -f /opt/nova-os/stacks/<stack>/docker-compose.yml up -d

# View compose services
docker compose -f <file> ps

# Update stack (pull and recreate)
docker compose -f <file> pull && docker compose -f <file> up -d

# View compose logs
docker compose -f <file> logs --tail 50

# Validate compose file
docker compose -f <file> config
```

### Volume Management

```bash
# List volumes
docker volume ls

# Volume usage
docker system df -v

# Backup volume
docker run --rm -v <volume>:/data -v /backup:/backup alpine tar czf /backup/<volume>.tar.gz -C /data .

# Restore volume
docker run --rm -v <volume>:/data -v /backup:/backup alpine tar xzf /backup/<volume>.tar.gz -C /data
```

## Database Operations

### PostgreSQL

```bash
# Connect via psql
PGPASSWORD=<secret_ref> psql -h <host> -U <user> -d <db> -c "<query>"

# Database list
psql -U postgres -l

# Table sizes
psql -d <db> -c "SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) FROM pg_tables WHERE schemaname='public' ORDER BY pg_total_relation_size DESC LIMIT 10;"

# Active connections
psql -d <db> -c "SELECT pid, usename, application_name, state, query_start, query FROM pg_stat_activity WHERE state = 'active';"

# Kill connection
psql -U postgres -c "SELECT pg_terminate_backend(<pid>);"

# Backup
dump_file="/backup/<db>_$(date +%Y%m%d_%H%M%S).sql"
pg_dump -h <host> -U <user> -d <db> -Fc -f "$dump_file"
```

### MySQL / MariaDB

```bash
# Connect
mysql -u <user> -p<secret> -h <host> -D <db> -e "<query>"

# Database sizes
mysql -e "SELECT table_schema, ROUND(SUM(data_length+index_length)/1024/1024,2) AS size_mb FROM information_schema.tables GROUP BY table_schema ORDER BY size_mb DESC;"

# Process list
mysql -e "SHOW FULL PROCESSLIST;"

# Kill query
mysql -e "KILL <id>;"

# Backup
mysqldump -u <user> -p<secret> <db> | gzip > "/backup/<db>_$(date +%Y%m%d_%H%M%S).sql.gz"
```

### Redis

```bash
# Connect via redis-cli
redis-cli -h <host> -p <port> -a <secret> INFO

# Key count per database
redis-cli INFO keyspace

# Memory usage
redis-cli INFO memory

# Slow queries
redis-cli SLOWLOG GET 10

# Flush database (DESTRUCTIVE — requires confirmation)
redis-cli FLUSHDB

# Backup (RDB)
redis-cli BGSAVE
# File saved to /var/lib/redis/dump.rdb
```

## Network Diagnostics

```bash
# Listening ports
ss -tlnp | grep LISTEN

# Established connections
ss -tn state established | wc -l

# Bandwidth usage (iftop required)
sudo iftop -t -s 10 -n

# Route table
ip route show

# DNS resolution
dig +short <domain>
host <domain>

# Test connectivity
curl -I -s -o /dev/null -w "%{http_code} %{time_total}s" <url>
ping -c 4 <host>
mtr -n -c 10 <host>

# Check certificate expiry
echo | openssl s_client -servername <domain> -connect <domain>:443 2>/dev/null | openssl x509 -noout -dates
```

## Log Analysis Patterns

### Real-time Log Monitoring

```bash
# Follow logs with highlight
journalctl -u <service> -f -n 0 | grep --color -E "ERROR|WARN|FATAL|$"

# Multi-service log aggregation
journalctl -u <svc1> -u <svc2> --since "1 hour ago" --no-pager

# Log rate analysis
cat /var/log/syslog | awk '{print $1" "$2" "$3}' | uniq -c
```

### Log Parsing with awk/jq

```bash
# Extract error frequency from application logs
grep "ERROR" /var/log/app.log | awk -F'|' '{print $3}' | sort | uniq -c | sort -rn | head -10

# Parse JSON logs
jq -r 'select(.level == "error") | .message' /var/log/app.json.log | head -20

# Request duration statistics from Nginx
awk '{print $NF}' /var/log/nginx/access.log | sort -n | awk '{a[i++]=$1} END {print "min="a[0], "max="a[i-1], "median="a[int(i/2)]}'
```

## Resource Monitoring

### CPU and Memory

```bash
# CPU info
lscpu | grep -E "Model name|CPU\(s\)|Thread|Core"

# Memory breakdown
cat /proc/meminfo | grep -E "MemTotal|MemFree|MemAvailable|Buffers|Cached|Swap"

# Per-process memory
ps aux --sort=-%mem | head -10

# Load average
uptime
cat /proc/loadavg

# CPU usage by process (pidstat required)
pidstat -u 1 5 | tail -n +4 | sort -k8 -rn | head -10
```

### Disk I/O

```bash
# I/O statistics
iostat -x 1 5

# Per-process I/O
pidstat -d 1 5

# Disk latency
iotop -o -b -n 5
```

### System Temperature / Hardware

```bash
# Temperature sensors (lm-sensors)
sensors

# Battery status (if applicable)
cat /sys/class/power_supply/BAT0/capacity 2>/dev/null

# RAID status (if applicable)
cat /proc/mdstat
```
