# Automation Engine Reference

Cron scheduling, event-driven reactions, CI/CD pipeline orchestration, task queue management, and fault tolerance for Nova-OS.

## Table of Contents

1. [Scheduler Architecture](#scheduler-architecture)
2. [Cron Job Management](#cron-job-management)
3. [Event-Driven Automation](#event-driven-automation)
4. [CI/CD Pipeline Patterns](#cicd-pipeline-patterns)
5. [Task Queue System](#task-queue-system)
6. [Workflow Definitions](#workflow-definitions)
7. [Fault Tolerance & Recovery](#fault-tolerance--recovery)
8. [Health Check System](#health-check-system)
9. [Backup Orchestration](#backup-orchestration)
10. [Monitoring Integration](#monitoring-integration)

## Scheduler Architecture

### Async Scheduler Setup

```python
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

scheduler = AsyncIOScheduler(timezone="UTC")

async def start_scheduler():
    """Initialize and start the automation scheduler."""
    # Load persisted jobs from database
    jobs = await db.fetchall("SELECT * FROM scheduled_jobs WHERE enabled = 1")
    for job in jobs:
        await register_job(job)
    
    scheduler.start()

async def register_job(job_def: dict):
    """Register a job with the scheduler."""
    trigger = CronTrigger.from_crontab(job_def["schedule"]) if job_def["schedule"].startswith("*") else IntervalTrigger(seconds=parse_interval(job_def["schedule"]))
    
    scheduler.add_job(
        execute_workflow,
        trigger=trigger,
        id=job_def["id"],
        args=[job_def["workflow"], job_def.get("params", {})],
        max_instances=1,  # Prevent overlapping runs
        coalesce=True     # Catch up missed runs
    )
```

## Cron Job Management

### Telegram CRUD Interface

```python
@router.message(Command("cron"))
async def cmd_cron(message: Message):
    """Manage scheduled jobs. Syntax:
    /cron list                    - Show all jobs
    /cron add <name> <schedule> <workflow>  - Add job
    /cron remove <name>           - Remove job
    /cron enable/disable <name>   - Toggle job
    """
    pass
```

### Schedule Format

| Format | Example | Description |
|---|---|---|
| Standard cron | `0 2 * * *` | Daily at 02:00 UTC |
| Interval | `5m`, `1h`, `1d` | Every N minutes/hours/days |
| System events | `@reboot`, `@daily`, `@weekly` | Named triggers |

### Common Job Templates

```python
STANDARD_JOBS = {
    "system_update_check": {
        "schedule": "0 6 * * *",  # Daily 06:00 UTC
        "workflow": "check_updates",
        "params": {"notify": True, "auto_apply_security": False}
    },
    "security_audit": {
        "schedule": "0 3 * * 0",  # Weekly Sunday 03:00 UTC
        "workflow": "security_audit",
        "params": {"full_scan": True}
    },
    "backup_databases": {
        "schedule": "0 */6 * * *",  # Every 6 hours
        "workflow": "backup_all_databases",
        "params": {"encrypt": True, "retention_days": 30}
    },
    "cert_expiry_check": {
        "schedule": "0 8 * * *",  # Daily 08:00 UTC
        "workflow": "check_cert_expiry",
        "params": {"warn_days": 30, "auto_renew": True}
    },
    "log_rotation": {
        "schedule": "0 0 * * *",  # Daily midnight UTC
        "workflow": "rotate_logs",
        "params": {"compress_after_days": 7, "delete_after_days": 90}
    },
    "disk_cleanup": {
        "schedule": "0 4 * * *",  # Daily 04:00 UTC
        "workflow": "disk_cleanup",
        "params": {"threshold_percent": 85}
    }
}
```

## Event-Driven Automation

### Event Bus

```python
from typing import Callable
import asyncio

class EventBus:
    """Internal pub/sub event system for Nova-OS."""
    
    def __init__(self):
        self.subscribers: dict[str, list[Callable]] = {}
    
    def subscribe(self, event_type: str, handler: Callable):
        if event_type not in self.subscribers:
            self.subscribers[event_type] = []
        self.subscribers[event_type].append(handler)
    
    async def publish(self, event_type: str, payload: dict):
        handlers = self.subscribers.get(event_type, [])
        for handler in handlers:
            try:
                await handler(payload)
            except Exception as e:
                logger.error(f"Event handler error for {event_type}: {e}")

events = EventBus()
```

### Event Types & Handlers

```python
# System events
events.subscribe("service_down", handle_service_down)
events.subscribe("high_cpu", handle_high_cpu)
events.subscribe("high_memory", handle_high_memory)
events.subscribe("disk_full", handle_disk_full)
events.subscribe("cert_expiring_soon", handle_cert_expiry)

# Webhook events
events.subscribe("github_push", handle_git_push)
events.subscribe("github_pr_merged", handle_pr_merge)
events.subscribe("dockerhub_push", handle_image_push)

# Security events
events.subscribe("failed_auth", handle_failed_auth)
events.subscribe("intrusion_detected", handle_intrusion)

# Example handler
async def handle_service_down(payload: dict):
    service = payload["service"]
    restart_count = payload.get("restart_count", 0)
    
    if restart_count < 3:
        await shell(f"sudo systemctl restart {service}")
        await notify_owner(f"Auto-restarted {service} (attempt {restart_count + 1})")
    else:
        await notify_owner(f"CRITICAL: {service} failed {restart_count} times. Manual intervention required.")
        await enter_lockdown(f"Service {service} repeated failure")
```

## CI/CD Pipeline Patterns

### Pipeline Definition

```python
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum

class PipelineStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"

@dataclass
class PipelineStep:
    name: str
    command: str
    timeout: int = 300
    rollback_command: Optional[str] = None
    verify_command: Optional[str] = None
    on_failure: str = "stop"  # stop, continue, rollback

@dataclass
class Pipeline:
    name: str
    steps: list[PipelineStep]
    notification_targets: list[int] = field(default_factory=list)  # Telegram user IDs
    auto_rollback: bool = True
```

### Pipeline Execution

```python
async def execute_pipeline(pipeline: Pipeline, triggered_by: int) -> dict:
    """Execute a CI/CD pipeline with rollback support."""
    run_id = str(uuid.uuid4())
    status = PipelineStatus.RUNNING
    results = []
    
    # Record pipeline start
    await db.execute(
        "INSERT INTO pipeline_runs (id, name, status, started_at, triggered_by) VALUES (?, ?, ?, ?, ?)",
        (run_id, pipeline.name, status.value, datetime.utcnow(), triggered_by)
    )
    
    await notify_targets(pipeline, f"Pipeline `{pipeline.name}` started. Run: `{run_id[:8]}`")
    
    try:
        for step in pipeline.steps:
            step_result = await execute_pipeline_step(run_id, step)
            results.append(step_result)
            
            if step_result["exit_code"] != 0:
                if step.on_failure == "rollback" and pipeline.auto_rollback:
                    await rollback_pipeline(pipeline, results)
                    status = PipelineStatus.ROLLED_BACK
                    await notify_targets(pipeline, f"Pipeline `{pipeline.name}` ROLLED BACK at step `{step.name}`")
                    return {"run_id": run_id, "status": status.value, "results": results}
                elif step.on_failure == "stop":
                    status = PipelineStatus.FAILED
                    await notify_targets(pipeline, f"Pipeline `{pipeline.name}` FAILED at step `{step.name}`\nError: {step_result['stderr'][:500]}")
                    return {"run_id": run_id, "status": status.value, "results": results}
        
        status = PipelineStatus.SUCCESS
        await notify_targets(pipeline, f"Pipeline `{pipeline.name}` completed successfully.")
        
    except Exception as e:
        status = PipelineStatus.FAILED
        if pipeline.auto_rollback:
            await rollback_pipeline(pipeline, results)
            status = PipelineStatus.ROLLED_BACK
        await notify_targets(pipeline, f"Pipeline `{pipeline.name}` FAILED: {str(e)}")
    
    finally:
        await db.execute(
            "UPDATE pipeline_runs SET status = ?, completed_at = ?, results = ? WHERE id = ?",
            (status.value, datetime.utcnow(), json.dumps(results), run_id)
        )
    
    return {"run_id": run_id, "status": status.value, "results": results}

async def execute_pipeline_step(run_id: str, step: PipelineStep) -> dict:
    """Execute a single pipeline step."""
    step_start = time.time()
    result = await shell(step.command, timeout=step.timeout)
    
    # Verify step if verification command provided
    if step.verify_command and result["returncode"] == 0:
        verify = await shell(step.verify_command, timeout=30)
        if verify["returncode"] != 0:
            result["returncode"] = 1
            result["stderr"] += f"\nVerification failed: {verify['stderr']}"
    
    result["step_name"] = step.name
    result["duration_ms"] = int((time.time() - step_start) * 1000)
    
    return result

async def rollback_pipeline(pipeline: Pipeline, executed_steps: list):
    """Rollback executed steps in reverse order."""
    for step_result in reversed(executed_steps):
        step = next(s for s in pipeline.steps if s.name == step_result["step_name"])
        if step.rollback_command:
            await shell(step.rollback_command, timeout=60)
            await asyncio.sleep(2)  # Brief pause between rollbacks
```

### Example Deployment Pipeline

```python
deploy_production = Pipeline(
    name="deploy-production",
    steps=[
        PipelineStep(
            name="pre_deploy_checks",
            command="/opt/nova-os/scripts/pre_deploy_check.sh",
            verify_command="/opt/nova-os/scripts/verify_health.sh",
            on_failure="stop"
        ),
        PipelineStep(
            name="backup_database",
            command="/opt/nova-os/scripts/backup_db.sh",
            rollback_command="/opt/nova-os/scripts/restore_db.sh",
            on_failure="rollback"
        ),
        PipelineStep(
            name="pull_images",
            command="docker compose -f /opt/stacks/production/docker-compose.yml pull",
            on_failure="stop"
        ),
        PipelineStep(
            name="migrate_database",
            command="docker compose -f /opt/stacks/production/docker-compose.yml run --rm app python manage.py migrate",
            rollback_command="docker compose -f /opt/stacks/production/docker-compose.yml run --rm app python manage.py migrate previous",
            on_failure="rollback"
        ),
        PipelineStep(
            name="deploy_containers",
            command="docker compose -f /opt/stacks/production/docker-compose.yml up -d",
            rollback_command="docker compose -f /opt/stacks/production/docker-compose.yml down && docker compose -f /opt/stacks/production/docker-compose.yml up -d --no-recreate",
            verify_command="/opt/nova-os/scripts/verify_deployment.sh",
            timeout=600,
            on_failure="rollback"
        ),
        PipelineStep(
            name="post_deploy_verify",
            command="/opt/nova-os/scripts/smoke_tests.sh",
            verify_command="/opt/nova-os/scripts/verify_endpoints.sh",
            on_failure="rollback"
        ),
        PipelineStep(
            name="cleanup_old_images",
            command="docker image prune -a -f",
            on_failure="continue"  # Non-critical cleanup
        )
    ],
    notification_targets=[OWNER_ID],
    auto_rollback=True
)
```

## Task Queue System

### Queue Implementation

```python
import asyncio
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

class TaskPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class Task:
    id: str
    name: str
    coro: Callable  # async function to execute
    priority: TaskPriority
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = None
    started_at: datetime = None
    completed_at: datetime = None
    result: any = None
    error: str = None
    retries: int = 0
    max_retries: int = 3

class TaskQueue:
    """Priority task queue with concurrent execution limits."""
    
    def __init__(self, max_concurrent: int = 3):
        self.queue = asyncio.PriorityQueue()
        self.max_concurrent = max_concurrent
        self.running = 0
        self.tasks = {}  # task_id -> Task
        self._semaphore = asyncio.Semaphore(max_concurrent)
    
    async def submit(self, task: Task) -> str:
        task.created_at = datetime.utcnow()
        self.tasks[task.id] = task
        await self.queue.put((task.priority.value, task.created_at, task.id))
        return task.id
    
    async def worker(self):
        while True:
            _, _, task_id = await self.queue.get()
            task = self.tasks[task_id]
            
            async with self._semaphore:
                task.status = TaskStatus.RUNNING
                task.started_at = datetime.utcnow()
                
                try:
                    task.result = await task.coro()
                    task.status = TaskStatus.COMPLETED
                except Exception as e:
                    task.error = str(e)
                    if task.retries < task.max_retries:
                        task.retries += 1
                        task.status = TaskStatus.PENDING
                        await self.queue.put((task.priority.value, datetime.utcnow(), task.id))
                    else:
                        task.status = TaskStatus.FAILED
                finally:
                    task.completed_at = datetime.utcnow()
                    self.running -= 1

# Global task queue
task_queue = TaskQueue(max_concurrent=3)

# Start workers on boot
async def start_task_workers():
    for _ in range(3):
        asyncio.create_task(task_queue.worker())
```

## Workflow Definitions

### Workflow Registry

```python
WORKFLOWS = {}

def workflow(name: str):
    """Decorator to register a workflow function."""
    def decorator(func):
        WORKFLOWS[name] = func
        return func
    return decorator

@workflow("check_updates")
async def wf_check_updates(params: dict):
    result = await shell("sudo apt-get update -qq && apt-get --just-print upgrade | grep -c '^Inst'")
    count = int(result["stdout"].strip()) if result["returncode"] == 0 else 0
    
    if count > 0 and params.get("notify"):
        await notify_owner(f"{count} package updates available. Use `/run update` to apply.")
    
    if params.get("auto_apply_security"):
        security = await shell("apt-get --just-print upgrade | grep -i security | wc -l")
        if int(security["stdout"].strip()) > 0:
            await shell("sudo apt-get upgrade -y -o APT::Get::Show-Upgraded=true | grep -i security")
            await notify_owner("Security updates applied automatically.")
    
    return {"updates_available": count}

@workflow("security_audit")
async def wf_security_audit(params: dict):
    results = {}
    
    # Check for listening services
    results["services"] = await shell("ss -tlnp | grep LISTEN")
    
    # Check failed logins
    results["failed_logins"] = await shell("grep 'Failed password' /var/log/auth.log | tail -20")
    
    # Check for SUID binaries
    results["suid_binaries"] = await shell("find / -perm -4000 -type f 2>/dev/null")
    
    # Check open ports from external
    results["external_ports"] = await shell("nmap -sT -O localhost 2>/dev/null | grep -E '( open |filtered)'")
    
    # AIDE check if available
    aide = await shell("aide --check 2>&1 | tail -20")
    results["file_integrity"] = aide if aide["returncode"] == 0 else "AIDE not configured"
    
    await notify_owner("Security audit complete. Check /var/log/nova-os/security_audit.log")
    return results

@workflow("backup_all_databases")
async def wf_backup_databases(params: dict):
    # Load database configs from state
    databases = await db.fetchall("SELECT name, type, host, db_name FROM databases")
    results = []
    
    for db in databases:
        backup_path = f"/opt/nova-os/backups/{db['name']}_{datetime.utcnow():%Y%m%d_%H%M%S}.sql"
        
        if db["type"] == "postgresql":
            password = await resolve_secret(f"{db['name']}_password")
            result = await shell(f"PGPASSWORD={password} pg_dump -h {db['host']} -U {db['name']} {db['db_name']} > {backup_path}")
        elif db["type"] == "mysql":
            password = await resolve_secret(f"{db['name']}_password")
            result = await shell(f"mysqldump -u {db['name']} -p{password} -h {db['host']} {db['db_name']} > {backup_path}")
        
        if params.get("encrypt"):
            await shell(f"age -r $(cat /opt/nova-os/backup_recipient.txt) -o {backup_path}.age {backup_path} && rm {backup_path}")
            backup_path += ".age"
        
        results.append({"database": db["name"], "path": backup_path, "status": "ok" if result["returncode"] == 0 else "failed"})
    
    # Cleanup old backups
    retention = params.get("retention_days", 30)
    await shell(f"find /opt/nova-os/backups -name '*.sql*' -mtime +{retention} -delete")
    
    return {"backups": results}

@workflow("check_cert_expiry")
async def wf_check_cert_expiry(params: dict):
    certs = await db.fetchall("SELECT domain, cert_path FROM ssl_certificates")
    expiring = []
    
    for cert in certs:
        result = await shell(f"openssl x509 -in {cert['cert_path']} -noout -enddate")
        if result["returncode"] == 0:
            expiry_str = result["stdout"].replace("notAfter=", "").strip()
            expiry = datetime.strptime(expiry_str, "%b %d %H:%M:%S %Y %Z")
            days_until = (expiry - datetime.utcnow()).days
            
            if days_until <= params.get("warn_days", 30):
                expiring.append({"domain": cert["domain"], "days": days_until})
            
            if days_until <= 7 and params.get("auto_renew"):
                await shell(f"sudo certbot renew --cert-name {cert['domain']} --force-renewal")
                await notify_owner(f"Auto-renewed certificate for {cert['domain']}")
    
    if expiring:
        domains = "\n".join(f"- {c['domain']}: {c['days']} days" for c in expiring)
        await notify_owner(f"SSL certificates expiring soon:\n{domains}")
    
    return {"expiring": expiring}

async def execute_workflow(name: str, params: dict = None):
    """Execute a workflow by name."""
    if name not in WORKFLOWS:
        raise ValueError(f"Unknown workflow: {name}")
    
    workflow_fn = WORKFLOWS[name]
    start_time = time.time()
    
    try:
        result = await workflow_fn(params or {})
        await db.execute(
            "INSERT INTO workflow_runs (name, status, started_at, duration_ms, result) VALUES (?, ?, ?, ?, ?)",
            (name, "success", datetime.utcnow(), int((time.time() - start_time) * 1000), json.dumps(result))
        )
        return result
    except Exception as e:
        await db.execute(
            "INSERT INTO workflow_runs (name, status, started_at, duration_ms, error) VALUES (?, ?, ?, ?, ?)",
            (name, "failed", datetime.utcnow(), int((time.time() - start_time) * 1000), str(e))
        )
        raise
```

## Fault Tolerance & Recovery

### Retry Strategies

```python
from enum import Enum

class RetryStrategy(Enum):
    FIXED = "fixed"           # Wait N seconds between retries
    EXPONENTIAL = "exponential"  # Double wait each retry
    LINEAR = "linear"         # Add N seconds each retry

async def with_retry(
    coro,
    max_retries: int = 3,
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    retryable_exceptions: tuple = (ConnectionError, TimeoutError)
):
    last_error = None
    
    for attempt in range(max_retries + 1):
        try:
            return await coro
        except retryable_exceptions as e:
            last_error = e
            if attempt == max_retries:
                break
            
            if strategy == RetryStrategy.FIXED:
                delay = base_delay
            elif strategy == RetryStrategy.EXPONENTIAL:
                delay = min(base_delay * (2 ** attempt), max_delay)
            else:  # LINEAR
                delay = min(base_delay * (attempt + 1), max_delay)
            
            await asyncio.sleep(delay)
    
    raise last_error
```

### Circuit Breaker Integration

Circuit breaker pattern is defined in `references/web-automation.md`. For system operations, use a simpler variant:

```python
class SystemCircuitBreaker:
    """Circuit breaker for system-level operations."""
    
    def __init__(self, name: str, failure_threshold: int = 5, recovery_timeout: int = 300):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.last_failure = 0
        self.state = "closed"  # closed, open, half_open
    
    def record_success(self):
        self.failures = max(0, self.failures - 1)
        if self.state == "half_open":
            self.state = "closed"
    
    def record_failure(self):
        self.failures += 1
        self.last_failure = time.time()
        if self.failures >= self.failure_threshold:
            self.state = "open"
    
    def can_execute(self) -> bool:
        if self.state == "closed":
            return True
        elif self.state == "open":
            if time.time() - self.last_failure > self.recovery_timeout:
                self.state = "half_open"
                return True
            return False
        else:  # half_open
            return True
```

### Graceful Degradation

```python
async def degraded_service(primary_coro, fallback_coro, fallback_value=None):
    """Try primary service, fall back to secondary on failure."""
    try:
        return await primary_coro
    except Exception:
        try:
            return await fallback_coro
        except Exception:
            return fallback_value
```

## Health Check System

### Health Check Definitions

```python
@dataclass
class HealthCheck:
    name: str
    check: Callable  # async function returning (status, details)
    interval: int  # seconds
    timeout: int = 10

async def check_disk_space() -> tuple:
    result = await shell("df / | tail -1 | awk '{print $5}' | sed 's/%//'")
    used = int(result["stdout"].strip())
    if used > 95:
        return "critical", f"Disk {used}% full"
    elif used > 85:
        return "warning", f"Disk {used}% full"
    return "ok", f"Disk {used}% used"

async def check_memory() -> tuple:
    result = await shell("free | grep Mem | awk '{print int($3/$2 * 100)}'")
    used = int(result["stdout"].strip())
    if used > 95:
        return "critical", f"Memory {used}% used"
    elif used > 85:
        return "warning", f"Memory {used}% used"
    return "ok", f"Memory {used}% used"

async def check_load() -> tuple:
    result = await shell("uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//'")
    load = float(result["stdout"].strip())
    cores = os.cpu_count()
    ratio = load / cores
    
    if ratio > 2.0:
        return "critical", f"Load {load} on {cores} cores"
    elif ratio > 1.0:
        return "warning", f"Load {load} on {cores} cores"
    return "ok", f"Load {load}"

async def check_services() -> tuple:
    failed = []
    services = await db.fetchall("SELECT name FROM monitored_services WHERE enabled = 1")
    for svc in services:
        result = await shell(f"systemctl is-active {svc['name']}")
        if result["returncode"] != 0:
            failed.append(svc["name"])
    
    if failed:
        return "critical", f"Services down: {', '.join(failed)}"
    return "ok", "All services active"

HEALTH_CHECKS = [
    HealthCheck("disk", check_disk_space, 300),
    HealthCheck("memory", check_memory, 60),
    HealthCheck("load", check_load, 60),
    HealthCheck("services", check_services, 60),
]
```

### Health Check Runner

```python
async def run_health_checks():
    """Execute all health checks and publish results."""
    status = {"overall": "ok", "checks": {}, "timestamp": datetime.utcnow().isoformat()}
    
    for check in HEALTH_CHECKS:
        try:
            check_status, details = await asyncio.wait_for(check.check(), timeout=check.timeout)
            status["checks"][check.name] = {"status": check_status, "details": details}
            
            if check_status == "critical" and status["overall"] != "critical":
                status["overall"] = "critical"
            elif check_status == "warning" and status["overall"] == "ok":
                status["overall"] = "warning"
                
        except asyncio.TimeoutError:
            status["checks"][check.name] = {"status": "critical", "details": "Check timed out"}
            status["overall"] = "critical"
    
    # Store result
    await db.execute(
        "INSERT INTO health_history (timestamp, overall_status, details) VALUES (?, ?, ?)",
        (status["timestamp"], status["overall"], json.dumps(status["checks"]))
    )
    
    # Publish events for critical/warning
    if status["overall"] in ("critical", "warning"):
        await events.publish("health_degraded", status)
    
    return status
```

## Backup Orchestration

### Backup Strategy

| Data Type | Frequency | Retention | Encryption | Method |
|---|---|---|---|---|
| State database (SQLite) | 6 hours | 30 days | Age | File copy + encrypt |
| Application databases | 6 hours | 30 days | Age | Native dump + encrypt |
| Configuration files | On change | 90 days | Age | Git commit + encrypt |
| SSL certificates | On change | 365 days | Age | File copy + encrypt |
| Full system | Weekly | 14 days | Age | tar.gz + encrypt |

### Backup Verification

```python
async def verify_backups():
    """Verify recent backups are restorable."""
    recent = await db.fetchall(
        "SELECT path, checksum, created_at FROM backups WHERE created_at > datetime('now', '-7 days') ORDER BY created_at DESC"
    )
    
    results = []
    for backup in recent:
        if not Path(backup["path"]).exists():
            results.append({"backup": backup["path"], "status": "missing"})
            continue
        
        # Verify checksum
        result = await shell(f"sha256sum {backup['path']} | awk '{{print $1}}'")
        actual_checksum = result["stdout"].strip()
        
        if actual_checksum != backup["checksum"]:
            results.append({"backup": backup["path"], "status": "checksum_mismatch"})
            await notify_owner(f"Backup integrity check FAILED: {backup['path']}")
        else:
            results.append({"backup": backup["path"], "status": "ok"})
    
    return results
```

## Monitoring Integration

### Prometheus Metrics Export

```python
from prometheus_client import CollectorRegistry, Gauge, Counter, generate_latest

registry = CollectorRegistry()

# Define metrics
metric_system_load = Gauge("nova_system_load", "System load average", registry=registry)
metric_memory_usage = Gauge("nova_memory_usage_percent", "Memory usage percent", registry=registry)
metric_disk_usage = Gauge("nova_disk_usage_percent", "Disk usage percent", registry=registry)
metric_commands_total = Counter("nova_commands_total", "Total commands executed", ["status"], registry=registry)
metric_alerts_total = Counter("nova_alerts_total", "Total alerts sent", ["severity"], registry=registry)

async def update_prometheus_metrics():
    """Update Prometheus metrics from current system state."""
    load = await shell("cat /proc/loadavg | awk '{print $1}'")
    if load["returncode"] == 0:
        metric_system_load.set(float(load["stdout"].strip()))
    
    mem = await shell("free | grep Mem | awk '{print int($3/$2 * 100)}'")
    if mem["returncode"] == 0:
        metric_memory_usage.set(int(mem["stdout"].strip()))
    
    disk = await shell("df / | tail -1 | awk '{print $5}' | sed 's/%//'")
    if disk["returncode"] == 0:
        metric_disk_usage.set(int(disk["stdout"].strip()))

async def metrics_handler(request: web.Request) -> web.Response:
    await update_prometheus_metrics()
    return web.Response(
        body=generate_latest(registry),
        content_type="text/plain; version=0.0.4"
    )
```

### Alert Manager

```python
class AlertManager:
    """Manage alert lifecycle: firing → acknowledged → resolved."""
    
    def __init__(self):
        self.active_alerts: dict[str, dict] = {}
    
    async def fire(self, alert_id: str, severity: str, title: str, description: str):
        if alert_id in self.active_alerts:
            return  # Already firing
        
        self.active_alerts[alert_id] = {
            "id": alert_id,
            "severity": severity,
            "title": title,
            "description": description,
            "fired_at": datetime.utcnow(),
            "acknowledged": False,
            "acknowledged_by": None,
            "count": 1
        }
        
        await notify_owner(f"[{severity}] {title}\n{description}\n\nAck: /ack {alert_id}")
        metric_alerts_total.labels(severity=severity).inc()
    
    async def acknowledge(self, alert_id: str, user_id: int):
        if alert_id not in self.active_alerts:
            return False
        
        self.active_alerts[alert_id]["acknowledged"] = True
        self.active_alerts[alert_id]["acknowledged_by"] = user_id
        return True
    
    async def resolve(self, alert_id: str):
        if alert_id in self.active_alerts:
            del self.active_alerts[alert_id]
            await notify_owner(f"Resolved: {alert_id}")

alert_manager = AlertManager()
```
